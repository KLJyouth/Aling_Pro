const crypto = require('crypto');

class Auth {
    static generateSignature(data, secret) {
        return crypto.createHmac('sha256', secret)
                    .update(JSON.stringify(data))
                    .digest('hex');
    }
    
    static validateSignature(data, signature, secret) {
        const expectedSignature = this.generateSignature(data, secret);
        return crypto.timingSafeEqual(
            Buffer.from(signature, 'hex'),
            Buffer.from(expectedSignature, 'hex')
        );
    }
}

module.exports = Auth;
