class AlingAI {
    constructor(apiKey, apiSecret) {
        this.apiKey = apiKey;
        this.apiSecret = apiSecret;
        this.baseUrl = 'https://api.alingai.com/v1';
    }
    
    async quantumEncrypt(data) {
        return this.request('POST', '/quantum/encrypt', { data });
    }
    
    async quantumDecrypt(encryptedData) {
        return this.request('POST', '/quantum/decrypt', { encrypted_data: encryptedData });
    }
    
    async zeroTrustVerify(identity) {
        return this.request('POST', '/zerotrust/verify', { identity });
    }
    
    async aiChat(message, model = 'default') {
        return this.request('POST', '/ai/chat', { message, model });
    }
    
    async request(method, endpoint, data = {}) {
        const url = this.baseUrl + endpoint;
        const headers = {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json',
            'X-SDK-Version': '2025.06.15'
        };
        
        const response = await fetch(url, {
            method,
            headers,
            body: method !== 'GET' ? JSON.stringify(data) : undefined
        });
        
        if (!response.ok) {
            throw new Error(`API请求失败: ${response.statusText}`);
        }
        
        return response.json();
    }
}

// Node.js 兼容
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AlingAI;
}
