const path = require('path');

module.exports = {
    entry: './src/alingai.js',
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: 'alingai.min.js',
        library: 'AlingAI',
        libraryTarget: 'umd'
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-env']
                    }
                }
            }
        ]
    }
};
