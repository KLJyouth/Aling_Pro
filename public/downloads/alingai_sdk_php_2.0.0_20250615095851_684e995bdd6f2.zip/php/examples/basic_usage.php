<?php

require_once 'vendor/autoload.php';

use AlingAI\Client;

// 初始化客户端
$client = new Client('your_api_key', 'your_api_secret');

try {
    // 量子加密示例
    $encrypted = $client->quantumEncrypt('Hello, AlingAI!');
    echo '加密结果: ' . json_encode($encrypted) . PHP_EOL;
    
    // 零信任验证示例
    $verification = $client->zeroTrustVerify([
        'user_id' => 'user123',
        'device_id' => 'device456'
    ]);
    echo '验证结果: ' . json_encode($verification) . PHP_EOL;
    
    // AI聊天示例
    $response = $client->aiChat('你好，我需要安全建议');
    echo 'AI回复: ' . json_encode($response) . PHP_EOL;
    
} catch (Exception $e) {
    echo '错误: ' . $e->getMessage() . PHP_EOL;
}
