from alingai import Client

# 初始化客户端
client = Client('your_api_key', 'your_api_secret')

try:
    # 量子加密示例
    encrypted = client.quantum_encrypt('Hello, AlingAI!')
    print('加密结果:', encrypted)
    
    # 零信任验证示例
    verification = client.zero_trust_verify({
        'user_id': 'user123',
        'device_id': 'device456'
    })
    print('验证结果:', verification)
    
    # AI聊天示例
    response = client.ai_chat('你好，我需要安全建议')
    print('AI回复:', response)
    
except Exception as e:
    print('错误:', str(e))
