import hmac
import hashlib
import json

class Auth:
    @staticmethod
    def generate_signature(data, secret):
        return hmac.new(
            secret.encode('utf-8'),
            json.dumps(data).encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
    
    @staticmethod
    def validate_signature(data, signature, secret):
        expected_signature = Auth.generate_signature(data, secret)
        return hmac.compare_digest(signature, expected_signature)
