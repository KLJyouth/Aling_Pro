import requests
import json

class Client:
    def __init__(self, api_key, api_secret):
        self.api_key = api_key
        self.api_secret = api_secret
        self.base_url = 'https://api.alingai.com/v1'
    
    def quantum_encrypt(self, data):
        return self._request('POST', '/quantum/encrypt', {'data': data})
    
    def quantum_decrypt(self, encrypted_data):
        return self._request('POST', '/quantum/decrypt', {'encrypted_data': encrypted_data})
    
    def zero_trust_verify(self, identity):
        return self._request('POST', '/zerotrust/verify', {'identity': identity})
    
    def ai_chat(self, message, model='default'):
        return self._request('POST', '/ai/chat', {'message': message, 'model': model})
    
    def _request(self, method, endpoint, data=None):
        url = self.base_url + endpoint
        headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json',
            'X-SDK-Version': '2025.06.15'
        }
        
        response = requests.request(method, url, headers=headers, json=data)
        
        if response.status_code >= 200 and response.status_code < 300:
            return response.json()
        else:
            raise Exception(f'API请求失败: {response.text}')
