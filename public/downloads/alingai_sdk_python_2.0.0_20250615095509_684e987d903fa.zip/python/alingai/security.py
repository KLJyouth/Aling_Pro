from cryptography.fernet import Fernet
import base64

class Security:
    @staticmethod
    def generate_key():
        return Fernet.generate_key()
    
    @staticmethod
    def encrypt_data(data, key):
        f = Fernet(key)
        return f.encrypt(data.encode()).decode()
    
    @staticmethod
    def decrypt_data(encrypted_data, key):
        f = Fernet(key)
        return f.decrypt(encrypted_data.encode()).decode()
