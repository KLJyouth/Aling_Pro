from setuptools import setup, find_packages

setup(
    name='alingai-sdk',
    version='2.0.0',
    description='AlingAI Platform Python SDK',
    author='AlingAI Team',
    author_email='dev@alingai.com',
    packages=find_packages(),
    install_requires=[
        'requests>=2.25.0',
        'cryptography>=3.4.0'
    ],
    python_requires='>=3.6',
    license='MIT'
)
