# API参考文档

## 基础URL
```
https://api.alingai.com/v1
```

## 认证
所有API请求都需要在请求头中包含API密钥：
```
Authorization: Bearer YOUR_API_KEY
```

## 端点

### 量子安全
- `POST /quantum/encrypt` - 量子加密
- `POST /quantum/decrypt` - 量子解密
- `GET /quantum/status` - 获取量子服务状态

### 零信任架构
- `POST /zerotrust/verify` - 身份验证
- `GET /zerotrust/policies` - 获取安全策略
- `POST /zerotrust/audit` - 安全审计

### AI安全助手
- `POST /ai/chat` - AI对话
- `GET /ai/models` - 获取可用模型
- `POST /ai/analyze` - 安全分析

更多详细信息请访问在线文档。
