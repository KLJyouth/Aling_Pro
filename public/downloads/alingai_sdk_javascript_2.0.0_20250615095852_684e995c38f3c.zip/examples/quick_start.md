# 快速开始指南

## 1. 安装SDK
根据您使用的编程语言，选择对应的SDK目录进行安装。

## 2. 获取API凭据
```
API_KEY=your_api_key_here
API_SECRET=your_api_secret_here
```

## 3. 初始化客户端
请参考各语言目录下的示例代码。

## 4. 基础API调用
- 量子加密: `/api/v1/quantum/encrypt`
- 零信任验证: `/api/v1/zerotrust/verify`
- AI助手: `/api/v1/ai/chat`

更多详细信息请参考API文档。
