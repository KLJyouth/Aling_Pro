// 浏览器环境示例
const client = new AlingAI('your_api_key', 'your_api_secret');

async function example() {
    try {
        // 量子加密示例
        const encrypted = await client.quantumEncrypt('Hello, AlingAI!');
        console.log('加密结果:', encrypted);
        
        // 零信任验证示例
        const verification = await client.zeroTrustVerify({
            user_id: 'user123',
            device_id: 'device456'
        });
        console.log('验证结果:', verification);
        
        // AI聊天示例
        const response = await client.aiChat('你好，我需要安全建议');
        console.log('AI回复:', response);
        
    } catch (error) {
        console.error('错误:', error.message);
    }
}

example();
