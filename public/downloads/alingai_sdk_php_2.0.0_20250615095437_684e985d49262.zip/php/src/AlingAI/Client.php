<?php

namespace AlingAI;

class Client {
    private $apiKey;
    private $apiSecret;
    private $baseUrl = 'https://api.alingai.com/v1';
    
    public function __construct($apiKey, $apiSecret) {
        $this->apiKey = $apiKey;
        $this->apiSecret = $apiSecret;
    }
    
    public function quantumEncrypt($data) {
        return $this->request('POST', '/quantum/encrypt', ['data' => $data]);
    }
    
    public function quantumDecrypt($encryptedData) {
        return $this->request('POST', '/quantum/decrypt', ['encrypted_data' => $encryptedData]);
    }
    
    public function zeroTrustVerify($identity) {
        return $this->request('POST', '/zerotrust/verify', ['identity' => $identity]);
    }
    
    public function aiChat($message, $model = 'default') {
        return $this->request('POST', '/ai/chat', ['message' => $message, 'model' => $model]);
    }
    
    private function request($method, $endpoint, $data = []) {
        $url = $this->baseUrl . $endpoint;
        $headers = [
            'Authorization: Bearer ' . $this->apiKey,
            'Content-Type: application/json',
            'X-SDK-Version: 2025.06.15'
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        
        if (!empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode >= 200 && $httpCode < 300) {
            return json_decode($response, true);
        } else {
            throw new Exception('API请求失败: ' . $response);
        }
    }
}
