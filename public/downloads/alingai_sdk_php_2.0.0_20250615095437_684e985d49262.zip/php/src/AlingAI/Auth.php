<?php

namespace AlingAI;

class Auth {
    public static function generateSignature($data, $secret) {
        return hash_hmac('sha256', json_encode($data), $secret);
    }
    
    public static function validateSignature($data, $signature, $secret) {
        return hash_equals($signature, self::generateSignature($data, $secret));
    }
}
