<?php

namespace AlingAI;

class Utils {
    public static function formatResponse($data) {
        return [
            'success' => true,
            'data' => $data,
            'timestamp' => time()
        ];
    }
    
    public static function formatError($message, $code = 500) {
        return [
            'success' => false,
            'error' => $message,
            'code' => $code,
            'timestamp' => time()
        ];
    }
}
