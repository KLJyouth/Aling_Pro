<?php
return array (
  'version' => 1748810536,
  'css_version' => 1748806738,
  'js_version' => 1748806737,
  'cache_duration' => 31536000,
);
