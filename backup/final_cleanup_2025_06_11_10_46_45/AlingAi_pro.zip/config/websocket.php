<?php
return array (
  'host' => '0.0.0.0',
  'port' => 8080,
  'ssl' => false,
  'ping_interval' => 30,
  'max_connections' => 1000,
);
