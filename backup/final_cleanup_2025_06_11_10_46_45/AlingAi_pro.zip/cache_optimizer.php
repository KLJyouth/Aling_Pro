<?php
/**
 * AlingAi Pro 缓存优化器
 * 创建高性能应用级缓存机制
 */

require_once __DIR__ . '/vendor/autoload.php';

class CacheOptimizer 
{
    private $logger;
    
    public function __construct() 
    {
        $this->logger = new \Monolog\Logger('cache_optimizer');
        $this->logger->pushHandler(new \Monolog\Handler\StreamHandler('storage/logs/cache_optimizer.log'));
        
        echo "🚀 AlingAi Pro 缓存优化器 v1.0\n";
        echo "===============================\n\n";
    }
    
    /**
     * 运行缓存优化
     */
    public function optimize(): void 
    {
        echo "开始缓存优化...\n\n";
        
        $this->createAdvancedFileCache();
        $this->setupOPcacheOptimization();
        $this->createApplicationCacheManager();
        $this->optimizeStaticAssets();
        $this->generateCacheConfig();
        
        echo "✅ 缓存优化完成！\n";
    }
    
    /**
     * 1. 创建高级文件缓存
     */
    private function createAdvancedFileCache(): void 
    {
        echo "1. 创建高级文件缓存系统...\n";
        
        $cacheDir = 'storage/cache/advanced';
        if (!is_dir($cacheDir)) {
            mkdir($cacheDir, 0755, true);
        }
        
        $advancedCache = '<?php
/**
 * 高级文件缓存服务
 */

namespace AlingAi\Cache;

class AdvancedFileCache 
{
    private string $cacheDir;
    private int $defaultTtl = 3600; // 1小时
    private array $memoryCache = []; // 内存级缓存
    
    public function __construct(string $cacheDir = null) 
    {
        $this->cacheDir = $cacheDir ?: __DIR__ . "/../../storage/cache/advanced";
        
        if (!is_dir($this->cacheDir)) {
            mkdir($this->cacheDir, 0755, true);
        }
    }
    
    /**
     * 获取缓存
     */
    public function get(string $key): mixed 
    {
        // 首先从内存缓存获取
        if (isset($this->memoryCache[$key])) {
            $item = $this->memoryCache[$key];
            if ($item["expires"] > time()) {
                return $item["data"];
            }
            unset($this->memoryCache[$key]);
        }
        
        $file = $this->getCacheFile($key);
        if (!file_exists($file)) {
            return null;
        }
        
        $content = file_get_contents($file);
        $data = unserialize($content);
        
        if ($data["expires"] < time()) {
            unlink($file);
            return null;
        }
        
        // 存入内存缓存
        $this->memoryCache[$key] = $data;
        
        return $data["data"];
    }
    
    /**
     * 设置缓存
     */
    public function set(string $key, mixed $value, int $ttl = null): bool 
    {
        $ttl = $ttl ?: $this->defaultTtl;
        $data = [
            "data" => $value,
            "expires" => time() + $ttl,
            "created" => time()
        ];
        
        // 存入内存缓存
        $this->memoryCache[$key] = $data;
        
        // 存入文件缓存
        $file = $this->getCacheFile($key);
        return file_put_contents($file, serialize($data)) !== false;
    }
    
    /**
     * 删除缓存
     */
    public function delete(string $key): bool 
    {
        unset($this->memoryCache[$key]);
        
        $file = $this->getCacheFile($key);
        if (file_exists($file)) {
            return unlink($file);
        }
        
        return true;
    }
    
    /**
     * 清空缓存
     */
    public function clear(): bool 
    {
        $this->memoryCache = [];
        
        $files = glob($this->cacheDir . "/*");
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }
        
        return true;
    }
    
    /**
     * 获取缓存统计
     */
    public function getStats(): array 
    {
        $files = glob($this->cacheDir . "/*");
        $totalSize = 0;
        $validCount = 0;
        $expiredCount = 0;
        
        foreach ($files as $file) {
            if (is_file($file)) {
                $totalSize += filesize($file);
                $content = file_get_contents($file);
                $data = unserialize($content);
                
                if ($data["expires"] > time()) {
                    $validCount++;
                } else {
                    $expiredCount++;
                }
            }
        }
        
        return [
            "total_files" => count($files),
            "valid_entries" => $validCount,
            "expired_entries" => $expiredCount,
            "memory_entries" => count($this->memoryCache),
            "total_size_bytes" => $totalSize,
            "cache_dir" => $this->cacheDir
        ];
    }
    
    /**
     * 清理过期缓存
     */
    public function cleanup(): int 
    {
        $cleaned = 0;
        $files = glob($this->cacheDir . "/*");
        
        foreach ($files as $file) {
            if (is_file($file)) {
                $content = file_get_contents($file);
                $data = unserialize($content);
                
                if ($data["expires"] < time()) {
                    unlink($file);
                    $cleaned++;
                }
            }
        }
        
        return $cleaned;
    }
    
    private function getCacheFile(string $key): string 
    {
        return $this->cacheDir . "/" . md5($key) . ".cache";
    }
}';
        
        file_put_contents('src/Cache/AdvancedFileCache.php', $advancedCache);
        echo "  ✓ 高级文件缓存类已创建\n";
        echo "✓ 高级文件缓存系统完成\n\n";
    }
    
    /**
     * 2. 设置OPcache优化
     */
    private function setupOPcacheOptimization(): void 
    {
        echo "2. 配置OPcache优化...\n";
        
        $opcacheConfig = ';
; OPcache 优化配置
; 添加到php.ini文件中

[opcache]
; 启用OPcache
opcache.enable=1
opcache.enable_cli=1

; 内存设置
opcache.memory_consumption=256
opcache.interned_strings_buffer=16
opcache.max_accelerated_files=10000

; 验证设置
opcache.validate_timestamps=0
opcache.revalidate_freq=0

; 文件缓存
opcache.file_cache=' . __DIR__ . '/storage/opcache
opcache.file_cache_only=0

; 优化设置
opcache.fast_shutdown=1
opcache.enable_file_override=1
opcache.optimization_level=0x7FFFBFFF

; 预加载 (PHP 7.4+)
; opcache.preload=' . __DIR__ . '/config/preload.php
; opcache.preload_user=www-data
';
        
        file_put_contents('config/opcache.ini', $opcacheConfig);
        
        // 创建预加载文件
        $preloadScript = '<?php
/**
 * OPcache 预加载脚本
 * 预加载常用类和函数
 */

// 预加载核心类
$classesToPreload = [
    __DIR__ . "/../vendor/autoload.php",
    __DIR__ . "/../src/Services/DatabaseService.php",
    __DIR__ . "/../src/Services/CacheService.php",
    __DIR__ . "/../src/Controllers/BaseController.php",
    __DIR__ . "/../src/Utils/Logger.php",
];

foreach ($classesToPreload as $file) {
    if (file_exists($file)) {
        require_once $file;
    }
}

// 预加载常用函数
function preloadedFunction() {
    return "Preloaded successfully";
}
';
        
        file_put_contents('config/preload.php', $preloadScript);
        
        echo "  ✓ OPcache配置已生成: config/opcache.ini\n";
        echo "  ✓ 预加载脚本已创建: config/preload.php\n";
        echo "✓ OPcache优化完成\n\n";
    }
    
    /**
     * 3. 创建应用缓存管理器
     */
    private function createApplicationCacheManager(): void 
    {
        echo "3. 创建应用缓存管理器...\n";
        
        $cacheManager = '<?php
/**
 * 应用缓存管理器
 */

namespace AlingAi\Cache;

use AlingAi\Cache\AdvancedFileCache;

class ApplicationCacheManager 
{
    private AdvancedFileCache $cache;
    private array $tags = [];
    
    public function __construct() 
    {
        $this->cache = new AdvancedFileCache();
    }
    
    /**
     * 缓存数据库查询结果
     */
    public function cacheQuery(string $sql, array $params, mixed $result, int $ttl = 300): void 
    {
        $key = "query:" . md5($sql . serialize($params));
        $this->cache->set($key, $result, $ttl);
    }
    
    /**
     * 获取缓存的查询结果
     */
    public function getCachedQuery(string $sql, array $params): mixed 
    {
        $key = "query:" . md5($sql . serialize($params));
        return $this->cache->get($key);
    }
    
    /**
     * 缓存API响应
     */
    public function cacheApiResponse(string $endpoint, array $params, mixed $response, int $ttl = 60): void 
    {
        $key = "api:" . md5($endpoint . serialize($params));
        $this->cache->set($key, $response, $ttl);
    }
    
    /**
     * 获取缓存的API响应
     */
    public function getCachedApiResponse(string $endpoint, array $params): mixed 
    {
        $key = "api:" . md5($endpoint . serialize($params));
        return $this->cache->get($key);
    }
    
    /**
     * 缓存用户会话
     */
    public function cacheUserSession(int $userId, array $sessionData, int $ttl = 1800): void 
    {
        $key = "session:user:" . $userId;
        $this->cache->set($key, $sessionData, $ttl);
    }
    
    /**
     * 获取缓存的用户会话
     */
    public function getCachedUserSession(int $userId): mixed 
    {
        $key = "session:user:" . $userId;
        return $this->cache->get($key);
    }
    
    /**
     * 缓存配置
     */
    public function cacheConfig(array $config, int $ttl = 3600): void 
    {
        $this->cache->set("app:config", $config, $ttl);
    }
    
    /**
     * 获取缓存的配置
     */
    public function getCachedConfig(): mixed 
    {
        return $this->cache->get("app:config");
    }
    
    /**
     * 按标签清理缓存
     */
    public function clearByTag(string $tag): void 
    {
        // 简化实现，在生产环境中需要更复杂的标签系统
        if ($tag === "queries") {
            $this->clearQueryCache();
        } elseif ($tag === "api") {
            $this->clearApiCache();
        }
    }
    
    /**
     * 清理查询缓存
     */
    public function clearQueryCache(): void 
    {
        // 实现查询缓存清理逻辑
        $this->cache->delete("query:*");
    }
    
    /**
     * 清理API缓存
     */
    public function clearApiCache(): void 
    {
        // 实现API缓存清理逻辑
        $this->cache->delete("api:*");
    }
    
    /**
     * 获取缓存统计
     */
    public function getStats(): array 
    {
        return $this->cache->getStats();
    }
    
    /**
     * 清理过期缓存
     */
    public function cleanup(): int 
    {
        return $this->cache->cleanup();
    }
}';
        
        file_put_contents('src/Cache/ApplicationCacheManager.php', $cacheManager);
        echo "  ✓ 应用缓存管理器已创建\n";
        echo "✓ 应用缓存管理器完成\n\n";
    }
    
    /**
     * 4. 优化静态资源
     */
    private function optimizeStaticAssets(): void 
    {
        echo "4. 优化静态资源缓存...\n";
        
        $htaccessAddition = '
# 静态资源缓存优化
<IfModule mod_expires.c>
    ExpiresActive On
    
    # CSS和JS文件缓存1年
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
    ExpiresByType application/x-javascript "access plus 1 year"
    
    # 图片文件缓存1个月
    ExpiresByType image/png "access plus 1 month"
    ExpiresByType image/jpg "access plus 1 month"
    ExpiresByType image/jpeg "access plus 1 month"
    ExpiresByType image/gif "access plus 1 month"
    ExpiresByType image/svg+xml "access plus 1 month"
    ExpiresByType image/webp "access plus 1 month"
    
    # 字体文件缓存1年
    ExpiresByType font/woff "access plus 1 year"
    ExpiresByType font/woff2 "access plus 1 year"
    ExpiresByType application/font-woff "access plus 1 year"
    ExpiresByType application/font-woff2 "access plus 1 year"
    
    # HTML文件缓存1小时
    ExpiresByType text/html "access plus 1 hour"
</IfModule>

# 启用ETags
FileETag MTime Size

# 浏览器缓存控制
<IfModule mod_headers.c>
    # CSS和JS文件
    <FilesMatch "\.(css|js)$">
        Header set Cache-Control "public, max-age=31536000, immutable"
    </FilesMatch>
    
    # 图片文件
    <FilesMatch "\.(png|jpg|jpeg|gif|svg|webp)$">
        Header set Cache-Control "public, max-age=2592000"
    </FilesMatch>
    
    # 字体文件
    <FilesMatch "\.(woff|woff2|ttf|eot)$">
        Header set Cache-Control "public, max-age=31536000, immutable"
    </FilesMatch>
</IfModule>
';
        
        // 将缓存规则添加到.htaccess
        $htaccessFile = 'public/.htaccess';
        if (file_exists($htaccessFile)) {
            file_put_contents($htaccessFile, $htaccessAddition, FILE_APPEND);
        } else {
            file_put_contents($htaccessFile, $htaccessAddition);
        }
        
        echo "  ✓ 静态资源缓存规则已添加到 public/.htaccess\n";
        echo "✓ 静态资源优化完成\n\n";
    }
    
    /**
     * 5. 生成缓存配置
     */
    private function generateCacheConfig(): void 
    {
        echo "5. 生成缓存配置...\n";
        
        $cacheConfig = '<?php
/**
 * 缓存配置
 */

return [
    "default" => "file",
    
    "stores" => [
        "file" => [
            "driver" => "file",
            "path" => __DIR__ . "/../storage/cache/advanced",
            "default_ttl" => 3600
        ],
        
        "memory" => [
            "driver" => "array",
            "default_ttl" => 300
        ]
    ],
    
    "query_cache" => [
        "enabled" => true,
        "default_ttl" => 300,
        "max_entries" => 1000
    ],
    
    "api_cache" => [
        "enabled" => true,
        "default_ttl" => 60,
        "max_entries" => 500
    ],
    
    "session_cache" => [
        "enabled" => true,
        "default_ttl" => 1800,
        "max_entries" => 1000
    ],
    
    "static_cache" => [
        "enabled" => true,
        "css_ttl" => 31536000, // 1年
        "js_ttl" => 31536000,  // 1年
        "image_ttl" => 2592000, // 1个月
        "font_ttl" => 31536000  // 1年
    ],
    
    "opcache" => [
        "enabled" => true,
        "config_file" => __DIR__ . "/opcache.ini",
        "preload_file" => __DIR__ . "/preload.php"
    ]
];';
        
        file_put_contents('config/cache.php', $cacheConfig);
        echo "  ✓ 缓存配置已生成: config/cache.php\n";
        echo "✓ 缓存配置生成完成\n\n";
    }
}

// 运行缓存优化器
$optimizer = new CacheOptimizer();
$optimizer->optimize();
