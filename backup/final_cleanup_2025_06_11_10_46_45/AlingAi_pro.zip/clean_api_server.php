<?php

declare(strict_types=1);

/**
 * AlingAi Pro 企业管理系统 API服务器
 * 提供RESTful API接口用于前端调用
 */

// 引入必要的类文件
require_once __DIR__ . '/includes/FileDatabase.php';
require_once __DIR__ . '/includes/EnterpriseManagementService.php';

// 设置CORS头，允许跨域请求
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

// 处理OPTIONS预检请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// 初始化数据库和服务
$dataDir = __DIR__ . '/storage/data';
$db = new FileDatabase($dataDir);
$service = new EnterpriseManagementService($db);

// 获取请求信息
$requestMethod = $_SERVER['REQUEST_METHOD'];
$requestUri = $_SERVER['REQUEST_URI'];
$path = parse_url($requestUri, PHP_URL_PATH);

// 定义路由
$routes = [
    'GET /api/admin/stats' => 'getSystemStats',
    'GET /api/admin/applications' => 'getApplications',
    'POST /api/admin/applications/review' => 'reviewApplication',
    'GET /api/admin/users' => 'getUsers',
    'GET /api/admin/users/details' => 'getUserDetails',
    'POST /api/admin/quota/update' => 'updateQuota',
    'GET /api/admin/enterprise-config' => 'getEnterpriseConfig',
    'POST /api/admin/enterprise-config/update' => 'updateEnterpriseConfig'
];

$route = $requestMethod . ' ' . $path;

// 记录请求日志
error_log("API Request: $route");

// 路由处理
if (isset($routes[$route])) {
    $handler = $routes[$route];
    
    try {
        switch ($handler) {
            case 'getSystemStats':
                $stats = $service->getSystemStats();
                sendJsonResponse(true, $stats);
                break;
                
            case 'getApplications':
                $status = $_GET['status'] ?? null;
                $applications = $status ? 
                    $service->getApplicationsByStatus($status) : 
                    $service->getAllApplications();
                sendJsonResponse(true, $applications);
                break;
                
            case 'reviewApplication':
                $input = getJsonInput();
                $applicationId = (int)($input['applicationId'] ?? 0);
                $status = $input['status'] ?? '';
                $adminNotes = $input['adminNotes'] ?? '';
                
                if ($applicationId && in_array($status, ['approved', 'rejected'])) {
                    $result = $service->reviewApplication($applicationId, $status, $adminNotes);
                    sendJsonResponse($result, null, $result ? '审核完成' : '审核失败');
                } else {
                    sendJsonResponse(false, null, '参数不完整或状态无效');
                }
                break;
                
            case 'getUsers':
                $type = $_GET['type'] ?? 'all';
                $users = $type === 'enterprise' ? 
                    $service->getEnterpriseUsers() : 
                    $service->getAllUsers();
                sendJsonResponse(true, $users);
                break;
                
            case 'getUserDetails':
                $userId = (int)($_GET['userId'] ?? 0);
                if ($userId) {
                    $userDetails = $service->getUserDetails($userId);
                    if ($userDetails) {
                        sendJsonResponse(true, $userDetails);
                    } else {
                        sendJsonResponse(false, null, '用户不存在');
                    }
                } else {
                    sendJsonResponse(false, null, '用户ID不能为空');
                }
                break;
                
            case 'updateQuota':
                $input = getJsonInput();
                $userId = (int)($input['userId'] ?? 0);
                $quotaData = $input['quotaData'] ?? [];
                
                if ($userId && !empty($quotaData)) {
                    $result = $service->updateUserQuota($userId, $quotaData);
                    sendJsonResponse($result, null, $result ? '配额更新成功' : '配额更新失败');
                } else {
                    sendJsonResponse(false, null, '参数不完整');
                }
                break;
                
            case 'getEnterpriseConfig':
                $userId = (int)($_GET['userId'] ?? 0);
                if ($userId) {
                    $config = $service->getEnterpriseConfig($userId);
                    sendJsonResponse(true, $config);
                } else {
                    sendJsonResponse(false, null, '用户ID不能为空');
                }
                break;
                
            case 'updateEnterpriseConfig':
                $input = getJsonInput();
                $userId = (int)($input['userId'] ?? 0);
                $configData = $input['configData'] ?? [];
                
                if ($userId && !empty($configData)) {
                    $result = $service->updateEnterpriseConfig($userId, $configData);
                    sendJsonResponse($result, null, $result ? '配置更新成功' : '配置更新失败');
                } else {
                    sendJsonResponse(false, null, '参数不完整');
                }
                break;
                
            default:
                sendJsonResponse(false, null, '未知的处理器');
        }
    } catch (Exception $e) {
        error_log("API Error: " . $e->getMessage());
        sendJsonResponse(false, null, '服务器内部错误: ' . $e->getMessage());
    }
} else {
    // 如果是请求根路径，返回API文档
    if ($path === '/' || $path === '/api') {
        sendJsonResponse(true, [
            'name' => 'AlingAi Pro 企业管理系统 API',
            'version' => '1.0.0',
            'endpoints' => [
                'GET /api/admin/stats' => '获取系统统计信息',
                'GET /api/admin/applications' => '获取企业申请列表',
                'POST /api/admin/applications/review' => '审核企业申请',
                'GET /api/admin/users' => '获取用户列表',
                'GET /api/admin/users/details' => '获取用户详细信息',
                'POST /api/admin/quota/update' => '更新用户配额',
                'GET /api/admin/enterprise-config' => '获取企业配置',
                'POST /api/admin/enterprise-config/update' => '更新企业配置'
            ],
            'timestamp' => date('Y-m-d H:i:s')
        ]);
    } else {
        http_response_code(404);
        sendJsonResponse(false, null, '接口不存在', ['path' => $path]);
    }
}

/**
 * 发送JSON响应
 */
function sendJsonResponse(bool $success, $data = null, string $message = '', array $extra = []): void {
    $response = ['success' => $success];
    
    if ($data !== null) {
        $response['data'] = $data;
    }
    
    if (!empty($message)) {
        $response['message'] = $message;
    }
    
    if (!empty($extra)) {
        $response = array_merge($response, $extra);
    }
    
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

/**
 * 获取JSON输入数据
 */
function getJsonInput(): array {
    $input = file_get_contents('php://input');
    return $input ? json_decode($input, true) : [];
}
