<?php
/**
 * AlingAi Pro 缓存预热脚本
 * 预加载常用数据以提升系统响应速度
 */

require_once __DIR__ . '/vendor/autoload.php';

use AlingAi\Core\Application;
use AlingAi\Cache\ApplicationCacheManager;
use AlingAi\Services\DatabaseServiceInterface;

echo "🔥 AlingAi Pro 缓存预热器 v1.0\n";
echo "===============================\n\n";

try {
    // 加载环境变量
    if (file_exists(__DIR__ . '/.env')) {
        $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
        $dotenv->load();
    }
    
    echo "1. 初始化应用程序...\n";
    $app = Application::create();
    $container = $app->getContainer();
    
    echo "   ✓ 应用程序初始化成功\n";
    
    echo "2. 获取缓存管理器...\n";
    $cacheManager = $container->get(ApplicationCacheManager::class);
    $dbService = $container->get(DatabaseServiceInterface::class);
    
    echo "   ✓ 缓存管理器获取成功\n";
    
    echo "3. 预热系统配置...\n";
    $systemConfig = $cacheManager->getSystemConfig();
    if ($systemConfig !== null) {
        echo "   ✓ 系统配置已缓存\n";
    } else {
        echo "   ⚠ 系统配置缓存失败\n";
    }
      echo "4. 预热用户数据（最近活跃用户）...\n";
    $warmedUsers = 0;
    
    // 如果是MySQL连接，预热活跃用户
    if (method_exists($dbService, 'query')) {
        try {
            $result = $dbService->query("SELECT id FROM users WHERE updated_at > DATE_SUB(NOW(), INTERVAL 7 DAY) LIMIT 20");
            
            if ($result && is_iterable($result)) {
                foreach ($result as $row) {
                    $userData = $cacheManager->getUserData($row['id'] ?? 1);
                    if ($userData !== null) {
                        $warmedUsers++;
                    }
                }
            }
        } catch (Exception $e) {
            echo "   ⚠ 用户数据预热跳过: " . $e->getMessage() . "\n";
        }
    } else {
        echo "   ⚠ 用户数据预热跳过 (文件存储模式)\n";
    }
    
    echo "   ✓ 已预热 {$warmedUsers} 个用户数据\n";
    
    echo "5. 测试缓存性能...\n";
    $startTime = microtime(true);
    
    // 执行多次缓存读取测试
    for ($i = 0; $i < 100; $i++) {
        $testKey = "performance_test_" . $i;
        $cacheManager->set($testKey, "test_data_" . $i, 300);
        $retrieved = $cacheManager->get($testKey);
    }
    
    $endTime = microtime(true);
    $duration = round(($endTime - $startTime) * 1000, 2);
    
    echo "   ✓ 100次缓存读写操作耗时: {$duration}ms\n";
    
    echo "6. 获取缓存统计信息...\n";
    $stats = $cacheManager->getStats();
    
    echo "   ✓ 内存缓存项: {$stats['memory_cache']['count']}\n";
    echo "   ✓ 文件缓存项: {$stats['file_cache']['cache_count']}\n";
    echo "   ✓ 缓存命中率: {$stats['hit_rate']}%\n";
    echo "   ✓ 总请求数: {$stats['requests']['total_requests']}\n";
    
    echo "7. 清理测试数据...\n";
    for ($i = 0; $i < 100; $i++) {
        $cacheManager->delete("performance_test_" . $i);
    }
    echo "   ✓ 测试数据清理完成\n";
    
    echo "\n✅ 缓存预热完成！\n";
    echo "\n📊 缓存系统性能报告:\n";
    echo "   - 内存缓存: 启用\n";
    echo "   - 文件缓存: 启用\n";
    echo "   - 压缩存储: 启用\n";
    echo "   - 自动清理: 启用\n";
    echo "   - 平均响应: " . round($duration / 100, 2) . "ms/操作\n";
    
    if ($duration < 50) {
        echo "   - 性能评级: ⭐⭐⭐⭐⭐ 优秀\n";
    } elseif ($duration < 100) {
        echo "   - 性能评级: ⭐⭐⭐⭐ 良好\n";
    } elseif ($duration < 200) {
        echo "   - 性能评级: ⭐⭐⭐ 一般\n";
    } else {
        echo "   - 性能评级: ⭐⭐ 需要优化\n";
    }
    
} catch (Exception $e) {
    echo "❌ 缓存预热失败: " . $e->getMessage() . "\n";
    echo "堆栈跟踪:\n" . $e->getTraceAsString() . "\n";
    exit(1);
} catch (Error $e) {
    echo "❌ 系统错误: " . $e->getMessage() . "\n";
    echo "堆栈跟踪:\n" . $e->getTraceAsString() . "\n";
    exit(1);
}
