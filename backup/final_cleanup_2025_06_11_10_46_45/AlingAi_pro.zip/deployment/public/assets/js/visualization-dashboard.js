/**
 * AlingAi 集成检测系统 - 数据可视化仪表板
 * 提供图表、实时监控、性能图表等可视化功能
 * 创建时间: 2025年5月30日
 */

class VisualizationDashboard {
    constructor() {
        this.charts = new Map();
        this.realTimeUpdateInterval = null;
        this.updateFrequency = 1000; // 1秒更新一次
        this.maxDataPoints = 50; // 最大数据点数
        this.isInitialized = false;
        this.chartLibraryLoaded = false;
        
        // 图表颜色主题
        this.colorTheme = {
            primary: '#667eea',
            secondary: '#764ba2',
            success: '#10b981',
            warning: '#f59e0b',
            error: '#ef4444',
            info: '#3b82f6',
            gradient: ['#667eea', '#764ba2', '#f093fb', '#f5576c'],
            background: 'rgba(102, 126, 234, 0.1)'
        };
        
        this.initializeChartLibrary();
    }

    // ==================== 初始化方法 ====================

    async initializeChartLibrary() {
        try {
            // 检查Chart.js是否已加载
            if (typeof Chart !== 'undefined') {
                this.chartLibraryLoaded = true;
                this.setupChartDefaults();
                return;
            }

            // 动态加载Chart.js
            await this.loadChartJS();
            this.chartLibraryLoaded = true;
            this.setupChartDefaults();
            
            console.log('📊 Chart.js库已加载完成');
        } catch (error) {
            console.error('❌ 加载图表库失败:', error);
            this.showFallbackMessage();
        }
    }

    async loadChartJS() {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.js';
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    setupChartDefaults() {
        if (typeof Chart === 'undefined') return;

        Chart.defaults.font.family = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
        Chart.defaults.font.size = 12;
        Chart.defaults.color = '#6b7280';
        Chart.defaults.plugins.legend.position = 'top';
        Chart.defaults.plugins.legend.labels.usePointStyle = true;
        Chart.defaults.responsive = true;
        Chart.defaults.maintainAspectRatio = false;
    }

    // ==================== 主要仪表板方法 ====================

    async initialize(detectionSystem) {
        if (this.isInitialized) return;
        
        this.detectionSystem = detectionSystem;
        
        // 等待图表库加载
        while (!this.chartLibraryLoaded) {
            await this.delay(100);
        }
        
        await this.createDashboardModal();
        this.setupEventListeners();
        this.isInitialized = true;
        
        console.log('📊 数据可视化仪表板已初始化');
    }

    async createDashboardModal() {
        const modalHTML = `
            <div class="modal fade" id="visualizationDashboard" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header bg-gradient text-white">
                            <h5 class="modal-title">
                                <i class="bi bi-graph-up"></i> 数据可视化仪表板
                            </h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            ${this.generateDashboardContent()}
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-primary" onclick="visualizationDashboard.exportCharts()">
                                <i class="bi bi-download"></i> 导出图表
                            </button>
                            <button type="button" class="btn btn-outline-success" onclick="visualizationDashboard.toggleRealTimeUpdate()">
                                <i class="bi bi-arrow-clockwise"></i> <span id="realTimeToggleText">启用实时更新</span>
                            </button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // 移除现有模态框（如果存在）
        const existingModal = document.getElementById('visualizationDashboard');
        if (existingModal) {
            existingModal.remove();
        }
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
    }

    generateDashboardContent() {
        return `
            <div class="container-fluid">
                <!-- 仪表板选项卡 -->
                <ul class="nav nav-tabs mb-3" id="dashboardTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="overview-tab" data-bs-toggle="tab" data-bs-target="#overview-panel" type="button">
                            <i class="bi bi-speedometer2"></i> 总览
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="performance-tab" data-bs-toggle="tab" data-bs-target="#performance-panel" type="button">
                            <i class="bi bi-graph-up"></i> 性能分析
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="trends-tab" data-bs-toggle="tab" data-bs-target="#trends-panel" type="button">
                            <i class="bi bi-activity"></i> 趋势分析
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="realtime-tab" data-bs-toggle="tab" data-bs-target="#realtime-panel" type="button">
                            <i class="bi bi-broadcast"></i> 实时监控
                        </button>
                    </li>
                </ul>
                
                <!-- 选项卡内容 -->
                <div class="tab-content" id="dashboardTabContent">
                    <!-- 总览面板 -->
                    <div class="tab-pane fade show active" id="overview-panel">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card h-100">
                                    <div class="card-header">
                                        <i class="bi bi-pie-chart"></i> 测试结果分布
                                    </div>
                                    <div class="card-body">
                                        <canvas id="testResultsChart" height="300"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card h-100">
                                    <div class="card-header">
                                        <i class="bi bi-bar-chart"></i> 类别成功率
                                    </div>
                                    <div class="card-body">
                                        <canvas id="categorySuccessChart" height="300"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="bi bi-clock-history"></i> 最近测试历史
                                    </div>
                                    <div class="card-body">
                                        <canvas id="recentHistoryChart" height="200"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- 性能分析面板 -->
                    <div class="tab-pane fade" id="performance-panel">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="card h-100">
                                    <div class="card-header">
                                        <i class="bi bi-speedometer"></i> 性能基线对比
                                    </div>
                                    <div class="card-body">
                                        <canvas id="performanceBaselineChart" height="350"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card h-100">
                                    <div class="card-header">
                                        <i class="bi bi-stopwatch"></i> 平均执行时间
                                    </div>
                                    <div class="card-body">
                                        <canvas id="averageTimeChart" height="350"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- 趋势分析面板 -->
                    <div class="tab-pane fade" id="trends-panel">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="bi bi-graph-up-arrow"></i> 成功率趋势
                                    </div>
                                    <div class="card-body">
                                        <canvas id="successRateTrendChart" height="300"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-6">
                                <div class="card h-100">
                                    <div class="card-header">
                                        <i class="bi bi-calendar-week"></i> 每日测试次数
                                    </div>
                                    <div class="card-body">
                                        <canvas id="dailyTestCountChart" height="250"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card h-100">
                                    <div class="card-header">
                                        <i class="bi bi-exclamation-triangle"></i> 错误类型分布
                                    </div>
                                    <div class="card-body">
                                        <canvas id="errorTypeChart" height="250"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- 实时监控面板 -->
                    <div class="tab-pane fade" id="realtime-panel">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="card h-100">
                                    <div class="card-header">
                                        <i class="bi bi-activity"></i> 实时性能监控
                                        <span class="badge bg-success ms-2" id="realTimeStatus">离线</span>
                                    </div>
                                    <div class="card-body">
                                        <canvas id="realTimePerformanceChart" height="300"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card h-100">
                                    <div class="card-header">
                                        <i class="bi bi-cpu"></i> 系统资源使用
                                    </div>
                                    <div class="card-body">
                                        <canvas id="systemResourceChart" height="300"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-header">
                                        <i class="bi bi-lightning"></i> 实时测试状态
                                    </div>
                                    <div class="card-body">
                                        <div id="realTimeTestStatus" class="d-flex flex-wrap gap-2">
                                            <!-- 实时状态将在这里显示 -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // ==================== 图表创建方法 ====================

    createTestResultsChart(data) {
        const ctx = document.getElementById('testResultsChart')?.getContext('2d');
        if (!ctx || typeof Chart === 'undefined') return;

        const chart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['成功', '警告', '失败'],
                datasets: [{
                    data: [data.passed || 0, data.warning || 0, data.failed || 0],
                    backgroundColor: [this.colorTheme.success, this.colorTheme.warning, this.colorTheme.error],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    },
                    tooltip: {
                        callbacks: {
                            afterLabel: (context) => {
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((context.raw / total) * 100).toFixed(1);
                                return `占比: ${percentage}%`;
                            }
                        }
                    }
                }
            }
        });

        this.charts.set('testResults', chart);
        return chart;
    }

    createCategorySuccessChart(data) {
        const ctx = document.getElementById('categorySuccessChart')?.getContext('2d');
        if (!ctx || typeof Chart === 'undefined') return;

        const chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.categories || [],
                datasets: [{
                    label: '成功率 (%)',
                    data: data.successRates || [],
                    backgroundColor: this.colorTheme.primary,
                    borderColor: this.colorTheme.secondary,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        this.charts.set('categorySuccess', chart);
        return chart;
    }

    createRecentHistoryChart(data) {
        const ctx = document.getElementById('recentHistoryChart')?.getContext('2d');
        if (!ctx || typeof Chart === 'undefined') return;

        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.timestamps || [],
                datasets: [{
                    label: '成功率',
                    data: data.successRates || [],
                    borderColor: this.colorTheme.success,
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    fill: true,
                    tension: 0.4
                }, {
                    label: '测试数量',
                    data: data.testCounts || [],
                    borderColor: this.colorTheme.info,
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    fill: false,
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        grid: {
                            drawOnChartArea: false,
                        }
                    }
                }
            }
        });

        this.charts.set('recentHistory', chart);
        return chart;
    }

    createPerformanceBaselineChart(data) {
        const ctx = document.getElementById('performanceBaselineChart')?.getContext('2d');
        if (!ctx || typeof Chart === 'undefined') return;

        const chart = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: data.categories || [],
                datasets: [{
                    label: '当前性能',
                    data: data.currentPerformance || [],
                    borderColor: this.colorTheme.primary,
                    backgroundColor: 'rgba(102, 126, 234, 0.2)',
                    pointBackgroundColor: this.colorTheme.primary
                }, {
                    label: '基线性能',
                    data: data.baselinePerformance || [],
                    borderColor: this.colorTheme.warning,
                    backgroundColor: 'rgba(245, 158, 11, 0.2)',
                    pointBackgroundColor: this.colorTheme.warning
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                elements: {
                    line: {
                        borderWidth: 3
                    }
                },
                scales: {
                    r: {
                        angleLines: {
                            display: false
                        },
                        suggestedMin: 0,
                        suggestedMax: 100
                    }
                }
            }
        });

        this.charts.set('performanceBaseline', chart);
        return chart;
    }

    // ==================== 实时更新方法 ====================

    toggleRealTimeUpdate() {
        if (this.realTimeUpdateInterval) {
            this.stopRealTimeUpdate();
        } else {
            this.startRealTimeUpdate();
        }
    }

    startRealTimeUpdate() {
        if (this.realTimeUpdateInterval) return;

        this.realTimeUpdateInterval = setInterval(() => {
            this.updateRealTimeCharts();
        }, this.updateFrequency);

        const statusBadge = document.getElementById('realTimeStatus');
        const toggleText = document.getElementById('realTimeToggleText');
        
        if (statusBadge) {
            statusBadge.textContent = '在线';
            statusBadge.className = 'badge bg-success ms-2';
        }
        
        if (toggleText) {
            toggleText.textContent = '停止实时更新';
        }

        console.log('📊 实时图表更新已启用');
    }

    stopRealTimeUpdate() {
        if (this.realTimeUpdateInterval) {
            clearInterval(this.realTimeUpdateInterval);
            this.realTimeUpdateInterval = null;
        }

        const statusBadge = document.getElementById('realTimeStatus');
        const toggleText = document.getElementById('realTimeToggleText');
        
        if (statusBadge) {
            statusBadge.textContent = '离线';
            statusBadge.className = 'badge bg-secondary ms-2';
        }
        
        if (toggleText) {
            toggleText.textContent = '启用实时更新';
        }

        console.log('📊 实时图表更新已停止');
    }

    updateRealTimeCharts() {
        if (!this.detectionSystem) return;

        // 更新实时性能图表
        this.updateRealTimePerformanceChart();
          // 更新系统资源图表
        this.updateSystemResourceChart();
        
        // 更新实时测试状态
        this.updateRealTimeTestStatus();
    }

    updateRealTimePerformanceChart() {
        const chart = this.charts.get('realTimePerformance');
        if (!chart) return;

        const realtimeData = this.detectionSystem.getRealtimeData();
        const now = new Date();
        
        // 添加新的数据点
        chart.data.labels.push(now.toLocaleTimeString());
        chart.data.datasets[0].data.push(realtimeData.progress || 0);
        
        // 保持最多20个数据点
        if (chart.data.labels.length > 20) {
            chart.data.labels.shift();
            chart.data.datasets[0].data.shift();
        }
        
        chart.update('none');
    }

    updateSystemResourceChart() {
        const chart = this.charts.get('systemResource');
        if (!chart) return;

        const realtimeData = this.detectionSystem.getRealtimeData();
        const metrics = realtimeData.systemMetrics || {};
        
        // 更新系统资源数据
        const memoryUsage = metrics.memoryUsage ? 
            (metrics.memoryUsage.usedJSHeapSize / metrics.memoryUsage.totalJSHeapSize * 100) : 0;
        
        chart.data.datasets[0].data = [
            memoryUsage,
            Math.random() * 30 + 20, // CPU使用率模拟
            realtimeData.isRunning ? 80 : 20, // 网络活动
            Math.random() * 40 + 10  // 磁盘I/O模拟
        ];
        
        chart.update('none');
    }

    updateRealTimeTestStatus() {
        const statusContainer = document.getElementById('realTimeTestStatus');
        if (!statusContainer) return;

        const realtimeData = this.detectionSystem.getRealtimeData();
        const recentTests = realtimeData.recentTests || [];
        
        statusContainer.innerHTML = recentTests.map(test => {
            const statusClass = {
                'success': 'bg-success',
                'warning': 'bg-warning',
                'error': 'bg-danger'
            }[test.status] || 'bg-secondary';
            
            return `
                <span class="badge ${statusClass} me-2 mb-1">
                    ${test.testName || 'Unknown'}: ${test.status}
                    <small>(${test.duration}ms)</small>
                </span>
            `;
        }).join('');
    }

    // ==================== 数据处理方法 ====================

    generateChartData() {
        if (!this.detectionSystem) return {};

        const history = this.detectionSystem.testHistory || [];
        const results = this.detectionSystem.testResults || new Map();
        const categories = this.detectionSystem.testCategories || {};

        return {
            testResults: this.generateTestResultsData(results),
            categorySuccess: this.generateCategorySuccessData(categories, history),
            recentHistory: this.generateRecentHistoryData(history),
            performanceBaseline: this.generatePerformanceBaselineData(),
            trends: this.generateTrendsData(history)
        };
    }

    generateTestResultsData(results) {
        let passed = 0, warning = 0, failed = 0;

        for (const [key, result] of results) {
            switch (result.status) {
                case 'success': passed++; break;
                case 'warning': warning++; break;
                case 'error': failed++; break;
            }
        }

        return { passed, warning, failed };
    }

    generateCategorySuccessData(categories, history) {
        const categoryStats = {};
        
        Object.keys(categories).forEach(category => {
            categoryStats[category] = { total: 0, success: 0 };
        });

        history.forEach(record => {
            if (categoryStats[record.category]) {
                categoryStats[record.category].total++;
                if (record.status === 'success') {
                    categoryStats[record.category].success++;
                }
            }
        });

        const categoryNames = Object.keys(categoryStats);
        const successRates = categoryNames.map(name => {
            const stats = categoryStats[name];
            return stats.total > 0 ? (stats.success / stats.total * 100).toFixed(1) : 0;
        });

        return {
            categories: categoryNames,
            successRates: successRates
        };
    }

    generateRecentHistoryData(history) {
        const recent = history.slice(-20); // 最近20条记录
        
        const timestamps = recent.map(record => {
            const date = new Date(record.timestamp);
            return date.toLocaleTimeString();
        });

        const successRates = recent.map((_, index) => {
            const subset = recent.slice(0, index + 1);
            const success = subset.filter(r => r.status === 'success').length;
            return subset.length > 0 ? (success / subset.length * 100).toFixed(1) : 0;
        });

        const testCounts = recent.map((_, index) => index + 1);

        return {
            timestamps,
            successRates,
            testCounts
        };
    }

    // ==================== 工具方法 ====================

    show() {
        if (!this.isInitialized) {
            console.warn('⚠️ 可视化仪表板未初始化');
            return;
        }

        const modal = new bootstrap.Modal(document.getElementById('visualizationDashboard'));
        modal.show();

        // 延迟创建图表以确保DOM已渲染
        setTimeout(() => {
            this.refreshAllCharts();
        }, 300);
    }

    refreshAllCharts() {
        const data = this.generateChartData();
        
        this.createTestResultsChart(data.testResults);
        this.createCategorySuccessChart(data.categorySuccess);
        this.createRecentHistoryChart(data.recentHistory);
        this.createPerformanceBaselineChart(data.performanceBaseline);
    }

    setupEventListeners() {
        // 监听标签页切换事件
        const tabButtons = document.querySelectorAll('#dashboardTabs button[data-bs-toggle="tab"]');
        tabButtons.forEach(button => {
            button.addEventListener('shown.bs.tab', (event) => {
                const targetTab = event.target.getAttribute('data-bs-target');
                setTimeout(() => {
                    this.onTabSwitch(targetTab);
                }, 100);
            });
        });
    }

    onTabSwitch(targetTab) {
        // 根据切换的标签页刷新相应图表
        switch (targetTab) {
            case '#performance-panel':
                this.refreshPerformanceCharts();
                break;
            case '#trends-panel':
                this.refreshTrendsCharts();
                break;
            case '#realtime-panel':
                this.refreshRealTimeCharts();
                break;
        }
    }

    exportCharts() {
        const exportData = {
            timestamp: new Date().toISOString(),
            charts: {}
        };

        // 导出每个图表的数据
        this.charts.forEach((chart, name) => {
            exportData.charts[name] = {
                type: chart.config.type,
                data: chart.data,
                options: chart.options
            };
        });

        // 下载JSON文件
        const blob = new Blob([JSON.stringify(exportData, null, 2)], {
            type: 'application/json'
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `visualization-dashboard-${Date.now()}.json`;
        a.click();
        URL.revokeObjectURL(url);

        console.log('📊 图表数据已导出');
    }

    showFallbackMessage() {
        const fallbackHTML = `
            <div class="alert alert-warning" role="alert">
                <i class="bi bi-exclamation-triangle"></i>
                <strong>图表库加载失败</strong><br>
                数据可视化功能需要Chart.js库支持。请检查网络连接或使用文本形式的数据报告。
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', fallbackHTML);
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }    // ==================== 占位方法（待实现） ====================

    refreshPerformanceCharts() {
        console.log('🔄 刷新性能图表...');
        
        if (!this.detectionSystem) return;
        
        const dashboardData = this.detectionSystem.getDashboardData();
        const performanceData = dashboardData.performance;
        
        // 更新性能基线图表
        const baselineChart = this.charts.get('performanceBaseline');
        if (baselineChart && performanceData.baseline) {
            const categories = Object.keys(performanceData.baseline);
            const currentPerformance = categories.map(cat => {
                const baseline = performanceData.baseline[cat];
                return baseline.averageTime || 0;
            });
            const baselinePerformance = categories.map(cat => {
                const baseline = performanceData.baseline[cat];
                return baseline.bestTime || 0;
            });
            
            baselineChart.data.labels = categories;
            baselineChart.data.datasets[0].data = currentPerformance;
            baselineChart.data.datasets[1].data = baselinePerformance;
            baselineChart.update();
        }
    }

    refreshTrendsCharts() {
        console.log('🔄 刷新趋势图表...');
        
        if (!this.detectionSystem) return;
        
        const dashboardData = this.detectionSystem.getDashboardData();
        const trendsData = dashboardData.trends;
        
        // 更新趋势图表
        const historyChart = this.charts.get('recentHistory');
        if (historyChart && trendsData) {
            historyChart.data.labels = trendsData.timestamps;
            historyChart.data.datasets[0].data = trendsData.successRates;
            historyChart.data.datasets[1].data = trendsData.testCounts;
            historyChart.update();
        }
    }

    // ==================== 数据处理方法 ====================

    processOverviewData(overviewData) {
        return {
            testResults: {
                passed: overviewData.passed || 0,
                failed: overviewData.failed || 0,
                warning: overviewData.warning || 0,
                pending: (overviewData.total || 0) - (overviewData.completed || 0)
            },
            categoryStats: overviewData.categoryStats || {},
            successRate: parseFloat(overviewData.successRate) || 0
        };
    }

    processPerformanceData(performanceData) {
        const baseline = performanceData.baseline || {};
        const categories = Object.keys(baseline);
        
        return {
            categories: categories,
            currentPerformance: categories.map(cat => {
                const data = baseline[cat];
                return data && data.averageTime ? Math.min(data.averageTime / 10, 100) : 0;
            }),
            baselinePerformance: categories.map(cat => {
                const data = baseline[cat];
                return data && data.bestTime ? Math.min(data.bestTime / 10, 100) : 0;
            }),
            recentPerformance: performanceData.recentPerformance || []
        };
    }

    processTrendsData(trendsData) {
        return {
            timestamps: trendsData.timestamps || [],
            successRates: trendsData.successRates || [],
            testCounts: trendsData.testCounts || [],
            avgDuration: trendsData.avgDuration || []
        };
    }

    processRealtimeData(realtimeData) {
        return {
            timestamp: realtimeData.timestamp || Date.now(),
            isRunning: realtimeData.isRunning || false,
            progress: realtimeData.currentProgress || 0,
            systemMetrics: realtimeData.systemMetrics || {},
            recentTests: realtimeData.recentTests || []
        };
    }

    refreshRealTimeCharts() {
        // TODO: 实现实时图表刷新
        console.log('🔄 刷新实时图表...');
    }

    updateRealTimePerformanceChart() {
        // TODO: 实现实时性能图表更新
    }

    updateSystemResourceChart() {
        // TODO: 实现系统资源图表更新
    }

    updateRealTimeTestStatus() {
        // TODO: 实现实时测试状态更新
    }

    generatePerformanceBaselineData() {
        // TODO: 实现性能基线数据生成
        return {
            categories: ['后端', '前端', 'WebSocket', '聊天', '性能'],
            currentPerformance: [85, 92, 78, 90, 88],
            baselinePerformance: [80, 85, 75, 85, 85]
        };
    }

    generateTrendsData(history) {
        // TODO: 实现趋势数据生成
        return {};
    }
}

// 创建全局实例
window.visualizationDashboard = new VisualizationDashboard();

// 导出显示函数
window.showVisualizationDashboard = function() {
    if (window.detectionSystem && window.visualizationDashboard) {
        if (!visualizationDashboard.isInitialized) {
            visualizationDashboard.initialize(window.detectionSystem).then(() => {
                visualizationDashboard.show();
            });
        } else {
            visualizationDashboard.show();
        }
    } else {
        console.warn('⚠️ 检测系统或可视化仪表板未就绪');
    }
};

console.log('📊 数据可视化仪表板模块已加载');
