/**
 * AlingAi Pro - WebSocket Client
 * 
 * Real-time communication system with auto-reconnection,
 * message queuing, and comprehensive event handling
 * 
 * @package AlingAi\Frontend\WebSocket
 * @author AlingAi Team
 * @version 2.0.0
 */

class WebSocketClient {
    constructor(url, options = {}) {
        this.url = url;
        this.options = {
            autoReconnect: true,
            reconnectInterval: 5000,
            maxReconnectAttempts: 10,
            heartbeatInterval: 30000,
            messageQueueSize: 100,
            protocols: [],
            debug: false,
            ...options
        };
        
        this.ws = null;
        this.status = 'disconnected'; // disconnected, connecting, connected, reconnecting
        this.reconnectAttempts = 0;
        this.messageQueue = [];
        this.eventHandlers = new Map();
        this.heartbeatTimer = null;
        this.reconnectTimer = null;
        
        this.init();
    }

    init() {
        this.connect();
    }

    connect() {
        if (this.status === 'connecting' || this.status === 'connected') {
            return;
        }
        
        this.status = 'connecting';
        this.emit('connecting');
        
        try {
            this.ws = new WebSocket(this.url, this.options.protocols);
            this.setupEventListeners();
        } catch (error) {
            this.handleError('Connection failed', error);
        }
    }

    setupEventListeners() {
        this.ws.onopen = (event) => {
            this.status = 'connected';
            this.reconnectAttempts = 0;
            this.log('WebSocket connected');
            
            this.startHeartbeat();
            this.processMessageQueue();
            this.emit('connected', event);
        };

        this.ws.onmessage = (event) => {
            this.handleMessage(event);
        };

        this.ws.onclose = (event) => {
            this.status = 'disconnected';
            this.stopHeartbeat();
            this.log('WebSocket disconnected', event.code, event.reason);
            
            this.emit('disconnected', {
                code: event.code,
                reason: event.reason,
                wasClean: event.wasClean
            });
            
            if (this.options.autoReconnect && !event.wasClean) {
                this.scheduleReconnect();
            }
        };

        this.ws.onerror = (event) => {
            this.handleError('WebSocket error', event);
        };
    }

    handleMessage(event) {
        try {
            let data;
            
            // Try to parse as JSON
            try {
                data = JSON.parse(event.data);
            } catch {
                data = event.data;
            }
            
            this.log('Received message:', data);
            
            // Handle heartbeat responses
            if (data && data.type === 'pong') {
                return;
            }
            
            // Emit message event
            this.emit('message', data, event);
            
            // Emit specific event type if available
            if (data && data.type) {
                this.emit(data.type, data.payload || data, event);
            }
            
        } catch (error) {
            this.handleError('Message parsing failed', error);
        }
    }

    send(data, type = null) {
        const message = this.formatMessage(data, type);
        
        if (this.status === 'connected') {
            try {
                this.ws.send(message);
                this.log('Sent message:', data);
                return true;
            } catch (error) {
                this.handleError('Send failed', error);
                this.queueMessage(message);
                return false;
            }
        } else {
            this.queueMessage(message);
            this.log('Message queued (not connected):', data);
            return false;
        }
    }

    formatMessage(data, type) {
        if (typeof data === 'string') {
            return data;
        }
        
        const message = {
            type: type || 'message',
            payload: data,
            timestamp: Date.now(),
            id: this.generateMessageId()
        };
        
        return JSON.stringify(message);
    }

    queueMessage(message) {
        if (this.messageQueue.length >= this.options.messageQueueSize) {
            this.messageQueue.shift(); // Remove oldest message
        }
        this.messageQueue.push(message);
    }

    processMessageQueue() {
        while (this.messageQueue.length > 0 && this.status === 'connected') {
            const message = this.messageQueue.shift();
            try {
                this.ws.send(message);
                this.log('Sent queued message');
            } catch (error) {
                this.handleError('Failed to send queued message', error);
                this.messageQueue.unshift(message); // Put it back
                break;
            }
        }
    }

    startHeartbeat() {
        if (this.options.heartbeatInterval <= 0) return;
        
        this.stopHeartbeat();
        this.heartbeatTimer = setInterval(() => {
            if (this.status === 'connected') {
                this.send({ type: 'ping' });
            }
        }, this.options.heartbeatInterval);
    }

    stopHeartbeat() {
        if (this.heartbeatTimer) {
            clearInterval(this.heartbeatTimer);
            this.heartbeatTimer = null;
        }
    }

    scheduleReconnect() {
        if (this.reconnectAttempts >= this.options.maxReconnectAttempts) {
            this.log('Max reconnection attempts reached');
            this.emit('reconnectFailed');
            return;
        }
        
        this.status = 'reconnecting';
        this.reconnectAttempts++;
        
        const delay = this.calculateReconnectDelay();
        this.log(`Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts})`);
        
        this.emit('reconnecting', {
            attempt: this.reconnectAttempts,
            maxAttempts: this.options.maxReconnectAttempts,
            delay
        });
        
        this.reconnectTimer = setTimeout(() => {
            this.connect();
        }, delay);
    }

    calculateReconnectDelay() {
        // Exponential backoff with jitter
        const baseDelay = this.options.reconnectInterval;
        const exponentialDelay = baseDelay * Math.pow(2, this.reconnectAttempts - 1);
        const maxDelay = 60000; // 1 minute max
        const delay = Math.min(exponentialDelay, maxDelay);
        
        // Add jitter (±25%)
        const jitter = delay * 0.25 * (Math.random() - 0.5);
        return Math.max(1000, delay + jitter);
    }

    close(code = 1000, reason = '') {
        this.options.autoReconnect = false;
        this.stopHeartbeat();
        
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }
        
        if (this.ws && this.ws.readyState !== WebSocket.CLOSED) {
            this.ws.close(code, reason);
        }
        
        this.status = 'disconnected';
    }

    reconnect() {
        this.close();
        this.reconnectAttempts = 0;
        this.options.autoReconnect = true;
        setTimeout(() => this.connect(), 100);
    }

    // Event system
    on(event, handler) {
        if (!this.eventHandlers.has(event)) {
            this.eventHandlers.set(event, []);
        }
        this.eventHandlers.get(event).push(handler);
        
        return () => this.off(event, handler);
    }

    off(event, handler) {
        if (!this.eventHandlers.has(event)) return;
        
        const handlers = this.eventHandlers.get(event);
        const index = handlers.indexOf(handler);
        if (index > -1) {
            handlers.splice(index, 1);
        }
    }

    once(event, handler) {
        const wrapper = (...args) => {
            handler(...args);
            this.off(event, wrapper);
        };
        this.on(event, wrapper);
    }

    emit(event, ...args) {
        if (this.eventHandlers.has(event)) {
            this.eventHandlers.get(event).forEach(handler => {
                try {
                    handler(...args);
                } catch (error) {
                    this.handleError(`Event handler error for ${event}`, error);
                }
            });
        }
    }

    // Utility methods
    isConnected() {
        return this.status === 'connected';
    }

    isConnecting() {
        return this.status === 'connecting';
    }

    isReconnecting() {
        return this.status === 'reconnecting';
    }

    getStatus() {
        return {
            status: this.status,
            reconnectAttempts: this.reconnectAttempts,
            queuedMessages: this.messageQueue.length,
            url: this.url
        };
    }

    generateMessageId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    handleError(message, error) {
        this.log('Error:', message, error);
        this.emit('error', { message, error });
    }

    log(...args) {
        if (this.options.debug) {
            console.log('[WebSocketClient]', ...args);
        }
    }

    // Promise-based methods
    sendAndWait(data, type = null, timeout = 10000) {
        return new Promise((resolve, reject) => {
            const messageId = this.generateMessageId();
            const message = {
                ...data,
                id: messageId
            };
            
            const timeoutId = setTimeout(() => {
                this.off('response', responseHandler);
                reject(new Error('Response timeout'));
            }, timeout);
            
            const responseHandler = (response) => {
                if (response.id === messageId) {
                    clearTimeout(timeoutId);
                    this.off('response', responseHandler);
                    resolve(response);
                }
            };
            
            this.on('response', responseHandler);
            
            if (!this.send(message, type)) {
                clearTimeout(timeoutId);
                this.off('response', responseHandler);
                reject(new Error('Failed to send message'));
            }
        });
    }

    waitForConnection(timeout = 10000) {
        return new Promise((resolve, reject) => {
            if (this.isConnected()) {
                resolve();
                return;
            }
            
            const timeoutId = setTimeout(() => {
                this.off('connected', connectHandler);
                reject(new Error('Connection timeout'));
            }, timeout);
            
            const connectHandler = () => {
                clearTimeout(timeoutId);
                resolve();
            };
            
            this.once('connected', connectHandler);
        });
    }
}

// WebSocket Manager for handling multiple connections
class WebSocketManager {
    constructor() {
        this.connections = new Map();
        this.defaultOptions = {
            autoReconnect: true,
            debug: false
        };
    }

    create(name, url, options = {}) {
        if (this.connections.has(name)) {
            this.connections.get(name).close();
        }
        
        const client = new WebSocketClient(url, {
            ...this.defaultOptions,
            ...options
        });
        
        this.connections.set(name, client);
        return client;
    }

    get(name) {
        return this.connections.get(name);
    }

    remove(name) {
        const client = this.connections.get(name);
        if (client) {
            client.close();
            this.connections.delete(name);
        }
    }

    broadcast(data, type = null) {
        this.connections.forEach(client => {
            if (client.isConnected()) {
                client.send(data, type);
            }
        });
    }

    closeAll() {
        this.connections.forEach(client => client.close());
        this.connections.clear();
    }

    getStatus() {
        const status = {};
        this.connections.forEach((client, name) => {
            status[name] = client.getStatus();
        });
        return status;
    }
}

// Real-time features helper
class RealTimeFeatures {
    constructor(wsClient) {
        this.ws = wsClient;
        this.typingUsers = new Set();
        this.userPresence = new Map();
        
        this.setupEventHandlers();
    }

    setupEventHandlers() {
        // Typing indicators
        this.ws.on('user_typing', (data) => {
            this.typingUsers.add(data.userId);
            this.updateTypingIndicator();
            
            // Auto-remove after timeout
            setTimeout(() => {
                this.typingUsers.delete(data.userId);
                this.updateTypingIndicator();
            }, 3000);
        });

        // User presence
        this.ws.on('user_presence', (data) => {
            this.userPresence.set(data.userId, {
                status: data.status,
                lastSeen: data.lastSeen || Date.now()
            });
            this.updatePresenceIndicators();
        });

        // Real-time notifications
        this.ws.on('notification', (data) => {
            this.showNotification(data);
        });
    }

    // Typing indicators
    startTyping(conversationId) {
        this.ws.send({
            type: 'typing_start',
            conversationId
        });
    }

    stopTyping(conversationId) {
        this.ws.send({
            type: 'typing_stop',
            conversationId
        });
    }

    updateTypingIndicator() {
        const indicator = document.querySelector('.typing-indicator');
        if (!indicator) return;
        
        if (this.typingUsers.size > 0) {
            const users = Array.from(this.typingUsers);
            let text = '';
            
            if (users.length === 1) {
                text = `${users[0]} is typing...`;
            } else if (users.length === 2) {
                text = `${users[0]} and ${users[1]} are typing...`;
            } else {
                text = `${users.length} people are typing...`;
            }
            
            indicator.textContent = text;
            indicator.classList.remove('hidden');
        } else {
            indicator.classList.add('hidden');
        }
    }

    // User presence
    updatePresenceIndicators() {
        this.userPresence.forEach((presence, userId) => {
            const indicator = document.querySelector(`[data-user-id="${userId}"] .presence-indicator`);
            if (indicator) {
                indicator.className = `presence-indicator ${presence.status}`;
                indicator.title = this.getPresenceText(presence);
            }
        });
    }

    getPresenceText(presence) {
        const now = Date.now();
        const diff = now - presence.lastSeen;
        
        switch (presence.status) {
            case 'online':
                return 'Online';
            case 'away':
                return 'Away';
            case 'busy':
                return 'Busy';
            case 'offline':
                if (diff < 60000) return 'Just left';
                if (diff < 3600000) return `Last seen ${Math.floor(diff / 60000)} minutes ago`;
                return 'Offline';
            default:
                return 'Unknown';
        }
    }

    // Real-time notifications
    showNotification(data) {
        if (window.UIManager && window.UIManager.showNotification) {
            window.UIManager.showNotification(data.message, data.type || 'info', {
                persistent: data.persistent,
                actions: data.actions
            });
        }
    }

    // Collaborative features
    joinRoom(roomId) {
        this.ws.send({
            type: 'join_room',
            roomId
        });
    }

    leaveRoom(roomId) {
        this.ws.send({
            type: 'leave_room',
            roomId
        });
    }

    syncCursor(position, selection) {
        this.ws.send({
            type: 'cursor_sync',
            position,
            selection
        });
    }
}

// Auto-initialization
document.addEventListener('DOMContentLoaded', () => {
    // Create global WebSocket manager
    window.wsManager = new WebSocketManager();
    
    // Auto-connect to default endpoint if specified
    const wsEndpoint = document.querySelector('meta[name="websocket-endpoint"]');
    if (wsEndpoint) {
        const url = wsEndpoint.getAttribute('content');
        const defaultWs = window.wsManager.create('default', url, {
            debug: true
        });
        
        // Setup real-time features
        window.realTimeFeatures = new RealTimeFeatures(defaultWs);
        
        // Global access
        window.ws = defaultWs;
    }
});

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        WebSocketClient,
        WebSocketManager,
        RealTimeFeatures
    };
}

// Global access
window.WebSocketClient = WebSocketClient;
window.WebSocketManager = WebSocketManager;
window.RealTimeFeatures = RealTimeFeatures;
