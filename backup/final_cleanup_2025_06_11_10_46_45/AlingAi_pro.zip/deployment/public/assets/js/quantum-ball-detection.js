/**
 * 量子球3D系统检测模块
 * 集成到AlingAi综合全端检测系统
 * 检测量子球API、WebSocket、3D渲染、动画系统等功能
 */

class QuantumBallDetection {
    constructor() {
        this.baseURL = window.location.origin;
        this.apiEndpoints = [
            '/api/quantum/status',
            '/api/quantum/trigger',
            '/api/quantum/presets',
            '/api/quantum/animation',
            '/api/quantum/config',
            '/api/quantum/sync',
            '/api/quantum/analytics',
            '/api/quantum/reset'
        ];
        this.testResults = [];
        this.websocketConnection = null;
        this.animationSystem = null;
    }

    // ==================== 量子球API检测 ====================
    async testQuantumBallAPI() {
        if (window.logInfo) window.logInfo('🌐 开始测试量子球API接口...');
        
        const results = {
            passed: 0,
            failed: 0,
            details: []
        };

        for (const endpoint of this.apiEndpoints) {
            try {
                const response = await fetch(`${this.baseURL}${endpoint}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });

                const isSuccess = response.ok;
                const data = await response.json();
                
                results.details.push({
                    endpoint,
                    status: response.status,
                    success: isSuccess,
                    data: isSuccess ? data : null,
                    error: isSuccess ? null : data.error
                });

                if (isSuccess) {
                    results.passed++;
                    if (window.logSuccess) window.logSuccess(`✅ ${endpoint} - 响应正常`);
                } else {
                    results.failed++;
                    if (window.logError) window.logError(`❌ ${endpoint} - 响应异常: ${response.status}`);
                }
            } catch (error) {
                results.failed++;
                results.details.push({
                    endpoint,
                    status: 'ERROR',
                    success: false,
                    data: null,
                    error: error.message
                });
                if (window.logError) window.logError(`❌ ${endpoint} - 请求失败: ${error.message}`);
            }
        }

        // 更新UI状态
        this.updateTestStatus('quantumBallAPI', results.failed === 0 ? 'success' : 'error');
        
        return results;
    }

    // ==================== WebSocket量子同步检测 ====================
    async testQuantumBallWebSocket() {
        if (window.logInfo) window.logInfo('📡 开始测试WebSocket量子同步...');
        
        return new Promise((resolve) => {
            try {
                const wsURL = `ws://${window.location.host}`;
                this.websocketConnection = new WebSocket(wsURL);
                
                let connectionTested = false;
                const timeout = setTimeout(() => {
                    if (!connectionTested) {
                        this.updateTestStatus('quantumBallWebSocket', 'error');
                        if (window.logError) window.logError('❌ WebSocket连接超时');
                        resolve({ success: false, error: 'Connection timeout' });
                    }
                }, 5000);

                this.websocketConnection.onopen = () => {
                    connectionTested = true;
                    clearTimeout(timeout);
                    
                    // 测试量子球状态同步
                    const testMessage = {
                        type: 'quantum_sync',
                        action: 'trigger_animation',
                        animation: 'pulse',
                        data: { intensity: 0.8, duration: 2000 }
                    };
                    
                    this.websocketConnection.send(JSON.stringify(testMessage));
                    
                    this.updateTestStatus('quantumBallWebSocket', 'success');
                    if (window.logSuccess) window.logSuccess('✅ WebSocket连接成功，量子同步正常');
                    
                    resolve({ success: true, message: 'WebSocket connected and quantum sync tested' });
                };

                this.websocketConnection.onerror = (error) => {
                    connectionTested = true;
                    clearTimeout(timeout);
                    this.updateTestStatus('quantumBallWebSocket', 'error');
                    if (window.logError) window.logError(`❌ WebSocket连接错误: ${error}`);
                    resolve({ success: false, error: error });
                };

                this.websocketConnection.onmessage = (event) => {
                    try {
                        const data = JSON.parse(event.data);
                        if (data.type === 'quantum_sync') {
                            if (window.logInfo) window.logInfo(`📡 收到量子同步消息: ${data.message}`);
                        }
                    } catch (e) {
                        if (window.logWarning) window.logWarning('⚠️ WebSocket消息解析失败');
                    }
                };

            } catch (error) {
                this.updateTestStatus('quantumBallWebSocket', 'error');
                if (window.logError) window.logError(`❌ WebSocket初始化失败: ${error.message}`);
                resolve({ success: false, error: error.message });
            }
        });
    }

    // ==================== 3D渲染引擎检测 ====================
    async test3DRenderingEngine() {
        if (window.logInfo) window.logInfo('🎮 开始测试3D渲染引擎...');
        
        const capabilities = {
            webgl: false,
            webgl2: false,
            extensions: [],
            maxTextureSize: 0,
            renderer: '',
            vendor: ''
        };

        try {
            // 检测WebGL支持
            const canvas = document.createElement('canvas');
            const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
            
            if (gl) {
                capabilities.webgl = true;
                capabilities.renderer = gl.getParameter(gl.RENDERER);
                capabilities.vendor = gl.getParameter(gl.VENDOR);
                capabilities.maxTextureSize = gl.getParameter(gl.MAX_TEXTURE_SIZE);
                
                // 检测WebGL扩展
                const extensions = gl.getSupportedExtensions();
                capabilities.extensions = extensions || [];
                
                if (window.logSuccess) window.logSuccess(`✅ WebGL支持正常 - ${capabilities.renderer}`);
            } else {
                throw new Error('WebGL不支持');
            }

            // 检测WebGL2支持
            const gl2 = canvas.getContext('webgl2');
            if (gl2) {
                capabilities.webgl2 = true;
                if (window.logSuccess) window.logSuccess('✅ WebGL2支持正常');
            }

            // 检测Three.js可用性
            if (typeof THREE !== 'undefined') {
                if (window.logSuccess) window.logSuccess('✅ Three.js库加载正常');
                
                // 创建简单的3D场景测试
                const scene = new THREE.Scene();
                const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
                const renderer = new THREE.WebGLRenderer({ canvas });
                
                // 创建测试几何体
                const geometry = new THREE.SphereGeometry(1, 32, 32);
                const material = new THREE.MeshBasicMaterial({ color: 0x667eea });
                const sphere = new THREE.Mesh(geometry, material);
                scene.add(sphere);
                
                renderer.render(scene, camera);
                
                if (window.logSuccess) window.logSuccess('✅ 3D场景渲染测试成功');
            } else {
                if (window.logWarning) window.logWarning('⚠️ Three.js库未加载');
            }

            this.updateTestStatus('quantumBall3DRendering', 'success');
            return { success: true, capabilities };
            
        } catch (error) {
            this.updateTestStatus('quantumBall3DRendering', 'error');
            if (window.logError) window.logError(`❌ 3D渲染引擎检测失败: ${error.message}`);
            return { success: false, error: error.message, capabilities };
        }
    }

    // ==================== 动画系统测试 ====================
    async testAnimationSystem() {
        if (window.logInfo) window.logInfo('🎭 开始测试量子球动画系统...');
        
        try {
            // 测试动画预设API
            const presetsResponse = await fetch(`${this.baseURL}/api/quantum/presets`);
            const presets = await presetsResponse.json();
            
            if (presets.success && presets.presets) {
                if (window.logSuccess) window.logSuccess(`✅ 动画预设加载成功: ${presets.presets.length}个预设`);
                
                // 测试每个动画预设
                for (const preset of presets.presets.slice(0, 3)) { // 只测试前3个
                    try {
                        const animationResponse = await fetch(`${this.baseURL}/api/quantum/animation`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                animation: preset.name,
                                duration: 1000,
                                intensity: 0.5
                            })
                        });
                        
                        const result = await animationResponse.json();
                        if (result.success) {
                            if (window.logSuccess) window.logSuccess(`✅ 动画预设"${preset.name}"触发成功`);
                        } else {
                            if (window.logWarning) window.logWarning(`⚠️ 动画预设"${preset.name}"触发失败`);
                        }
                    } catch (error) {
                        if (window.logError) window.logError(`❌ 动画预设"${preset.name}"测试失败: ${error.message}`);
                    }
                }
            }

            // 测试CSS动画支持
            const testElement = document.createElement('div');
            testElement.style.animation = 'quantumPulse 1s ease-in-out';
            document.body.appendChild(testElement);
            
            setTimeout(() => {
                document.body.removeChild(testElement);
            }, 100);
            
            if (window.logSuccess) window.logSuccess('✅ CSS动画支持正常');

            this.updateTestStatus('quantumBallAnimations', 'success');
            return { success: true, presets: presets.presets || [] };
            
        } catch (error) {
            this.updateTestStatus('quantumBallAnimations', 'error');
            if (window.logError) window.logError(`❌ 动画系统测试失败: ${error.message}`);
            return { success: false, error: error.message };
        }
    }

    // ==================== 聊天集成测试 ====================
    async testChatIntegration() {
        if (window.logInfo) window.logInfo('💬 开始测试量子球聊天集成...');
        
        try {
            // 检测QuantumChatIntegrator
            if (typeof QuantumChatIntegrator !== 'undefined') {
                if (window.logSuccess) window.logSuccess('✅ QuantumChatIntegrator类已加载');
                
                // 测试聊天事件触发
                const testEvents = [
                    { type: 'message_sent', animation: 'pulse' },
                    { type: 'message_received', animation: 'ripple' },
                    { type: 'typing_start', animation: 'breathing' },
                    { type: 'system_notification', animation: 'alert' }
                ];
                
                for (const event of testEvents) {
                    try {
                        // 模拟聊天事件
                        const response = await fetch(`${this.baseURL}/api/quantum/trigger`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                event: event.type,
                                animation: event.animation,
                                intensity: 0.7
                            })
                        });
                        
                        const result = await response.json();
                        if (result.success) {
                            if (window.logSuccess) window.logSuccess(`✅ 聊天事件"${event.type}"集成正常`);
                        }
                    } catch (error) {
                        if (window.logWarning) window.logWarning(`⚠️ 聊天事件"${event.type}"测试失败`);
                    }
                }
            } else {
                if (window.logWarning) window.logWarning('⚠️ QuantumChatIntegrator未加载');
            }

            this.updateTestStatus('quantumBallChatIntegration', 'success');
            return { success: true };
            
        } catch (error) {
            this.updateTestStatus('quantumBallChatIntegration', 'error');
            if (window.logError) window.logError(`❌ 聊天集成测试失败: ${error.message}`);
            return { success: false, error: error.message };
        }
    }

    // ==================== 性能优化检测 ====================
    async testPerformanceOptimization() {
        if (window.logInfo) window.logInfo('⚡ 开始测试量子球性能优化...');
        
        const metrics = {
            frameRate: 0,
            renderTime: 0,
            memoryUsage: 0,
            gpuInfo: {},
            optimizations: []
        };

        try {
            // 检测性能API支持
            if (performance.now) {
                const startTime = performance.now();
                
                // 模拟渲染负载
                await new Promise(resolve => {
                    let frame = 0;
                    const animate = () => {
                        frame++;
                        if (frame < 60) {
                            requestAnimationFrame(animate);
                        } else {
                            resolve();
                        }
                    };
                    animate();
                });
                
                const endTime = performance.now();
                metrics.renderTime = endTime - startTime;
                metrics.frameRate = 60000 / metrics.renderTime;
                
                if (window.logSuccess) window.logSuccess(`✅ 帧率测试完成: ${metrics.frameRate.toFixed(1)} FPS`);
            }

            // 检测内存使用
            if (performance.memory) {
                metrics.memoryUsage = performance.memory.usedJSHeapSize / 1024 / 1024;
                if (window.logInfo) window.logInfo(`📊 内存使用: ${metrics.memoryUsage.toFixed(2)} MB`);
            }

            // 检测WebGL性能信息
            const canvas = document.createElement('canvas');
            const gl = canvas.getContext('webgl');
            if (gl) {
                const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
                if (debugInfo) {
                    metrics.gpuInfo = {
                        renderer: gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL),
                        vendor: gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL)
                    };
                    if (window.logInfo) window.logInfo(`🎮 GPU信息: ${metrics.gpuInfo.renderer}`);
                }
            }

            // 检测优化特性
            const optimizations = [
                { name: 'requestAnimationFrame', supported: typeof requestAnimationFrame !== 'undefined' },
                { name: 'WebGL', supported: !!gl },
                { name: 'WebGL2', supported: !!canvas.getContext('webgl2') },
                { name: 'Hardware Acceleration', supported: gl && gl.getParameter(gl.RENDERER).includes('GPU') }
            ];

            metrics.optimizations = optimizations;
            
            optimizations.forEach(opt => {
                if (opt.supported) {
                    if (window.logSuccess) window.logSuccess(`✅ ${opt.name} 优化支持正常`);
                } else {
                    if (window.logWarning) window.logWarning(`⚠️ ${opt.name} 优化不支持`);
                }
            });

            this.updateTestStatus('quantumBallPerformance', 'success');
            return { success: true, metrics };
            
        } catch (error) {
            this.updateTestStatus('quantumBallPerformance', 'error');
            if (window.logError) window.logError(`❌ 性能优化检测失败: ${error.message}`);
            return { success: false, error: error.message, metrics };
        }
    }

    // ==================== 综合量子球检测 ====================
    async runFullQuantumBallDetection() {
        if (window.logInfo) window.logInfo('🌟 开始量子球3D系统完整检测...');
        
        const allResults = {
            timestamp: new Date().toISOString(),
            totalTests: 6,
            passedTests: 0,
            results: {}
        };

        try {
            // 依次执行所有测试
            allResults.results.apiTest = await this.testQuantumBallAPI();
            if (allResults.results.apiTest.passed > 0) allResults.passedTests++;

            allResults.results.websocketTest = await this.testQuantumBallWebSocket();
            if (allResults.results.websocketTest.success) allResults.passedTests++;

            allResults.results.renderingTest = await this.test3DRenderingEngine();
            if (allResults.results.renderingTest.success) allResults.passedTests++;

            allResults.results.animationTest = await this.testAnimationSystem();
            if (allResults.results.animationTest.success) allResults.passedTests++;

            allResults.results.chatIntegrationTest = await this.testChatIntegration();
            if (allResults.results.chatIntegrationTest.success) allResults.passedTests++;

            allResults.results.performanceTest = await this.testPerformanceOptimization();
            if (allResults.results.performanceTest.success) allResults.passedTests++;

            // 更新整体状态
            const overallSuccess = allResults.passedTests >= 4; // 至少4个测试通过
            this.updateTestStatus('quantumBallCategory', overallSuccess ? 'success' : 'warning');
            
            if (window.logSuccess) {
                window.logSuccess(`🎯 量子球系统检测完成: ${allResults.passedTests}/${allResults.totalTests} 通过`);
            }

            return allResults;
            
        } catch (error) {
            this.updateTestStatus('quantumBallCategory', 'error');
            if (window.logError) window.logError(`❌ 量子球系统检测失败: ${error.message}`);
            return { success: false, error: error.message };
        }
    }

    // ==================== 工具函数 ====================
    updateTestStatus(testId, status) {
        const element = document.getElementById(testId);
        if (element) {
            // 移除旧状态类
            element.classList.remove('pending', 'running', 'success', 'warning', 'error');
            element.classList.add(status);
            
            // 更新状态徽章
            const badge = element.querySelector('.status-badge');
            if (badge) {
                badge.classList.remove('status-pending', 'status-running', 'status-success', 'status-warning', 'status-error');
                badge.classList.add(`status-${status}`);
                
                const statusText = {
                    pending: '待检测',
                    running: '检测中',
                    success: '通过',
                    warning: '警告',
                    error: '失败'
                };
                badge.textContent = statusText[status] || status;
            }
        }
    }

    // 清理资源
    cleanup() {
        if (this.websocketConnection) {
            this.websocketConnection.close();
            this.websocketConnection = null;
        }
    }
}

// 全局实例
window.quantumBallDetection = new QuantumBallDetection();

// 将量子球检测集成到主检测系统
if (window.detectionSystem) {
    // 扩展主检测系统
    const originalRunFullDetection = window.detectionSystem.runFullDetection;
    if (originalRunFullDetection) {
        window.detectionSystem.runFullDetection = async function() {
            await originalRunFullDetection.call(this);
            
            // 添加量子球检测
            if (window.logInfo) window.logInfo('🌟 启动量子球3D系统检测...');
            await window.quantumBallDetection.runFullQuantumBallDetection();
        };
    }
}

// 导出给全局使用
window.runQuantumBallDetection = () => {
    return window.quantumBallDetection.runFullQuantumBallDetection();
};

console.log('✅ 量子球3D系统检测模块已加载');
