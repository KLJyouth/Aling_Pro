/**
 * 量子球聊天集成演示脚本
 * 展示3D量子球如何与聊天系统实时交互
 */

class QuantumChatDemo {
    constructor() {
        this.isRunning = false;
        this.demoSteps = [
            {
                name: '用户发送消息',
                action: 'userMessageSent',
                message: '你好，AI助手！',
                duration: 2000,
                description: '用户输入消息时，量子球呈现蓝色脉冲效果'
            },
            {
                name: 'AI开始思考',
                action: 'aiThinking',
                message: '',
                duration: 3000,
                description: 'AI处理消息时，量子球显示紫色波动和连接线加速'
            },
            {
                name: 'AI回复消息',
                action: 'aiResponseReceived',
                message: '你好！我是智能助手，有什么可以帮助您的吗？',
                duration: 2000,
                description: 'AI响应时，量子球呈现绿色光芒和光束效果'
            },
            {
                name: '网络错误',
                action: 'chatError',
                message: '网络连接失败',
                duration: 2000,
                description: '出现错误时，量子球显示红色警告和震动效果'
            }
        ];
        this.currentStep = 0;
    }
    
    async startDemo() {
        if (this.isRunning) {
            console.log('演示已在运行中...');
            return;
        }
        
        console.log('🎬 开始量子球聊天集成演示');
        this.isRunning = true;
        this.currentStep = 0;
        
        // 等待量子球集成器就绪
        if (!window.quantumChatIntegrator) {
            console.log('⏳ 等待量子球集成器就绪...');
            await this.waitForIntegrator();
        }
        
        // 创建演示UI
        this.createDemoUI();
        
        // 开始演示循环
        await this.runDemoLoop();
        
        this.isRunning = false;
        console.log('✅ 演示完成');
    }
    
    async waitForIntegrator() {
        return new Promise((resolve) => {
            const checkIntegrator = () => {
                if (window.quantumChatIntegrator) {
                    resolve();
                } else {
                    setTimeout(checkIntegrator, 500);
                }
            };
            checkIntegrator();
        });
    }
    
    createDemoUI() {
        // 创建演示控制面板
        const existingPanel = document.getElementById('quantumDemoPanel');
        if (existingPanel) {
            existingPanel.remove();
        }
        
        const demoPanel = document.createElement('div');
        demoPanel.id = 'quantumDemoPanel';
        demoPanel.style.cssText = `
            position: fixed;
            top: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 20px;
            border-radius: 10px;
            border: 2px solid #6b46c1;
            backdrop-filter: blur(10px);
            z-index: 1000;
            min-width: 300px;
            font-family: system-ui, -apple-system, sans-serif;
        `;
        
        demoPanel.innerHTML = `
            <h3 style="margin: 0 0 15px 0; color: #8b5cf6;">🌌 量子球演示</h3>
            <div id="demoStatus" style="margin-bottom: 15px; font-size: 14px;">准备开始...</div>
            <div id="demoProgress" style="width: 100%; height: 4px; background: #333; border-radius: 2px; margin-bottom: 15px;">
                <div id="demoProgressBar" style="width: 0%; height: 100%; background: linear-gradient(45deg, #6b46c1, #8b5cf6); border-radius: 2px; transition: width 0.3s ease;"></div>
            </div>
            <div style="display: flex; gap: 10px;">
                <button id="demoPause" style="padding: 8px 16px; background: #f59e0b; border: none; border-radius: 5px; color: white; cursor: pointer;">暂停</button>
                <button id="demoStop" style="padding: 8px 16px; background: #ef4444; border: none; border-radius: 5px; color: white; cursor: pointer;">停止</button>
                <button id="demoRestart" style="padding: 8px 16px; background: #10b981; border: none; border-radius: 5px; color: white; cursor: pointer;">重新开始</button>
            </div>
        `;
        
        document.body.appendChild(demoPanel);
        
        // 绑定按钮事件
        document.getElementById('demoPause').onclick = () => this.pauseDemo();
        document.getElementById('demoStop').onclick = () => this.stopDemo();
        document.getElementById('demoRestart').onclick = () => this.restartDemo();
    }
    
    async runDemoLoop() {
        while (this.isRunning && this.currentStep < this.demoSteps.length) {
            const step = this.demoSteps[this.currentStep];
            
            console.log(`🎭 演示步骤 ${this.currentStep + 1}: ${step.name}`);
            this.updateDemoUI(step);
            
            // 触发量子球动画
            await this.executeStep(step);
            
            // 等待动画完成
            await this.sleep(step.duration);
            
            this.currentStep++;
            this.updateProgress();
        }
        
        // 演示完成，重新开始
        if (this.isRunning) {
            this.currentStep = 0;
            await this.sleep(2000); // 暂停2秒后重新开始
            await this.runDemoLoop();
        }
    }
    
    async executeStep(step) {
        try {
            switch (step.action) {
                case 'userMessageSent':
                    if (window.quantumChatIntegrator) {
                        await window.quantumChatIntegrator.triggerUserMessageAnimation(step.message);
                    }
                    break;
                    
                case 'aiThinking':
                    if (window.quantumChatIntegrator) {
                        await window.quantumChatIntegrator.triggerAIThinkingAnimation();
                    }
                    break;
                    
                case 'aiResponseReceived':
                    if (window.quantumChatIntegrator) {
                        await window.quantumChatIntegrator.triggerAIResponseAnimation(step.message);
                    }
                    break;
                    
                case 'chatError':
                    if (window.quantumChatIntegrator) {
                        await window.quantumChatIntegrator.triggerErrorAnimation(new Error(step.message));
                    }
                    break;
            }
        } catch (error) {
            console.error('演示步骤执行失败:', error);
        }
    }
    
    updateDemoUI(step) {
        const statusDiv = document.getElementById('demoStatus');
        if (statusDiv) {
            statusDiv.innerHTML = `
                <div style="font-weight: bold; color: #8b5cf6; margin-bottom: 5px;">${step.name}</div>
                <div style="font-size: 12px; color: #ccc;">${step.description}</div>
                ${step.message ? `<div style="font-size: 12px; color: #10b981; margin-top: 5px; font-style: italic;">"${step.message}"</div>` : ''}
            `;
        }
    }
    
    updateProgress() {
        const progressBar = document.getElementById('demoProgressBar');
        if (progressBar) {
            const progress = ((this.currentStep) / this.demoSteps.length) * 100;
            progressBar.style.width = `${progress}%`;
        }
    }
    
    pauseDemo() {
        this.isRunning = false;
        console.log('⏸️ 演示已暂停');
    }
    
    stopDemo() {
        this.isRunning = false;
        this.currentStep = 0;
        
        const panel = document.getElementById('quantumDemoPanel');
        if (panel) {
            panel.remove();
        }
        
        console.log('⏹️ 演示已停止');
    }
    
    async restartDemo() {
        this.stopDemo();
        await this.sleep(500);
        await this.startDemo();
    }
    
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    // 手动触发单个动画的方法
    async triggerAnimation(action, message = '') {
        const step = this.demoSteps.find(s => s.action === action) || {
            action,
            message,
            duration: 2000,
            name: action,
            description: `手动触发 ${action} 动画`
        };
        
        console.log(`🎯 手动触发动画: ${action}`);
        await this.executeStep(step);
    }
}

// 全局演示实例
window.quantumChatDemo = new QuantumChatDemo();

// 自动检测页面环境并提供适当的演示
document.addEventListener('DOMContentLoaded', () => {
    // 检查是否在首页
    if (window.location.pathname === '/' || window.location.pathname.includes('index.html')) {
        console.log('🏠 检测到首页环境，量子球演示可用');
        
        // 添加快捷键启动演示
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.shiftKey && e.key === 'Q') {
                e.preventDefault();
                window.quantumChatDemo.startDemo();
                console.log('🚀 快捷键启动演示: Ctrl+Shift+Q');
            }
        });
          // 延迟自动启动演示 - 已禁用
        // 使用 window.quantumChatDemo.startDemo() 手动启动演示
        console.log('🎬 量子球演示已就绪，使用 window.quantumChatDemo.startDemo() 手动启动');
        console.log('⌨️ 或使用快捷键: Ctrl+Shift+Q');
        
        /*
        setTimeout(() => {
            if (window.quantumChatIntegrator) {
                console.log('🎬 3秒后自动启动量子球演示，按 Ctrl+Shift+Q 可随时启动');
                setTimeout(() => {
                    window.quantumChatDemo.startDemo();
                }, 3000);
            }
        }, 5000);
        */
    }
    
    // 检查是否在聊天页面
    if (window.location.pathname.includes('chat.html')) {
        console.log('💬 检测到聊天页面环境');
        
        // 为聊天页面添加量子球状态指示器
        setTimeout(() => {
            const statusIndicator = document.createElement('div');
            statusIndicator.className = 'quantum-status-indicator';
            statusIndicator.id = 'quantumStatusIndicator';
            statusIndicator.title = '量子球连接状态';
            document.body.appendChild(statusIndicator);
            
            // 监听集成器状态
            if (window.quantumChatIntegrator) {
                window.quantumChatIntegrator.on('connected', () => {
                    statusIndicator.className = 'quantum-status-indicator';
                });
                
                window.quantumChatIntegrator.on('disconnected', () => {
                    statusIndicator.className = 'quantum-status-indicator disconnected';
                });
                
                window.quantumChatIntegrator.on('quantumBallAnimation', (data) => {
                    if (data.eventType === 'aiThinking') {
                        statusIndicator.className = 'quantum-status-indicator thinking';
                        setTimeout(() => {
                            statusIndicator.className = 'quantum-status-indicator';
                        }, 3000);
                    }
                });
            }
        }, 2000);
    }
    
    // 检查是否在测试页面
    if (window.location.pathname.includes('quantum-test.html')) {
        console.log('🧪 检测到测试页面环境');
        
        // 为测试页面添加快速演示按钮
        setTimeout(() => {
            const testContainer = document.querySelector('.test-container');
            if (testContainer) {
                const demoButton = document.createElement('button');
                demoButton.className = 'test-button';
                demoButton.textContent = '开始完整演示';
                demoButton.style.background = 'linear-gradient(45deg, #10b981, #34d399)';
                demoButton.onclick = () => window.quantumChatDemo.startDemo();
                
                // 插入到测试按钮区域
                const buttonContainer = testContainer.querySelector('.text-center');
                if (buttonContainer) {
                    buttonContainer.appendChild(document.createElement('br'));
                    buttonContainer.appendChild(demoButton);
                }
            }
        }, 1000);
    }
});

// 导出演示类
if (typeof module !== 'undefined' && module.exports) {
    module.exports = QuantumChatDemo;
}

console.log('🎭 量子球聊天集成演示模块已加载');
console.log('💡 使用 window.quantumChatDemo.startDemo() 开始演示');
console.log('⌨️ 首页快捷键: Ctrl+Shift+Q');
