// 最终功能验证脚本 - 手动触发聊天测试
// 在浏览器控制台中运行: runFinalVerification()

console.log('🎯 加载最终功能验证脚本...');

// 延迟执行函数
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// 检查计数器
let checkCount = 0;
const maxChecks = 5;

// 最终验证测试
window.runFinalVerification = async function() {
    console.log('🚀 开始最终功能验证...\n');
    
    let testResults = {
        domCheck: false,
        chatInstance: false,
        guestMode: false,
        messageTest: false,
        uiResponse: false
    };
    
    try {
        // 1. DOM检查
        console.log('1️⃣ 检查核心DOM元素...');
        const coreElements = [
            'messageInput', 'sendButton', 'chatMessages', 
            'guestModeButton', 'userStatus'
        ];
        
        const missingElements = coreElements.filter(id => !document.getElementById(id));
        if (missingElements.length === 0) {
            console.log('   ✅ 所有核心DOM元素存在');
            testResults.domCheck = true;
        } else {
            console.log('   ❌ 缺少元素:', missingElements);
        }
        
        // 2. 聊天实例检查
        console.log('\n2️⃣ 检查聊天实例...');
        if (window.chatInstance && window.chatInstance.core && window.chatInstance.ui && window.chatInstance.api) {
            console.log('   ✅ 聊天实例完整加载');
            testResults.chatInstance = true;
        } else {
            console.log('   ❌ 聊天实例未完全加载');
            console.log('   实例状态:', {
                chatInstance: !!window.chatInstance,
                core: !!(window.chatInstance?.core),
                ui: !!(window.chatInstance?.ui),
                api: !!(window.chatInstance?.api)
            });
        }
        
        // 3. 访客模式激活
        console.log('\n3️⃣ 激活访客模式...');
        localStorage.removeItem('guestMode');
        localStorage.removeItem('token');
        
        const guestBtn = document.getElementById('guestModeButton');
        if (guestBtn) {
            guestBtn.click();
            await delay(500);
            
            const guestModeSet = localStorage.getItem('guestMode') === 'true';
            const userStatus = document.getElementById('userStatus');
            const statusText = userStatus ? userStatus.textContent : '';
            
            if (guestModeSet && statusText.includes('访客')) {
                console.log('   ✅ 访客模式激活成功');
                console.log('   📋 用户状态:', statusText);
                testResults.guestMode = true;
            } else {
                console.log('   ❌ 访客模式激活失败');
                console.log('   localStorage:', localStorage.getItem('guestMode'));
                console.log('   状态文本:', statusText);
            }
        } else {
            console.log('   ❌ 访客模式按钮不存在');
        }
        
        // 4. 消息发送测试
        console.log('\n4️⃣ 测试消息发送...');
        const messageInput = document.getElementById('messageInput');
        const sendButton = document.getElementById('sendButton');
        const chatMessages = document.getElementById('chatMessages');
        
        if (messageInput && sendButton && chatMessages) {
            const initialCount = chatMessages.children.length;
            
            // 输入测试消息
            const testMessage = '你好，这是一条测试消息';
            messageInput.value = testMessage;
            messageInput.dispatchEvent(new Event('input'));
            
            console.log('   📝 输入测试消息:', testMessage);
            console.log('   🔄 点击发送按钮...');
            
            // 点击发送
            sendButton.click();
            
            // 等待处理
            await delay(2000);
            
            const finalCount = chatMessages.children.length;
            const messagesAdded = finalCount > initialCount;
            const inputCleared = messageInput.value === '';
            
            if (messagesAdded && inputCleared) {
                console.log('   ✅ 消息发送成功');
                console.log('   📊 消息数量变化:', initialCount, '→', finalCount);
                testResults.messageTest = true;
                
                // 检查是否有访客模式回复
                const messages = Array.from(chatMessages.children);
                const lastMessages = messages.slice(-2); // 获取最后两条消息
                const hasGuestResponse = lastMessages.some(msg => 
                    msg.textContent && (
                        msg.textContent.includes('访客模式') || 
                        msg.textContent.includes('演示回复') ||
                        msg.textContent.includes('登录')
                    )
                );
                
                if (hasGuestResponse) {
                    console.log('   ✅ 收到访客模式AI回复');
                    testResults.uiResponse = true;
                } else {
                    console.log('   ⚠️ 未检测到访客模式AI回复');
                    console.log('   💬 最新消息内容:', lastMessages.map(m => m.textContent?.substring(0, 50)));
                }
            } else {
                console.log('   ❌ 消息发送失败');
                console.log('   详情:', { messagesAdded, inputCleared, initialCount, finalCount });
            }
        } else {
            console.log('   ❌ 消息相关元素缺失');
        }
        
        // 5. 生成最终报告
        console.log('\n📊 最终验证结果:');
        console.log('================');
        
        const results = [
            { name: 'DOM元素检查', status: testResults.domCheck, icon: testResults.domCheck ? '✅' : '❌' },
            { name: '聊天实例加载', status: testResults.chatInstance, icon: testResults.chatInstance ? '✅' : '❌' },
            { name: '访客模式激活', status: testResults.guestMode, icon: testResults.guestMode ? '✅' : '❌' },
            { name: '消息发送功能', status: testResults.messageTest, icon: testResults.messageTest ? '✅' : '❌' },
            { name: 'AI回复显示', status: testResults.uiResponse, icon: testResults.uiResponse ? '✅' : '❌' }
        ];
        
        results.forEach((result, index) => {
            console.log(`${index + 1}. ${result.icon} ${result.name}`);
        });
        
        const passedTests = results.filter(r => r.status).length;
        const totalTests = results.length;
        const successRate = Math.round((passedTests / totalTests) * 100);
        
        console.log('\n📈 测试统计:');
        console.log(`   通过: ${passedTests}/${totalTests} (${successRate}%)`);
        
        if (successRate >= 80) {
            console.log('\n🎉 聊天页面功能验证通过！');
            console.log('💡 您现在可以正常使用聊天功能了。');
        } else if (successRate >= 60) {
            console.log('\n⚠️ 聊天页面基本可用，但有些功能需要优化。');
        } else {
            console.log('\n❌ 聊天页面存在较多问题，需要进一步调试。');
        }
        
        // 返回结果供后续使用
        return {
            success: successRate >= 80,
            results: testResults,
            successRate,
            details: results
        };
        
    } catch (error) {
        console.error('❌ 验证过程中发生错误:', error);
        return { success: false, error: error.message };
    }
};

// 快速测试访客模式聊天
window.quickChatTest = function() {
    console.log('🚀 快速聊天测试...');
    
    // 确保访客模式
    localStorage.setItem('guestMode', 'true');
    
    const messageInput = document.getElementById('messageInput');
    const sendButton = document.getElementById('sendButton');
    
    if (messageInput && sendButton) {
        messageInput.value = '你好，AlingAi！';
        messageInput.dispatchEvent(new Event('input'));
        
        console.log('📤 发送测试消息...');
        sendButton.click();
        
        console.log('⏱️ 请等待2秒查看结果...');
    } else {
        console.log('❌ 输入元素不存在');
    }
};

// 检查页面就绪状态
function checkPageReady() {
    checkCount++;
    
    const isReady = !!(
        document.getElementById('messageInput') &&
        document.getElementById('sendButton') &&
        window.chatInstance
    );
    
    if (isReady) {
        console.log('✅ 页面已就绪，可以运行测试');
        console.log('💡 运行命令:');
        console.log('   - runFinalVerification() : 完整功能验证');
        console.log('   - quickChatTest() : 快速聊天测试');
        checkCount = 0;
    } else if (checkCount < maxChecks) {        console.log('⏳ 页面尚未完全加载，请稍后重试... (' + checkCount + '/' + maxChecks + ')');
        setTimeout(checkPageReady, 2000);
    } else {
        console.log('⚠️ 页面加载检查已达最大次数，停止重试');
        checkCount = 0;
    }
}

// 页面加载完成后自动检查
if (document.readyState === 'complete') {
    setTimeout(checkPageReady, 500);
} else {
    window.addEventListener('load', () => setTimeout(checkPageReady, 500));
}

console.log('✅ 最终验证脚本加载完成!');
