/**
 * AlingAi Pro - 高级搜索和过滤系统
 * 提供强大的实时搜索、高级过滤、智能建议和模糊匹配功能
 * @version 1.0.0
 * @author AlingAi Team
 */

class SearchAndFilterSystem {
    constructor(options = {}) {
        this.options = {
            // 基础配置
            container: options.container || '.search-container',
            dataSource: options.dataSource || [],
            searchFields: options.searchFields || ['title', 'content'],
            resultContainer: options.resultContainer || '.search-results',
            
            // 搜索配置
            minSearchLength: options.minSearchLength || 2,
            maxResults: options.maxResults || 50,
            debounceDelay: options.debounceDelay || 300,
            caseSensitive: options.caseSensitive || false,
            
            // 功能开关
            enableFuzzySearch: options.enableFuzzySearch !== false,
            enableHighlight: options.enableHighlight !== false,
            enableAutocomplete: options.enableAutocomplete !== false,
            enableVoiceSearch: options.enableVoiceSearch || false,
            enableSearchHistory: options.enableSearchHistory !== false,
            enableAdvancedFilters: options.enableAdvancedFilters !== false,
            
            // 渲染配置
            resultTemplate: options.resultTemplate || null,
            noResultsTemplate: options.noResultsTemplate || null,
            loadingTemplate: options.loadingTemplate || null,
            
            // 回调函数
            onSearch: options.onSearch || null,
            onSelect: options.onSelect || null,
            onFilter: options.onFilter || null,
            
            ...options
        };

        this.currentQuery = '';
        this.currentFilters = new Map();
        this.searchHistory = new Set();
        this.searchCache = new Map();
        this.abortController = null;
        this.isInitialized = false;
        
        this.speechRecognition = null;
        this.isListening = false;

        this.init();
    }

    /**
     * 初始化搜索系统
     */
    init() {
        this.loadSearchHistory();
        this.createSearchInterface();
        this.setupEventListeners();
        this.initializeVoiceSearch();
        this.setupGlobalStyles();
        this.isInitialized = true;
    }

    /**
     * 创建搜索界面
     */
    createSearchInterface() {
        const container = typeof this.options.container === 'string' 
            ? document.querySelector(this.options.container) 
            : this.options.container;

        if (!container) {
            console.error('Search container not found');
            return;
        }

        container.innerHTML = `
            <div class="search-system">
                <div class="search-input-wrapper">
                    <div class="search-input-container">
                        <input type="text" 
                               class="search-input" 
                               placeholder="搜索内容..."
                               autocomplete="off"
                               spellcheck="false">
                        <div class="search-actions">
                            ${this.options.enableVoiceSearch ? `
                                <button class="voice-search-btn" type="button" title="语音搜索">
                                    <span class="voice-icon">🎙️</span>
                                </button>
                            ` : ''}
                            <button class="search-clear-btn" type="button" title="清除">
                                <span class="clear-icon">×</span>
                            </button>
                            ${this.options.enableAdvancedFilters ? `
                                <button class="filter-toggle-btn" type="button" title="高级过滤">
                                    <span class="filter-icon">⚙️</span>
                                </button>
                            ` : ''}
                        </div>
                    </div>
                    
                    ${this.options.enableAutocomplete ? `
                        <div class="search-suggestions" style="display: none;">
                            <div class="suggestions-list"></div>
                        </div>
                    ` : ''}
                </div>

                ${this.options.enableAdvancedFilters ? `
                    <div class="advanced-filters" style="display: none;">
                        <div class="filter-section">
                            <h4>高级过滤选项</h4>
                            <div class="filter-controls">
                                <div class="filter-group">
                                    <label>搜索范围:</label>
                                    <select class="search-scope">
                                        <option value="all">全部内容</option>
                                        <option value="title">仅标题</option>
                                        <option value="content">仅内容</option>
                                        <option value="tags">仅标签</option>
                                    </select>
                                </div>
                                
                                <div class="filter-group">
                                    <label>排序方式:</label>
                                    <select class="sort-order">
                                        <option value="relevance">相关性</option>
                                        <option value="date">日期</option>
                                        <option value="title">标题</option>
                                        <option value="size">大小</option>
                                    </select>
                                </div>
                                
                                <div class="filter-group">
                                    <label>结果数量:</label>
                                    <select class="result-limit">
                                        <option value="10">10</option>
                                        <option value="25">25</option>
                                        <option value="50">50</option>
                                        <option value="100">100</option>
                                    </select>
                                </div>
                                
                                <div class="filter-group">
                                    <label>
                                        <input type="checkbox" class="case-sensitive"> 
                                        区分大小写
                                    </label>
                                </div>
                                
                                <div class="filter-group">
                                    <label>
                                        <input type="checkbox" class="exact-match"> 
                                        精确匹配
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                ` : ''}

                <div class="search-status">
                    <div class="search-info"></div>
                    <div class="search-loading" style="display: none;">
                        <span class="loading-spinner"></span> 搜索中...
                    </div>
                </div>

                <div class="search-results"></div>
            </div>
        `;

        this.elements = {
            container: container.querySelector('.search-system'),
            input: container.querySelector('.search-input'),
            suggestions: container.querySelector('.search-suggestions'),
            suggestionsList: container.querySelector('.suggestions-list'),
            advancedFilters: container.querySelector('.advanced-filters'),
            results: container.querySelector('.search-results'),
            status: container.querySelector('.search-status'),
            info: container.querySelector('.search-info'),
            loading: container.querySelector('.search-loading'),
            clearBtn: container.querySelector('.search-clear-btn'),
            voiceBtn: container.querySelector('.voice-search-btn'),
            filterBtn: container.querySelector('.filter-toggle-btn')
        };
    }

    /**
     * 设置全局样式
     */
    setupGlobalStyles() {
        if (document.getElementById('search-filter-styles')) return;

        const styles = document.createElement('style');
        styles.id = 'search-filter-styles';
        styles.textContent = `
            .search-system {
                position: relative;
                width: 100%;
                max-width: 800px;
                margin: 0 auto;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
            }

            .search-input-wrapper {
                position: relative;
                margin-bottom: 16px;
            }

            .search-input-container {
                position: relative;
                display: flex;
                align-items: center;
                background: linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05));
                border: 2px solid rgba(255,255,255,0.2);
                border-radius: 12px;
                backdrop-filter: blur(10px);
                transition: all 0.3s ease;
            }

            .search-input-container:focus-within {
                border-color: rgba(100, 200, 255, 0.6);
                box-shadow: 0 8px 32px rgba(100, 200, 255, 0.2);
                transform: translateY(-2px);
            }

            .search-input {
                flex: 1;
                padding: 16px 20px;
                border: none;
                background: transparent;
                color: #333;
                font-size: 16px;
                outline: none;
                border-radius: 12px;
            }

            .search-input::placeholder {
                color: rgba(0,0,0,0.5);
            }

            .search-actions {
                display: flex;
                align-items: center;
                gap: 8px;
                padding-right: 12px;
            }

            .search-actions button {
                width: 36px;
                height: 36px;
                border: none;
                background: rgba(255,255,255,0.1);
                color: #666;
                border-radius: 8px;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: all 0.2s ease;
                font-size: 14px;
            }

            .search-actions button:hover {
                background: rgba(255,255,255,0.2);
                color: #333;
                transform: scale(1.05);
            }

            .voice-search-btn.listening {
                background: linear-gradient(135deg, #ef4444, #dc2626);
                color: white;
                animation: pulse 1s infinite;
            }

            @keyframes pulse {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(1.1); }
            }

            .search-suggestions {
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: white;
                border: 1px solid rgba(0,0,0,0.1);
                border-radius: 8px;
                box-shadow: 0 8px 32px rgba(0,0,0,0.1);
                backdrop-filter: blur(10px);
                z-index: 1000;
                max-height: 300px;
                overflow-y: auto;
            }

            .suggestion-item {
                padding: 12px 16px;
                border-bottom: 1px solid rgba(0,0,0,0.05);
                cursor: pointer;
                transition: background 0.2s ease;
                display: flex;
                align-items: center;
                gap: 12px;
            }

            .suggestion-item:hover,
            .suggestion-item.selected {
                background: rgba(100, 200, 255, 0.1);
            }

            .suggestion-item:last-child {
                border-bottom: none;
            }

            .suggestion-icon {
                width: 20px;
                height: 20px;
                opacity: 0.6;
            }

            .suggestion-text {
                flex: 1;
            }

            .suggestion-type {
                font-size: 12px;
                color: #666;
                background: rgba(0,0,0,0.05);
                padding: 2px 8px;
                border-radius: 4px;
            }

            .advanced-filters {
                background: linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05));
                border: 1px solid rgba(255,255,255,0.2);
                border-radius: 8px;
                padding: 20px;
                margin-bottom: 16px;
                backdrop-filter: blur(10px);
            }

            .filter-section h4 {
                margin: 0 0 16px 0;
                color: #333;
                font-size: 16px;
                font-weight: 600;
            }

            .filter-controls {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 16px;
            }

            .filter-group {
                display: flex;
                flex-direction: column;
                gap: 8px;
            }

            .filter-group label {
                font-size: 14px;
                font-weight: 500;
                color: #555;
                display: flex;
                align-items: center;
                gap: 8px;
            }

            .filter-group select,
            .filter-group input[type="text"] {
                padding: 8px 12px;
                border: 1px solid rgba(0,0,0,0.2);
                border-radius: 6px;
                background: rgba(255,255,255,0.8);
                font-size: 14px;
                transition: all 0.2s ease;
            }

            .filter-group select:focus,
            .filter-group input[type="text"]:focus {
                outline: none;
                border-color: rgba(100, 200, 255, 0.6);
                box-shadow: 0 0 0 2px rgba(100, 200, 255, 0.2);
            }

            .search-status {
                margin-bottom: 16px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                min-height: 24px;
            }

            .search-info {
                font-size: 14px;
                color: #666;
            }

            .search-loading {
                display: flex;
                align-items: center;
                gap: 8px;
                font-size: 14px;
                color: #666;
            }

            .loading-spinner {
                width: 16px;
                height: 16px;
                border: 2px solid #ddd;
                border-top: 2px solid #666;
                border-radius: 50%;
                animation: spin 1s linear infinite;
            }

            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }

            .search-results {
                min-height: 100px;
            }

            .search-result-item {
                background: white;
                border: 1px solid rgba(0,0,0,0.1);
                border-radius: 8px;
                padding: 16px;
                margin-bottom: 12px;
                transition: all 0.2s ease;
                cursor: pointer;
            }

            .search-result-item:hover {
                box-shadow: 0 4px 16px rgba(0,0,0,0.1);
                transform: translateY(-1px);
            }

            .result-title {
                font-size: 16px;
                font-weight: 600;
                color: #333;
                margin-bottom: 8px;
                line-height: 1.4;
            }

            .result-content {
                font-size: 14px;
                color: #666;
                line-height: 1.5;
                margin-bottom: 8px;
            }

            .result-meta {
                display: flex;
                justify-content: space-between;
                align-items: center;
                font-size: 12px;
                color: #999;
            }

            .result-tags {
                display: flex;
                gap: 4px;
            }

            .result-tag {
                background: rgba(100, 200, 255, 0.1);
                color: rgba(100, 200, 255, 0.8);
                padding: 2px 8px;
                border-radius: 4px;
                font-size: 11px;
            }

            .search-highlight {
                background: linear-gradient(135deg, #fbbf24, #f59e0b);
                color: white;
                padding: 1px 3px;
                border-radius: 3px;
                font-weight: 600;
            }

            .no-results {
                text-align: center;
                padding: 40px 20px;
                color: #666;
            }

            .no-results-icon {
                font-size: 48px;
                margin-bottom: 16px;
                opacity: 0.5;
            }

            .no-results-title {
                font-size: 18px;
                font-weight: 600;
                margin-bottom: 8px;
            }

            .no-results-message {
                font-size: 14px;
                line-height: 1.5;
            }

            /* 响应式设计 */
            @media (max-width: 768px) {
                .search-system {
                    padding: 0 16px;
                }

                .filter-controls {
                    grid-template-columns: 1fr;
                }

                .search-status {
                    flex-direction: column;
                    gap: 8px;
                    align-items: flex-start;
                }

                .search-input {
                    font-size: 16px; /* 防止iOS缩放 */
                }
            }

            /* 量子主题 */
            .search-system.quantum-theme .search-input-container {
                background: linear-gradient(135deg, 
                    rgba(20, 50, 120, 0.1), 
                    rgba(50, 20, 120, 0.1),
                    rgba(120, 20, 80, 0.1)
                );
                border-color: rgba(100, 200, 255, 0.3);
            }

            .search-system.quantum-theme .search-result-item {
                background: linear-gradient(135deg, 
                    rgba(255, 255, 255, 0.9), 
                    rgba(240, 248, 255, 0.9)
                );
                border-color: rgba(100, 200, 255, 0.2);
            }
        `;
        
        document.head.appendChild(styles);
    }

    /**
     * 设置事件监听器
     */
    setupEventListeners() {
        if (!this.elements.input) return;

        // 搜索输入事件
        this.elements.input.addEventListener('input', this.debounce((e) => {
            this.handleSearch(e.target.value);
        }, this.options.debounceDelay));

        // 键盘导航
        this.elements.input.addEventListener('keydown', (e) => {
            this.handleKeyNavigation(e);
        });

        // 清除按钮
        if (this.elements.clearBtn) {
            this.elements.clearBtn.addEventListener('click', () => {
                this.clearSearch();
            });
        }

        // 语音搜索按钮
        if (this.elements.voiceBtn) {
            this.elements.voiceBtn.addEventListener('click', () => {
                this.toggleVoiceSearch();
            });
        }

        // 过滤器切换按钮
        if (this.elements.filterBtn) {
            this.elements.filterBtn.addEventListener('click', () => {
                this.toggleAdvancedFilters();
            });
        }

        // 过滤器变化事件
        if (this.elements.advancedFilters) {
            this.elements.advancedFilters.addEventListener('change', (e) => {
                this.handleFilterChange(e);
            });
        }

        // 点击外部关闭建议
        document.addEventListener('click', (e) => {
            if (!this.elements.container.contains(e.target)) {
                this.hideSuggestions();
            }
        });

        // 结果点击事件
        this.elements.results.addEventListener('click', (e) => {
            const resultItem = e.target.closest('.search-result-item');
            if (resultItem) {
                this.handleResultClick(resultItem);
            }
        });
    }

    /**
     * 初始化语音搜索
     */
    initializeVoiceSearch() {
        if (!this.options.enableVoiceSearch) return;

        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.speechRecognition = new SpeechRecognition();
            
            this.speechRecognition.continuous = false;
            this.speechRecognition.interimResults = false;
            this.speechRecognition.lang = 'zh-CN';

            this.speechRecognition.onstart = () => {
                this.isListening = true;
                this.elements.voiceBtn.classList.add('listening');
                this.showStatus('正在监听...');
            };

            this.speechRecognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                this.elements.input.value = transcript;
                this.handleSearch(transcript);
            };

            this.speechRecognition.onend = () => {
                this.isListening = false;
                this.elements.voiceBtn.classList.remove('listening');
                this.hideStatus();
            };

            this.speechRecognition.onerror = (event) => {
                this.isListening = false;
                this.elements.voiceBtn.classList.remove('listening');
                this.showStatus('语音识别出错', 'error');
            };
        } else {
            // 隐藏语音搜索按钮
            if (this.elements.voiceBtn) {
                this.elements.voiceBtn.style.display = 'none';
            }
        }
    }

    /**
     * 处理搜索
     */
    async handleSearch(query) {
        this.currentQuery = query.trim();

        if (this.currentQuery.length < this.options.minSearchLength) {
            this.clearResults();
            this.hideSuggestions();
            return;
        }

        // 取消之前的搜索
        if (this.abortController) {
            this.abortController.abort();
        }
        this.abortController = new AbortController();

        this.showLoading();

        try {
            // 检查缓存
            const cacheKey = this.getCacheKey(this.currentQuery, this.currentFilters);
            if (this.searchCache.has(cacheKey)) {
                const cachedResults = this.searchCache.get(cacheKey);
                this.displayResults(cachedResults);
                this.hideLoading();
                return;
            }

            // 执行搜索
            const results = await this.performSearch(this.currentQuery, this.currentFilters);
            
            // 缓存结果
            this.searchCache.set(cacheKey, results);
            
            // 显示结果
            this.displayResults(results);
            
            // 更新搜索历史
            if (this.options.enableSearchHistory) {
                this.addToSearchHistory(this.currentQuery);
            }

            // 显示自动完成建议
            if (this.options.enableAutocomplete && this.currentQuery.length >= 2) {
                this.showSuggestions(this.currentQuery);
            }

            // 触发搜索回调
            if (this.options.onSearch) {
                this.options.onSearch(this.currentQuery, results, this.currentFilters);
            }

        } catch (error) {
            if (error.name !== 'AbortError') {
                console.error('Search error:', error);
                this.showError('搜索时发生错误');
            }
        } finally {
            this.hideLoading();
        }
    }

    /**
     * 执行搜索
     */
    async performSearch(query, filters) {
        // 如果有自定义数据源
        if (typeof this.options.dataSource === 'function') {
            return await this.options.dataSource(query, filters);
        }

        // 本地搜索
        if (Array.isArray(this.options.dataSource)) {
            return this.searchLocalData(query, filters);
        }

        // API搜索
        if (typeof this.options.dataSource === 'string') {
            return await this.searchAPI(query, filters);
        }

        return [];
    }

    /**
     * 本地数据搜索
     */
    searchLocalData(query, filters) {
        let results = [...this.options.dataSource];

        // 应用过滤器
        results = this.applyFilters(results, filters);

        // 执行搜索
        const searchTerms = query.toLowerCase().split(/\s+/);
        
        results = results.map(item => {
            let score = 0;
            let matches = [];

            for (const field of this.options.searchFields) {
                const fieldValue = this.getNestedValue(item, field);
                if (fieldValue) {
                    const fieldText = String(fieldValue).toLowerCase();
                    
                    for (const term of searchTerms) {
                        if (this.options.enableFuzzySearch) {
                            const fuzzyScore = this.fuzzyMatch(term, fieldText);
                            if (fuzzyScore > 0.6) {
                                score += fuzzyScore * (field === 'title' ? 2 : 1);
                                matches.push({ field, term, type: 'fuzzy', score: fuzzyScore });
                            }
                        } else {
                            if (fieldText.includes(term)) {
                                const exactBonus = fieldText === term ? 2 : 1;
                                score += exactBonus * (field === 'title' ? 2 : 1);
                                matches.push({ field, term, type: 'exact', bonus: exactBonus });
                            }
                        }
                    }
                }
            }

            return score > 0 ? { ...item, _searchScore: score, _searchMatches: matches } : null;
        }).filter(Boolean);

        // 排序结果
        results.sort((a, b) => b._searchScore - a._searchScore);

        // 限制结果数量
        return results.slice(0, this.options.maxResults);
    }

    /**
     * API搜索
     */
    async searchAPI(query, filters) {
        const params = new URLSearchParams({
            q: query,
            limit: this.options.maxResults,
            ...this.filtersToParams(filters)
        });

        const response = await fetch(`${this.options.dataSource}?${params}`, {
            signal: this.abortController.signal
        });

        if (!response.ok) {
            throw new Error(`Search API error: ${response.status}`);
        }

        const data = await response.json();
        return data.results || data.items || data;
    }

    /**
     * 应用过滤器
     */
    applyFilters(results, filters) {
        if (!filters || filters.size === 0) return results;

        return results.filter(item => {
            for (const [key, value] of filters.entries()) {
                const itemValue = this.getNestedValue(item, key);
                
                if (value.type === 'exact' && itemValue !== value.value) {
                    return false;
                }
                
                if (value.type === 'range') {
                    const numValue = Number(itemValue);
                    if (numValue < value.min || numValue > value.max) {
                        return false;
                    }
                }
                
                if (value.type === 'contains' && !String(itemValue).toLowerCase().includes(String(value.value).toLowerCase())) {
                    return false;
                }
                
                if (value.type === 'date') {
                    const itemDate = new Date(itemValue);
                    const filterDate = new Date(value.value);
                    if (itemDate.toDateString() !== filterDate.toDateString()) {
                        return false;
                    }
                }
            }
            return true;
        });
    }

    /**
     * 模糊匹配算法
     */
    fuzzyMatch(needle, haystack) {
        const needleLength = needle.length;
        const haystackLength = haystack.length;
        
        if (needleLength === 0) return 1;
        if (haystackLength === 0) return 0;

        const matrix = Array(needleLength + 1).fill(null).map(() => Array(haystackLength + 1).fill(0));

        for (let i = 0; i <= needleLength; i++) matrix[i][0] = i;
        for (let j = 0; j <= haystackLength; j++) matrix[0][j] = j;

        for (let i = 1; i <= needleLength; i++) {
            for (let j = 1; j <= haystackLength; j++) {
                const cost = needle[i - 1] === haystack[j - 1] ? 0 : 1;
                matrix[i][j] = Math.min(
                    matrix[i - 1][j] + 1,      // deletion
                    matrix[i][j - 1] + 1,      // insertion
                    matrix[i - 1][j - 1] + cost // substitution
                );
            }
        }

        const distance = matrix[needleLength][haystackLength];
        return 1 - distance / Math.max(needleLength, haystackLength);
    }

    /**
     * 显示搜索结果
     */
    displayResults(results) {
        if (!results || results.length === 0) {
            this.showNoResults();
            return;
        }

        this.showInfo(`找到 ${results.length} 个结果`);

        const html = results.map(item => {
            if (this.options.resultTemplate) {
                return this.options.resultTemplate(item, this.currentQuery);
            }
            return this.defaultResultTemplate(item);
        }).join('');

        this.elements.results.innerHTML = html;
    }

    /**
     * 默认结果模板
     */
    defaultResultTemplate(item) {
        const title = this.highlightText(item.title || item.name || '无标题', this.currentQuery);
        const content = this.highlightText(this.truncateText(item.content || item.description || '', 200), this.currentQuery);
        const tags = item.tags ? item.tags.map(tag => `<span class="result-tag">${tag}</span>`).join('') : '';
        const date = item.date ? new Date(item.date).toLocaleDateString() : '';

        return `
            <div class="search-result-item" data-item='${JSON.stringify(item)}'>
                <div class="result-title">${title}</div>
                <div class="result-content">${content}</div>
                <div class="result-meta">
                    <div class="result-tags">${tags}</div>
                    <div class="result-date">${date}</div>
                </div>
            </div>
        `;
    }

    /**
     * 高亮搜索关键词
     */
    highlightText(text, query) {
        if (!this.options.enableHighlight || !query) return text;

        const terms = query.toLowerCase().split(/\s+/);
        let highlightedText = text;

        terms.forEach(term => {
            const regex = new RegExp(`(${this.escapeRegex(term)})`, 'gi');
            highlightedText = highlightedText.replace(regex, '<span class="search-highlight">$1</span>');
        });

        return highlightedText;
    }

    /**
     * 显示建议
     */
    showSuggestions(query) {
        if (!this.options.enableAutocomplete || !this.elements.suggestions) return;

        const suggestions = this.generateSuggestions(query);
        if (suggestions.length === 0) {
            this.hideSuggestions();
            return;
        }

        const html = suggestions.map((suggestion, index) => `
            <div class="suggestion-item ${index === 0 ? 'selected' : ''}" data-suggestion="${suggestion.text}">
                <span class="suggestion-icon">${suggestion.icon}</span>
                <span class="suggestion-text">${this.highlightText(suggestion.text, query)}</span>
                <span class="suggestion-type">${suggestion.type}</span>
            </div>
        `).join('');

        this.elements.suggestionsList.innerHTML = html;
        this.elements.suggestions.style.display = 'block';

        // 绑定建议点击事件
        this.elements.suggestionsList.addEventListener('click', (e) => {
            const suggestionItem = e.target.closest('.suggestion-item');
            if (suggestionItem) {
                const suggestion = suggestionItem.dataset.suggestion;
                this.elements.input.value = suggestion;
                this.handleSearch(suggestion);
                this.hideSuggestions();
            }
        });
    }

    /**
     * 生成搜索建议
     */
    generateSuggestions(query) {
        const suggestions = [];

        // 搜索历史建议
        if (this.options.enableSearchHistory) {
            Array.from(this.searchHistory)
                .filter(term => term.toLowerCase().includes(query.toLowerCase()) && term !== query)
                .slice(0, 3)
                .forEach(term => {
                    suggestions.push({
                        text: term,
                        type: '历史',
                        icon: '🕐'
                    });
                });
        }

        // 自动完成建议
        if (Array.isArray(this.options.dataSource)) {
            const autoComplete = this.options.dataSource
                .filter(item => {
                    const searchableText = this.options.searchFields
                        .map(field => this.getNestedValue(item, field))
                        .join(' ')
                        .toLowerCase();
                    return searchableText.includes(query.toLowerCase());
                })
                .slice(0, 5)
                .map(item => ({
                    text: item.title || item.name || String(item),
                    type: '内容',
                    icon: '📄'
                }));

            suggestions.push(...autoComplete);
        }

        return suggestions.slice(0, 8);
    }

    /**
     * 键盘导航处理
     */
    handleKeyNavigation(e) {
        if (!this.elements.suggestions || this.elements.suggestions.style.display === 'none') return;

        const suggestions = this.elements.suggestions.querySelectorAll('.suggestion-item');
        const currentSelected = this.elements.suggestions.querySelector('.suggestion-item.selected');
        let selectedIndex = currentSelected ? Array.from(suggestions).indexOf(currentSelected) : -1;

        switch (e.key) {
            case 'ArrowDown':
                e.preventDefault();
                selectedIndex = Math.min(selectedIndex + 1, suggestions.length - 1);
                this.updateSelection(suggestions, selectedIndex);
                break;

            case 'ArrowUp':
                e.preventDefault();
                selectedIndex = Math.max(selectedIndex - 1, 0);
                this.updateSelection(suggestions, selectedIndex);
                break;

            case 'Enter':
                e.preventDefault();
                if (currentSelected) {
                    const suggestion = currentSelected.dataset.suggestion;
                    this.elements.input.value = suggestion;
                    this.handleSearch(suggestion);
                    this.hideSuggestions();
                } else {
                    this.handleSearch(this.elements.input.value);
                }
                break;

            case 'Escape':
                this.hideSuggestions();
                break;
        }
    }

    /**
     * 更新选择状态
     */
    updateSelection(suggestions, selectedIndex) {
        suggestions.forEach((suggestion, index) => {
            suggestion.classList.toggle('selected', index === selectedIndex);
        });
    }

    /**
     * 切换高级过滤器
     */
    toggleAdvancedFilters() {
        if (!this.elements.advancedFilters) return;

        const isVisible = this.elements.advancedFilters.style.display !== 'none';
        this.elements.advancedFilters.style.display = isVisible ? 'none' : 'block';
        
        if (this.elements.filterBtn) {
            this.elements.filterBtn.classList.toggle('active', !isVisible);
        }
    }

    /**
     * 处理过滤器变化
     */
    handleFilterChange(e) {
        const filterName = e.target.name || e.target.className;
        const filterValue = e.target.type === 'checkbox' ? e.target.checked : e.target.value;

        this.currentFilters.set(filterName, {
            type: 'exact',
            value: filterValue
        });

        // 重新搜索
        if (this.currentQuery) {
            this.handleSearch(this.currentQuery);
        }

        // 触发过滤器回调
        if (this.options.onFilter) {
            this.options.onFilter(this.currentFilters);
        }
    }

    /**
     * 切换语音搜索
     */
    toggleVoiceSearch() {
        if (!this.speechRecognition) return;

        if (this.isListening) {
            this.speechRecognition.stop();
        } else {
            this.speechRecognition.start();
        }
    }

    /**
     * 处理结果点击
     */
    handleResultClick(resultItem) {
        try {
            const itemData = JSON.parse(resultItem.dataset.item);
            if (this.options.onSelect) {
                this.options.onSelect(itemData);
            }
        } catch (error) {
            console.error('Error parsing result item data:', error);
        }
    }

    /**
     * 工具方法
     */
    clearSearch() {
        this.elements.input.value = '';
        this.currentQuery = '';
        this.clearResults();
        this.hideSuggestions();
        this.elements.input.focus();
    }

    clearResults() {
        this.elements.results.innerHTML = '';
        this.hideInfo();
    }

    showLoading() {
        if (this.elements.loading) {
            this.elements.loading.style.display = 'flex';
        }
    }

    hideLoading() {
        if (this.elements.loading) {
            this.elements.loading.style.display = 'none';
        }
    }

    showInfo(message) {
        if (this.elements.info) {
            this.elements.info.textContent = message;
            this.elements.info.style.display = 'block';
        }
    }

    hideInfo() {
        if (this.elements.info) {
            this.elements.info.style.display = 'none';
        }
    }

    showStatus(message, type = 'info') {
        // 可以集成通知系统
        if (window.notifications) {
            window.notifications.show(type, message, { timeout: 3000 });
        }
    }

    hideStatus() {
        // 隐藏状态信息
    }

    showError(message) {
        this.showStatus(message, 'error');
        this.clearResults();
    }

    showNoResults() {
        const template = this.options.noResultsTemplate || this.defaultNoResultsTemplate();
        this.elements.results.innerHTML = template;
        this.showInfo('未找到匹配结果');
    }

    defaultNoResultsTemplate() {
        return `
            <div class="no-results">
                <div class="no-results-icon">🔍</div>
                <div class="no-results-title">未找到匹配结果</div>
                <div class="no-results-message">
                    请尝试使用不同的关键词或调整搜索条件
                </div>
            </div>
        `;
    }

    hideSuggestions() {
        if (this.elements.suggestions) {
            this.elements.suggestions.style.display = 'none';
        }
    }

    /**
     * 搜索历史管理
     */
    addToSearchHistory(query) {
        this.searchHistory.add(query);
        if (this.searchHistory.size > 20) {
            const first = this.searchHistory.values().next().value;
            this.searchHistory.delete(first);
        }
        this.saveSearchHistory();
    }

    loadSearchHistory() {
        try {
            const saved = localStorage.getItem('search_history');
            if (saved) {
                this.searchHistory = new Set(JSON.parse(saved));
            }
        } catch (error) {
            console.warn('Failed to load search history:', error);
        }
    }

    saveSearchHistory() {
        try {
            localStorage.setItem('search_history', JSON.stringify(Array.from(this.searchHistory)));
        } catch (error) {
            console.warn('Failed to save search history:', error);
        }
    }

    /**
     * 缓存管理
     */
    getCacheKey(query, filters) {
        const filterStr = Array.from(filters.entries())
            .map(([k, v]) => `${k}:${JSON.stringify(v)}`)
            .join('|');
        return `${query}__${filterStr}`;
    }

    clearCache() {
        this.searchCache.clear();
    }

    /**
     * 辅助方法
     */
    getNestedValue(obj, path) {
        return path.split('.').reduce((current, key) => current && current[key], obj);
    }

    truncateText(text, maxLength) {
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength - 3) + '...';
    }

    escapeRegex(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    filtersToParams(filters) {
        const params = {};
        filters.forEach((value, key) => {
            params[key] = value.value;
        });
        return params;
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    /**
     * 公共API方法
     */
    search(query) {
        this.elements.input.value = query;
        return this.handleSearch(query);
    }

    setDataSource(dataSource) {
        this.options.dataSource = dataSource;
        this.clearCache();
    }

    addFilter(name, value, type = 'exact') {
        this.currentFilters.set(name, { type, value });
        if (this.currentQuery) {
            this.handleSearch(this.currentQuery);
        }
    }

    removeFilter(name) {
        this.currentFilters.delete(name);
        if (this.currentQuery) {
            this.handleSearch(this.currentQuery);
        }
    }

    clearFilters() {
        this.currentFilters.clear();
        if (this.currentQuery) {
            this.handleSearch(this.currentQuery);
        }
    }

    getResults() {
        return Array.from(this.elements.results.querySelectorAll('.search-result-item'))
            .map(item => JSON.parse(item.dataset.item));
    }

    focus() {
        this.elements.input.focus();
    }

    destroy() {
        if (this.abortController) {
            this.abortController.abort();
        }
        
        if (this.speechRecognition) {
            this.speechRecognition.stop();
        }

        this.clearCache();
        this.searchHistory.clear();
        
        if (this.elements.container) {
            this.elements.container.innerHTML = '';
        }
    }
}

// 全局导出
window.SearchAndFilterSystem = SearchAndFilterSystem;

// 导出模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SearchAndFilterSystem;
}
