class VoiceInteraction {
  constructor() {
    this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
    this.speechSynthesis = window.speechSynthesis;
    this.isSpeaking = false;
    this.utterance = null;
    this.conversationState = 'idle'; // 'idle'|'listening'|'processing'|'speaking'
    this.recognition = null;
  }

  // 初始化语音识别
  initRecognition(onResult) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    this.recognition = new SpeechRecognition();
    this.recognition.continuous = true;
    this.recognition.interimResults = true;
    this.recognition.lang = 'zh-CN';

    this.recognition.onstart = () => {
      this.conversationState = 'listening';
      this.playFeedbackTone('start');
    };

    this.recognition.onresult = (event) => {
      let final = '';
      let interim = '';
      
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          final += transcript;
        } else {
          interim += transcript;
        }
      }

      if (final) {
        this.conversationState = 'processing';
        onResult(final);
      } else if (interim) {
        onResult('', interim);
      }
    };

    this.recognition.onerror = (event) => {
      console.error('Recognition error:', event.error);
      this.playFeedbackTone('error');
      this.resetState();
    };

    this.recognition.onend = () => {
      if (this.conversationState === 'listening') {
        this.recognition.start(); // 保持连续监听
      }
    };
  }

  // 开始连续对话
  startContinuousConversation(onUserSpeech, onComplete) {
    this.initRecognition(onUserSpeech);
    this.recognition.start();
    
    return {
      respond: async (text) => {
        if (this.conversationState === 'listening') {
          this.recognition.stop();
        }
        
        this.conversationState = 'speaking';
        await this.speak(text);
        
        if (onComplete) onComplete();
        this.conversationState = 'listening';
        this.recognition.start();
      },
      stop: () => {
        this.resetState();
      }
    };
  }

  // 重置状态
  resetState() {
    if (this.recognition) {
      this.recognition.stop();
    }
    this.stopSpeaking();
    this.conversationState = 'idle';
  }

  // 播放提示音
  playFeedbackTone(type) {
    const freqMap = {
      'start': 800,
      'end': 400,
      'error': 200
    };
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();
    
    oscillator.type = 'sine';
    oscillator.frequency.value = freqMap[type] || 500;
    gainNode.gain.value = 0.3;
    
    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);
    
    oscillator.start();
    gainNode.gain.exponentialRampToValueAtTime(
      0.0001, this.audioContext.currentTime + 0.3
    );
    oscillator.stop(this.audioContext.currentTime + 0.3);
  }

  // 文本转语音
  speak(text) {
    return new Promise((resolve) => {
      if (this.isSpeaking) {
        this.stopSpeaking();
      }

      this.utterance = new SpeechSynthesisUtterance(text);
      this.utterance.lang = 'zh-CN';
      this.utterance.rate = 0.9;
      this.utterance.pitch = 1.1;
      
      this.utterance.onstart = () => {
        this.isSpeaking = true;
      };
      
      this.utterance.onend = () => {
        this.isSpeaking = false;
        resolve();
      };
      
      this.speechSynthesis.speak(this.utterance);
    });
  }

  stopSpeaking() {
    if (this.isSpeaking) {
      this.speechSynthesis.cancel();
      this.isSpeaking = false;
    }
  }
}

// 导出单例实例
export const voiceInteraction = new VoiceInteraction();