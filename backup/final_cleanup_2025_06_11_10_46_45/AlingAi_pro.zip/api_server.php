<?php

declare(strict_types=1);

// 引入必要的文件
require_once __DIR__ . '/setup_file_database.php';
require_once __DIR__ . '/test_enterprise_system.php';

/**
 * 企业管理系统API服务器
 * 提供RESTful API接口用于前端调用
 */

// 设置CORS头，允许跨域请求
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

// 处理OPTIONS预检请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// 初始化数据库和服务
$dataDir = __DIR__ . '/storage/data';
$db = new FileDatabase($dataDir);
$service = new EnterpriseManagementService($db);

// 路由处理
$requestMethod = $_SERVER['REQUEST_METHOD'];
$requestUri = $_SERVER['REQUEST_URI'];
$path = parse_url($requestUri, PHP_URL_PATH);

// 简单的路由匹配
$routes = [
    'GET /api/admin/stats' => 'getSystemStats',
    'GET /api/admin/applications' => 'getApplications',
    'POST /api/admin/applications/review' => 'reviewApplication',
    'GET /api/admin/users' => 'getUsers',
    'POST /api/admin/quota/update' => 'updateQuota',
    'GET /api/admin/enterprise-config' => 'getEnterpriseConfig',
    'POST /api/admin/enterprise-config/update' => 'updateEnterpriseConfig'
];

$route = $requestMethod . ' ' . $path;

// 日志记录
error_log("API Request: $route");

if (isset($routes[$route])) {
    $handler = $routes[$route];
    
    try {
        switch ($handler) {
            case 'getSystemStats':
                echo json_encode([
                    'success' => true,
                    'data' => $service->getSystemStats()
                ]);
                break;
                
            case 'getApplications':
                $status = $_GET['status'] ?? null;
                $applications = $status ? 
                    $service->getApplicationsByStatus($status) : 
                    $service->getAllApplications();
                    
                echo json_encode([
                    'success' => true,
                    'data' => $applications
                ]);
                break;
                
            case 'reviewApplication':
                $input = json_decode(file_get_contents('php://input'), true);
                $applicationId = (int)($input['applicationId'] ?? 0);
                $status = $input['status'] ?? '';
                $adminNotes = $input['adminNotes'] ?? '';
                
                if ($applicationId && $status) {
                    $result = $service->reviewApplication($applicationId, $status, $adminNotes);
                    echo json_encode([
                        'success' => $result,
                        'message' => $result ? '审核完成' : '审核失败'
                    ]);
                } else {
                    echo json_encode([
                        'success' => false,
                        'message' => '参数不完整'
                    ]);
                }
                break;
                
            case 'getUsers':
                $users = $db->find('users');
                echo json_encode([
                    'success' => true,
                    'data' => $users
                ]);
                break;
                
            case 'updateQuota':
                $input = json_decode(file_get_contents('php://input'), true);
                $userId = (int)($input['userId'] ?? 0);
                $quotaData = $input['quotaData'] ?? [];
                
                if ($userId && !empty($quotaData)) {
                    $result = $service->updateUserQuota($userId, $quotaData);
                    echo json_encode([
                        'success' => $result,
                        'message' => $result ? '配额更新成功' : '配额更新失败'
                    ]);
                } else {
                    echo json_encode([
                        'success' => false,
                        'message' => '参数不完整'
                    ]);
                }
                break;
                
            case 'getEnterpriseConfig':
                $userId = (int)($_GET['userId'] ?? 0);
                if ($userId) {
                    $config = $service->getEnterpriseConfig($userId);
                    echo json_encode([
                        'success' => true,
                        'data' => $config
                    ]);
                } else {
                    echo json_encode([
                        'success' => false,
                        'message' => '用户ID不能为空'
                    ]);
                }
                break;
                
            case 'updateEnterpriseConfig':
                $input = json_decode(file_get_contents('php://input'), true);
                $userId = (int)($input['userId'] ?? 0);
                $configData = $input['configData'] ?? [];
                
                if ($userId && !empty($configData)) {
                    $result = $service->updateEnterpriseConfig($userId, $configData);
                    echo json_encode([
                        'success' => $result,
                        'message' => $result ? '配置更新成功' : '配置更新失败'
                    ]);
                } else {
                    echo json_encode([
                        'success' => false,
                        'message' => '参数不完整'
                    ]);
                }
                break;
                
            default:
                echo json_encode([
                    'success' => false,
                    'message' => '未知的处理器'
                ]);
        }
    } catch (Exception $e) {
        error_log("API Error: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => '服务器内部错误: ' . $e->getMessage()
        ]);
    }
} else {
    // 如果是请求根路径，返回API文档
    if ($path === '/' || $path === '/api') {
        echo json_encode([
            'name' => 'AlingAi Pro 企业管理系统 API',
            'version' => '1.0.0',
            'endpoints' => [
                'GET /api/admin/stats' => '获取系统统计信息',
                'GET /api/admin/applications' => '获取企业申请列表',
                'POST /api/admin/applications/review' => '审核企业申请',
                'GET /api/admin/users' => '获取用户列表',
                'POST /api/admin/quota/update' => '更新用户配额',
                'GET /api/admin/enterprise-config' => '获取企业配置',
                'POST /api/admin/enterprise-config/update' => '更新企业配置'
            ],
            'timestamp' => date('Y-m-d H:i:s')
        ]);
    } else {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => '接口不存在',
            'path' => $path
        ]);
    }
}
