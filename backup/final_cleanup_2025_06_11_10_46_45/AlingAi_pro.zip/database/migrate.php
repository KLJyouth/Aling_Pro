<?php
/**
 * 数据库迁移执行脚本
 * 适用于MySQL 5.7.43+
 * 支持自动迁移、回滚、状态检查等功能
 */

class DatabaseMigration
{
    private $pdo;
    private $migrationPath;
    private $migrationTable = 'migrations';
    
    public function __construct($config)
    {
        $this->migrationPath = __DIR__ . '/migrations/';
        $this->connectDatabase($config);
        $this->createMigrationTable();
    }
    
    /**
     * 连接数据库
     */
    private function connectDatabase($config)
    {
        try {
            $dsn = "mysql:host={$config['host']};port={$config['port']};charset=utf8mb4";
            $this->pdo = new PDO($dsn, $config['username'], $config['password'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
            ]);
            
            // 创建数据库（如果不存在）
            $this->pdo->exec("CREATE DATABASE IF NOT EXISTS `{$config['database']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $this->pdo->exec("USE `{$config['database']}`");
            
            echo "✓ 数据库连接成功\n";
        } catch (PDOException $e) {
            die("✗ 数据库连接失败: " . $e->getMessage() . "\n");
        }
    }
    
    /**
     * 创建迁移记录表
     */
    private function createMigrationTable()
    {
        $sql = "CREATE TABLE IF NOT EXISTS `{$this->migrationTable}` (
            `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
            `migration` varchar(255) NOT NULL,
            `batch` int(11) NOT NULL,
            `executed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uk_migration` (`migration`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $this->pdo->exec($sql);
    }
    
    /**
     * 获取所有迁移文件
     */
    private function getMigrationFiles()
    {
        $files = glob($this->migrationPath . '*.sql');
        sort($files);
        return array_map('basename', $files);
    }
    
    /**
     * 获取已执行的迁移
     */
    private function getExecutedMigrations()
    {
        $stmt = $this->pdo->query("SELECT migration FROM {$this->migrationTable} ORDER BY id");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    /**
     * 执行迁移
     */
    public function migrate()
    {
        $allMigrations = $this->getMigrationFiles();
        $executedMigrations = $this->getExecutedMigrations();
        $pendingMigrations = array_diff($allMigrations, $executedMigrations);
        
        if (empty($pendingMigrations)) {
            echo "✓ 没有待执行的迁移\n";
            return;
        }
        
        $batch = $this->getNextBatch();
        
        foreach ($pendingMigrations as $migration) {
            $this->executeMigration($migration, $batch);
        }
        
        echo "✓ 所有迁移执行完成\n";
    }
    
    /**
     * 执行单个迁移文件
     */
    private function executeMigration($migration, $batch)
    {
        $filePath = $this->migrationPath . $migration;
        
        if (!file_exists($filePath)) {
            echo "✗ 迁移文件不存在: {$migration}\n";
            return false;
        }
        
        $sql = file_get_contents($filePath);
        
        try {
            $this->pdo->beginTransaction();
            
            // 执行迁移SQL
            $this->pdo->exec($sql);
            
            // 记录迁移
            $stmt = $this->pdo->prepare("INSERT INTO {$this->migrationTable} (migration, batch) VALUES (?, ?)");
            $stmt->execute([$migration, $batch]);
            
            $this->pdo->commit();
            
            echo "✓ 迁移执行成功: {$migration}\n";
            return true;
            
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            echo "✗ 迁移执行失败: {$migration}\n";
            echo "错误信息: " . $e->getMessage() . "\n";
            return false;
        }
    }
    
    /**
     * 获取下一个批次号
     */
    private function getNextBatch()
    {
        $stmt = $this->pdo->query("SELECT MAX(batch) as max_batch FROM {$this->migrationTable}");
        $result = $stmt->fetch();
        return ($result['max_batch'] ?? 0) + 1;
    }
    
    /**
     * 回滚迁移
     */
    public function rollback($steps = 1)
    {
        $stmt = $this->pdo->prepare("SELECT DISTINCT batch FROM {$this->migrationTable} ORDER BY batch DESC LIMIT ?");
        $stmt->execute([$steps]);
        $batches = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        if (empty($batches)) {
            echo "✓ 没有可回滚的迁移\n";
            return;
        }
        
        foreach ($batches as $batch) {
            $this->rollbackBatch($batch);
        }
        
        echo "✓ 回滚完成\n";
    }
    
    /**
     * 回滚指定批次
     */
    private function rollbackBatch($batch)
    {
        $stmt = $this->pdo->prepare("SELECT migration FROM {$this->migrationTable} WHERE batch = ? ORDER BY id DESC");
        $stmt->execute([$batch]);
        $migrations = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        foreach ($migrations as $migration) {
            // 这里可以实现回滚逻辑，暂时只删除记录
            $stmt = $this->pdo->prepare("DELETE FROM {$this->migrationTable} WHERE migration = ?");
            $stmt->execute([$migration]);
            echo "✓ 回滚迁移: {$migration}\n";
        }
    }
    
    /**
     * 显示迁移状态
     */
    public function status()
    {
        $allMigrations = $this->getMigrationFiles();
        $executedMigrations = $this->getExecutedMigrations();
        
        echo "迁移状态:\n";
        echo str_repeat("-", 80) . "\n";
        printf("%-50s %s\n", "迁移文件", "状态");
        echo str_repeat("-", 80) . "\n";
        
        foreach ($allMigrations as $migration) {
            $status = in_array($migration, $executedMigrations) ? "已执行" : "待执行";
            printf("%-50s %s\n", $migration, $status);
        }
        
        echo str_repeat("-", 80) . "\n";
        echo "总计: " . count($allMigrations) . " 个迁移文件\n";
        echo "已执行: " . count($executedMigrations) . " 个\n";
        echo "待执行: " . (count($allMigrations) - count($executedMigrations)) . " 个\n";
    }
    
    /**
     * 重置数据库
     */
    public function reset()
    {
        $confirmation = readline("确定要重置数据库吗？这将删除所有数据！(yes/no): ");
        
        if (strtolower($confirmation) !== 'yes') {
            echo "操作已取消\n";
            return;
        }
        
        try {
            // 获取所有表
            $stmt = $this->pdo->query("SHOW TABLES");
            $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            // 禁用外键检查
            $this->pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
            
            // 删除所有表
            foreach ($tables as $table) {
                $this->pdo->exec("DROP TABLE IF EXISTS `{$table}`");
                echo "✓ 删除表: {$table}\n";
            }
            
            // 启用外键检查
            $this->pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
            
            echo "✓ 数据库重置完成\n";
            
        } catch (PDOException $e) {
            echo "✗ 数据库重置失败: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 刷新数据库（重置并重新迁移）
     */
    public function refresh()
    {
        echo "开始刷新数据库...\n";
        $this->reset();
        $this->migrate();
        echo "✓ 数据库刷新完成\n";
    }
}

// 使用示例
if (php_sapi_name() === 'cli') {
    // 数据库配置
    $config = [
        'host' => getenv('DB_HOST') ?: 'localhost',
        'port' => getenv('DB_PORT') ?: '3306',
        'database' => getenv('DB_DATABASE') ?: 'alingai',
        'username' => getenv('DB_USERNAME') ?: 'root',
        'password' => getenv('DB_PASSWORD') ?: ''
    ];
    
    $migration = new DatabaseMigration($config);
    
    $command = $argv[1] ?? 'status';
    
    switch ($command) {
        case 'migrate':
            $migration->migrate();
            break;
            
        case 'rollback':
            $steps = intval($argv[2] ?? 1);
            $migration->rollback($steps);
            break;
            
        case 'status':
            $migration->status();
            break;
            
        case 'reset':
            $migration->reset();
            break;
            
        case 'refresh':
            $migration->refresh();
            break;
            
        default:
            echo "用法: php migrate.php [command]\n";
            echo "命令:\n";
            echo "  migrate   执行所有待处理的迁移\n";
            echo "  rollback  回滚迁移 (可选参数: 回滚步数)\n";
            echo "  status    显示迁移状态\n";
            echo "  reset     重置数据库\n";
            echo "  refresh   重置并重新迁移数据库\n";
            break;
    }
}
