<?php
/**
 * 备份监控脚本 - AlingAi Pro
 */
class BackupMonitor
{
    private $config = [
        'backup_path' => 'E:/Backups/AlingAi_Pro',
        'alert_email' => 'admin@alingai.com',
        'max_backup_age' => 86400, // 24小时
        'min_backup_size' => 1048576 // 1MB
    ];
    
    public function checkBackupHealth()
    {
        echo "检查备份健康状态...\n";
        
        $issues = [];
        
        // 检查数据库备份
        $dbIssues = $this->checkDatabaseBackups();
        $issues = array_merge($issues, $dbIssues);
        
        // 检查文件备份
        $fileIssues = $this->checkFileBackups();
        $issues = array_merge($issues, $fileIssues);
        
        // 检查备份存储空间
        $spaceIssues = $this->checkStorageSpace();
        $issues = array_merge($issues, $spaceIssues);
        
        if (empty($issues)) {
            echo "✓ 所有备份状态正常\n";
            $this->logBackupStatus('OK', '备份系统运行正常');
        } else {
            echo "⚠ 发现备份问题:\n";
            foreach ($issues as $issue) {
                echo "  - $issue\n";
            }
            $this->logBackupStatus('WARNING', implode('; ', $issues));
            $this->sendAlert($issues);
        }
        
        return empty($issues);
    }
    
    private function checkDatabaseBackups()
    {
        $issues = [];
        $dbBackupPath = $this->config['backup_path'] . '/database';
        
        if (!is_dir($dbBackupPath)) {
            $issues[] = '数据库备份目录不存在';
            return $issues;
        }
        
        $backups = glob($dbBackupPath . '/*.sql.gz');
        
        if (empty($backups)) {
            $issues[] = '未找到数据库备份文件';
            return $issues;
        }
        
        // 检查最新备份的时间
        $latestBackup = max(array_map('filemtime', $backups));
        if (time() - $latestBackup > $this->config['max_backup_age']) {
            $issues[] = '数据库备份过期，最新备份时间: ' . date('Y-m-d H:i:s', $latestBackup);
        }
        
        // 检查备份文件大小
        $latestFile = '';
        $latestTime = 0;
        foreach ($backups as $backup) {
            if (filemtime($backup) > $latestTime) {
                $latestTime = filemtime($backup);
                $latestFile = $backup;
            }
        }
        
        if ($latestFile && filesize($latestFile) < $this->config['min_backup_size']) {
            $issues[] = '数据库备份文件过小，可能备份失败';
        }
        
        return $issues;
    }
    
    private function checkFileBackups()
    {
        $issues = [];
        $fileBackupPath = $this->config['backup_path'] . '/files';
        
        if (!is_dir($fileBackupPath)) {
            $issues[] = '文件备份目录不存在';
            return $issues;
        }
        
        $backups = glob($fileBackupPath . '/*.zip');
        
        if (empty($backups)) {
            $issues[] = '未找到文件备份';
            return $issues;
        }
        
        // 检查最新备份
        $latestBackup = max(array_map('filemtime', $backups));
        if (time() - $latestBackup > $this->config['max_backup_age'] * 7) { // 文件备份可以7天一次
            $issues[] = '文件备份过期';
        }
        
        return $issues;
    }
    
    private function checkStorageSpace()
    {
        $issues = [];
        $backupPath = $this->config['backup_path'];
        
        if (!is_dir($backupPath)) {
            $issues[] = '备份根目录不存在';
            return $issues;
        }
        
        $freeBytes = disk_free_space($backupPath);
        $totalBytes = disk_total_space($backupPath);
        $usedPercent = (($totalBytes - $freeBytes) / $totalBytes) * 100;
        
        if ($usedPercent > 90) {
            $issues[] = '备份存储空间不足，已使用 ' . round($usedPercent, 2) . '%';
        } elseif ($usedPercent > 80) {
            $issues[] = '备份存储空间紧张，已使用 ' . round($usedPercent, 2) . '%';
        }
        
        return $issues;
    }
    
    private function logBackupStatus($level, $message)
    {
        $logFile = $this->config['backup_path'] . '/backup_monitor.log';
        $logEntry = sprintf(
            "[%s] %s: %s\n",
            date('Y-m-d H:i:s'),
            $level,
            $message
        );
        file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }
    
    private function sendAlert($issues)
    {
        $subject = 'AlingAi Pro 备份系统告警';
        $message = "备份系统检测到以下问题:\n\n";
        foreach ($issues as $issue) {
            $message .= "- $issue\n";
        }
        $message .= "\n请及时检查和修复备份系统。";
        
        // 简单邮件发送
        mail($this->config['alert_email'], $subject, $message);
        
        // 记录告警日志
        $alertFile = $this->config['backup_path'] . '/backup_alerts.log';
        $alertEntry = sprintf(
            "[%s] ALERT: %s\n",
            date('Y-m-d H:i:s'),
            implode('; ', $issues)
        );
        file_put_contents($alertFile, $alertEntry, FILE_APPEND | LOCK_EX);
    }
}

// 执行监控检查
$monitor = new BackupMonitor();
$monitor->checkBackupHealth();
?>