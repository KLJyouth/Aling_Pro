/**
 * AlingAi Pro - UI组件库
 * 现代化、可复用的UI组件集合，支持主题切换和响应式设计
 * 
 * @version 1.0.0
 * @author AlingAi Team
 * @created 2024-12-19
 */

/**
 * 基础组件类
 */
class BaseComponent {
    constructor(element, options = {}) {
        this.element = element;
        this.options = { ...this.constructor.defaultOptions, ...options };
        this.isInitialized = false;
        this.eventListeners = [];
        
        this.init();
    }

    init() {
        if (this.isInitialized) return;
        
        this.bindEvents();
        this.render();
        this.isInitialized = true;
        
        this.emit('initialized');
    }

    bindEvents() {
        // 子类重写
    }

    render() {
        // 子类重写
    }

    destroy() {
        this.removeAllListeners();
        this.element = null;
        this.emit('destroyed');
    }

    on(event, callback) {
        this.element.addEventListener(event, callback);
        this.eventListeners.push({ event, callback });
    }

    off(event, callback) {
        this.element.removeEventListener(event, callback);
        this.eventListeners = this.eventListeners.filter(
            listener => !(listener.event === event && listener.callback === callback)
        );
    }

    emit(event, data = null) {
        const customEvent = new CustomEvent(event, { detail: data });
        this.element.dispatchEvent(customEvent);
    }

    removeAllListeners() {
        this.eventListeners.forEach(({ event, callback }) => {
            this.element.removeEventListener(event, callback);
        });
        this.eventListeners = [];
    }

    static defaultOptions = {};
}

/**
 * 通知组件
 */
class NotificationComponent extends BaseComponent {
    static defaultOptions = {
        type: 'info',
        duration: 5000,
        position: 'top-right',
        closable: true,
        icon: true,
        animation: 'slide'
    };

    render() {
        this.element.className = `notification notification-${this.options.type} notification-${this.options.position}`;
        
        const iconMap = {
            success: 'fas fa-check-circle',
            error: 'fas fa-exclamation-circle',
            warning: 'fas fa-exclamation-triangle',
            info: 'fas fa-info-circle'
        };

        this.element.innerHTML = `
            ${this.options.icon ? `<i class="${iconMap[this.options.type]}"></i>` : ''}
            <div class="notification-content">
                <div class="notification-title">${this.options.title || ''}</div>
                <div class="notification-message">${this.options.message}</div>
            </div>
            ${this.options.closable ? '<button class="notification-close"><i class="fas fa-times"></i></button>' : ''}
        `;

        // 添加动画类
        this.element.classList.add(`notification-${this.options.animation}`);
        
        // 触发入场动画
        requestAnimationFrame(() => {
            this.element.classList.add('notification-show');
        });
    }

    bindEvents() {
        if (this.options.closable) {
            const closeBtn = this.element.querySelector('.notification-close');
            closeBtn?.addEventListener('click', () => this.close());
        }

        if (this.options.duration > 0) {
            this.autoCloseTimer = setTimeout(() => {
                this.close();
            }, this.options.duration);
        }
    }

    close() {
        if (this.autoCloseTimer) {
            clearTimeout(this.autoCloseTimer);
        }

        this.element.classList.add('notification-hide');
        this.element.classList.remove('notification-show');
        
        setTimeout(() => {
            this.element.remove();
            this.destroy();
        }, 300);
    }
}

/**
 * 模态框组件
 */
class ModalComponent extends BaseComponent {
    static defaultOptions = {
        backdrop: true,
        keyboard: true,
        focus: true,
        closable: true,
        size: 'medium',
        animation: 'fade'
    };

    render() {
        // 创建backdrop
        if (this.options.backdrop) {
            this.backdrop = document.createElement('div');
            this.backdrop.className = 'modal-backdrop';
            document.body.appendChild(this.backdrop);
        }

        this.element.className = `modal modal-${this.options.size}`;
        this.element.innerHTML = `
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">${this.options.title || ''}</h4>
                        ${this.options.closable ? '<button class="modal-close"><i class="fas fa-times"></i></button>' : ''}
                    </div>
                    <div class="modal-body">
                        ${this.options.content || ''}
                    </div>
                    ${this.options.footer ? `<div class="modal-footer">${this.options.footer}</div>` : ''}
                </div>
            </div>
        `;

        document.body.appendChild(this.element);
        document.body.classList.add('modal-open');
    }

    bindEvents() {
        if (this.options.closable) {
            const closeBtn = this.element.querySelector('.modal-close');
            closeBtn?.addEventListener('click', () => this.close());
        }

        if (this.options.backdrop) {
            this.backdrop?.addEventListener('click', () => {
                if (this.options.backdrop === true) {
                    this.close();
                }
            });
        }

        if (this.options.keyboard) {
            document.addEventListener('keydown', this.handleKeydown.bind(this));
        }

        // 阻止模态框内容滚动传播
        const modalContent = this.element.querySelector('.modal-content');
        modalContent?.addEventListener('scroll', (e) => {
            e.stopPropagation();
        });
    }

    handleKeydown(event) {
        if (event.key === 'Escape' && this.options.keyboard) {
            this.close();
        }
    }

    show() {
        this.element.style.display = 'block';
        
        if (this.backdrop) {
            this.backdrop.classList.add('show');
        }
        
        requestAnimationFrame(() => {
            this.element.classList.add('show');
            
            if (this.options.focus) {
                const focusElement = this.element.querySelector('[autofocus]') || 
                                  this.element.querySelector('input, button, [tabindex]');
                focusElement?.focus();
            }
        });

        this.emit('shown');
    }

    close() {
        this.element.classList.remove('show');
        
        if (this.backdrop) {
            this.backdrop.classList.remove('show');
        }

        setTimeout(() => {
            this.element.style.display = 'none';
            document.body.classList.remove('modal-open');
            
            if (this.backdrop) {
                this.backdrop.remove();
            }
            
            this.element.remove();
            this.destroy();
            this.emit('hidden');
        }, 300);
    }
}

/**
 * 下拉菜单组件
 */
class DropdownComponent extends BaseComponent {
    static defaultOptions = {
        trigger: 'click',
        placement: 'bottom-start',
        offset: [0, 2],
        animation: 'fade'
    };

    render() {
        this.toggle = this.element.querySelector('.dropdown-toggle');
        this.menu = this.element.querySelector('.dropdown-menu');
        
        if (!this.toggle || !this.menu) {
            console.error('Dropdown requires .dropdown-toggle and .dropdown-menu elements');
            return;
        }

        this.element.classList.add('dropdown');
    }

    bindEvents() {
        if (this.options.trigger === 'click') {
            this.toggle.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.toggle();
            });

            document.addEventListener('click', (e) => {
                if (!this.element.contains(e.target)) {
                    this.hide();
                }
            });
        } else if (this.options.trigger === 'hover') {
            this.element.addEventListener('mouseenter', () => this.show());
            this.element.addEventListener('mouseleave', () => this.hide());
        }

        // 键盘导航
        this.element.addEventListener('keydown', this.handleKeydown.bind(this));
    }

    handleKeydown(event) {
        const items = this.menu.querySelectorAll('.dropdown-item:not(.disabled)');
        const currentIndex = Array.from(items).indexOf(document.activeElement);

        switch (event.key) {
            case 'ArrowDown':
                event.preventDefault();
                const nextIndex = currentIndex < items.length - 1 ? currentIndex + 1 : 0;
                items[nextIndex]?.focus();
                break;
            case 'ArrowUp':
                event.preventDefault();
                const prevIndex = currentIndex > 0 ? currentIndex - 1 : items.length - 1;
                items[prevIndex]?.focus();
                break;
            case 'Escape':
                this.hide();
                this.toggle.focus();
                break;
            case 'Enter':
            case ' ':
                if (document.activeElement.classList.contains('dropdown-item')) {
                    event.preventDefault();
                    document.activeElement.click();
                }
                break;
        }
    }

    toggle() {
        if (this.element.classList.contains('show')) {
            this.hide();
        } else {
            this.show();
        }
    }

    show() {
        this.element.classList.add('show');
        this.menu.classList.add('show');
        
        // 计算位置
        this.updatePosition();
        
        this.emit('shown');
    }

    hide() {
        this.element.classList.remove('show');
        this.menu.classList.remove('show');
        
        this.emit('hidden');
    }

    updatePosition() {
        // 简单的位置计算，实际项目中可能需要更复杂的定位逻辑
        const rect = this.toggle.getBoundingClientRect();
        const menuRect = this.menu.getBoundingClientRect();
        
        let top = rect.bottom + this.options.offset[1];
        let left = rect.left + this.options.offset[0];

        // 边界检测
        if (left + menuRect.width > window.innerWidth) {
            left = rect.right - menuRect.width;
        }

        if (top + menuRect.height > window.innerHeight) {
            top = rect.top - menuRect.height - this.options.offset[1];
        }

        this.menu.style.top = `${top}px`;
        this.menu.style.left = `${left}px`;
    }
}

/**
 * 标签页组件
 */
class TabsComponent extends BaseComponent {
    static defaultOptions = {
        animation: 'fade',
        keyboard: true
    };

    init() {
        this.activeTab = null;
        this.tabs = [];
        this.panels = [];
        
        super.init();
    }

    render() {
        this.element.classList.add('tabs');
        
        const tabNavs = this.element.querySelectorAll('.tab-nav');
        const tabPanels = this.element.querySelectorAll('.tab-panel');

        this.tabs = Array.from(tabNavs);
        this.panels = Array.from(tabPanels);

        // 设置初始状态
        const activeTab = this.element.querySelector('.tab-nav.active') || this.tabs[0];
        if (activeTab) {
            this.setActiveTab(activeTab);
        }
    }

    bindEvents() {
        this.tabs.forEach(tab => {
            tab.addEventListener('click', (e) => {
                e.preventDefault();
                this.setActiveTab(tab);
            });
        });

        if (this.options.keyboard) {
            this.element.addEventListener('keydown', this.handleKeydown.bind(this));
        }
    }

    handleKeydown(event) {
        const currentIndex = this.tabs.indexOf(this.activeTab);
        
        switch (event.key) {
            case 'ArrowRight':
                event.preventDefault();
                const nextIndex = currentIndex < this.tabs.length - 1 ? currentIndex + 1 : 0;
                this.setActiveTab(this.tabs[nextIndex]);
                break;
            case 'ArrowLeft':
                event.preventDefault();
                const prevIndex = currentIndex > 0 ? currentIndex - 1 : this.tabs.length - 1;
                this.setActiveTab(this.tabs[prevIndex]);
                break;
            case 'Home':
                event.preventDefault();
                this.setActiveTab(this.tabs[0]);
                break;
            case 'End':
                event.preventDefault();
                this.setActiveTab(this.tabs[this.tabs.length - 1]);
                break;
        }
    }

    setActiveTab(tab) {
        if (tab === this.activeTab) return;

        const tabId = tab.getAttribute('data-tab') || tab.getAttribute('href')?.substring(1);
        const panel = this.element.querySelector(`#${tabId}`) || 
                     this.panels[this.tabs.indexOf(tab)];

        if (!panel) return;

        // 移除之前的激活状态
        if (this.activeTab) {
            this.activeTab.classList.remove('active');
            this.activeTab.setAttribute('aria-selected', 'false');
        }

        this.panels.forEach(p => {
            p.classList.remove('active');
            p.setAttribute('aria-hidden', 'true');
        });

        // 设置新的激活状态
        tab.classList.add('active');
        tab.setAttribute('aria-selected', 'true');
        panel.classList.add('active');
        panel.setAttribute('aria-hidden', 'false');

        this.activeTab = tab;
        tab.focus();

        this.emit('tabChanged', { tab, panel });
    }

    getActiveTab() {
        return this.activeTab;
    }
}

/**
 * 工具提示组件
 */
class TooltipComponent extends BaseComponent {
    static defaultOptions = {
        placement: 'top',
        trigger: 'hover',
        delay: { show: 500, hide: 100 },
        animation: true,
        html: false
    };

    render() {
        this.tooltip = document.createElement('div');
        this.tooltip.className = 'tooltip';
        this.tooltip.innerHTML = `
            <div class="tooltip-arrow"></div>
            <div class="tooltip-inner">${this.options.title || this.element.getAttribute('title') || ''}</div>
        `;
        
        // 移除原生title属性
        if (this.element.hasAttribute('title')) {
            this.originalTitle = this.element.getAttribute('title');
            this.element.removeAttribute('title');
        }
    }

    bindEvents() {
        if (this.options.trigger === 'hover') {
            this.element.addEventListener('mouseenter', () => {
                this.showTimer = setTimeout(() => this.show(), this.options.delay.show);
            });

            this.element.addEventListener('mouseleave', () => {
                if (this.showTimer) {
                    clearTimeout(this.showTimer);
                }
                this.hideTimer = setTimeout(() => this.hide(), this.options.delay.hide);
            });
        } else if (this.options.trigger === 'click') {
            this.element.addEventListener('click', () => {
                if (this.isVisible) {
                    this.hide();
                } else {
                    this.show();
                }
            });

            document.addEventListener('click', (e) => {
                if (!this.element.contains(e.target) && !this.tooltip.contains(e.target)) {
                    this.hide();
                }
            });
        }
    }

    show() {
        if (this.isVisible) return;

        document.body.appendChild(this.tooltip);
        this.updatePosition();
        
        if (this.options.animation) {
            this.tooltip.classList.add('fade');
            requestAnimationFrame(() => {
                this.tooltip.classList.add('show');
            });
        } else {
            this.tooltip.classList.add('show');
        }

        this.isVisible = true;
        this.emit('shown');
    }

    hide() {
        if (!this.isVisible) return;

        this.tooltip.classList.remove('show');
        
        if (this.options.animation) {
            setTimeout(() => {
                if (this.tooltip.parentNode) {
                    this.tooltip.parentNode.removeChild(this.tooltip);
                }
            }, 150);
        } else {
            if (this.tooltip.parentNode) {
                this.tooltip.parentNode.removeChild(this.tooltip);
            }
        }

        this.isVisible = false;
        this.emit('hidden');
    }

    updatePosition() {
        const elementRect = this.element.getBoundingClientRect();
        const tooltipRect = this.tooltip.getBoundingClientRect();
        
        let top, left;

        switch (this.options.placement) {
            case 'top':
                top = elementRect.top - tooltipRect.height - 8;
                left = elementRect.left + (elementRect.width - tooltipRect.width) / 2;
                break;
            case 'bottom':
                top = elementRect.bottom + 8;
                left = elementRect.left + (elementRect.width - tooltipRect.width) / 2;
                break;
            case 'left':
                top = elementRect.top + (elementRect.height - tooltipRect.height) / 2;
                left = elementRect.left - tooltipRect.width - 8;
                break;
            case 'right':
                top = elementRect.top + (elementRect.height - tooltipRect.height) / 2;
                left = elementRect.right + 8;
                break;
        }

        // 边界检测
        if (left < 0) left = 8;
        if (left + tooltipRect.width > window.innerWidth) {
            left = window.innerWidth - tooltipRect.width - 8;
        }
        if (top < 0) top = 8;

        this.tooltip.style.top = `${top + window.scrollY}px`;
        this.tooltip.style.left = `${left + window.scrollX}px`;
        this.tooltip.setAttribute('data-placement', this.options.placement);
    }

    updateTitle(title) {
        const inner = this.tooltip.querySelector('.tooltip-inner');
        if (inner) {
            inner.textContent = title;
        }
    }

    destroy() {
        if (this.showTimer) clearTimeout(this.showTimer);
        if (this.hideTimer) clearTimeout(this.hideTimer);
        
        if (this.tooltip.parentNode) {
            this.tooltip.parentNode.removeChild(this.tooltip);
        }

        if (this.originalTitle) {
            this.element.setAttribute('title', this.originalTitle);
        }

        super.destroy();
    }
}

/**
 * 进度条组件
 */
class ProgressComponent extends BaseComponent {
    static defaultOptions = {
        value: 0,
        max: 100,
        animated: false,
        striped: false,
        label: false
    };

    render() {
        this.element.className = 'progress';
        
        if (this.options.striped) {
            this.element.classList.add('progress-striped');
        }
        
        if (this.options.animated) {
            this.element.classList.add('progress-animated');
        }

        this.bar = document.createElement('div');
        this.bar.className = 'progress-bar';
        this.bar.setAttribute('role', 'progressbar');
        
        if (this.options.label) {
            this.label = document.createElement('span');
            this.label.className = 'progress-label';
            this.bar.appendChild(this.label);
        }

        this.element.appendChild(this.bar);
        this.updateProgress();
    }

    updateProgress() {
        const percentage = Math.min(100, Math.max(0, (this.options.value / this.options.max) * 100));
        
        this.bar.style.width = `${percentage}%`;
        this.bar.setAttribute('aria-valuenow', this.options.value);
        this.bar.setAttribute('aria-valuemin', '0');
        this.bar.setAttribute('aria-valuemax', this.options.max);

        if (this.label) {
            this.label.textContent = `${Math.round(percentage)}%`;
        }

        this.emit('progress', { value: this.options.value, percentage });
    }

    setValue(value) {
        this.options.value = value;
        this.updateProgress();
    }

    setMax(max) {
        this.options.max = max;
        this.updateProgress();
    }

    increment(amount = 1) {
        this.setValue(this.options.value + amount);
    }

    decrement(amount = 1) {
        this.setValue(this.options.value - amount);
    }
}

/**
 * 手风琴组件
 */
class AccordionComponent extends BaseComponent {
    static defaultOptions = {
        multiple: false,
        animation: true
    };

    init() {
        this.items = [];
        super.init();
    }

    render() {
        this.element.classList.add('accordion');
        
        const accordionItems = this.element.querySelectorAll('.accordion-item');
        this.items = Array.from(accordionItems).map(item => ({
            element: item,
            header: item.querySelector('.accordion-header'),
            body: item.querySelector('.accordion-body'),
            isOpen: item.classList.contains('active')
        }));
    }

    bindEvents() {
        this.items.forEach((item, index) => {
            item.header?.addEventListener('click', () => {
                this.toggle(index);
            });
        });
    }

    toggle(index) {
        const item = this.items[index];
        if (!item) return;

        if (item.isOpen) {
            this.close(index);
        } else {
            if (!this.options.multiple) {
                this.closeAll();
            }
            this.open(index);
        }
    }

    open(index) {
        const item = this.items[index];
        if (!item || item.isOpen) return;

        item.element.classList.add('active');
        item.isOpen = true;

        if (this.options.animation) {
            item.body.style.height = '0';
            item.body.style.overflow = 'hidden';
            
            requestAnimationFrame(() => {
                item.body.style.height = `${item.body.scrollHeight}px`;
                
                setTimeout(() => {
                    item.body.style.height = '';
                    item.body.style.overflow = '';
                }, 300);
            });
        }

        this.emit('opened', { index, item });
    }

    close(index) {
        const item = this.items[index];
        if (!item || !item.isOpen) return;

        item.element.classList.remove('active');
        item.isOpen = false;

        if (this.options.animation) {
            item.body.style.height = `${item.body.scrollHeight}px`;
            item.body.style.overflow = 'hidden';
            
            requestAnimationFrame(() => {
                item.body.style.height = '0';
                
                setTimeout(() => {
                    item.body.style.height = '';
                    item.body.style.overflow = '';
                }, 300);
            });
        }

        this.emit('closed', { index, item });
    }

    closeAll() {
        this.items.forEach((item, index) => {
            if (item.isOpen) {
                this.close(index);
            }
        });
    }

    openAll() {
        if (this.options.multiple) {
            this.items.forEach((item, index) => {
                if (!item.isOpen) {
                    this.open(index);
                }
            });
        }
    }
}

/**
 * UI组件管理器
 */
class UIManager {
    constructor() {
        this.components = new Map();
        this.observers = new Map();
        
        this.init();
    }

    init() {
        // 自动初始化组件
        this.autoInitComponents();
        
        // 设置DOM变化观察器
        this.setupMutationObserver();
        
        console.log('✅ UI组件管理器初始化完成');
    }

    autoInitComponents() {
        const componentMap = {
            '[data-component="notification"]': NotificationComponent,
            '[data-component="modal"]': ModalComponent,
            '[data-component="dropdown"]': DropdownComponent,
            '[data-component="tabs"]': TabsComponent,
            '[data-component="tooltip"]': TooltipComponent,
            '[data-component="progress"]': ProgressComponent,
            '[data-component="accordion"]': AccordionComponent
        };

        Object.entries(componentMap).forEach(([selector, ComponentClass]) => {
            document.querySelectorAll(selector).forEach(element => {
                if (!this.components.has(element)) {
                    const options = this.parseDataAttributes(element);
                    const component = new ComponentClass(element, options);
                    this.components.set(element, component);
                }
            });
        });
    }

    parseDataAttributes(element) {
        const options = {};
        
        Array.from(element.attributes).forEach(attr => {
            if (attr.name.startsWith('data-option-')) {
                const key = attr.name.replace('data-option-', '').replace(/-([a-z])/g, (g) => g[1].toUpperCase());
                let value = attr.value;
                
                // 尝试解析JSON值
                if (value === 'true') value = true;
                else if (value === 'false') value = false;
                else if (!isNaN(value)) value = Number(value);
                else if (value.startsWith('{') || value.startsWith('[')) {
                    try {
                        value = JSON.parse(value);
                    } catch (e) {
                        // 保持原值
                    }
                }
                
                options[key] = value;
            }
        });

        return options;
    }

    setupMutationObserver() {
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        this.initializeNewElements(node);
                    }
                });

                mutation.removedNodes.forEach((node) => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        this.cleanupRemovedElements(node);
                    }
                });
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        this.observers.set('mutation', observer);
    }

    initializeNewElements(element) {
        // 检查元素本身
        if (element.hasAttribute('data-component')) {
            this.autoInitComponents();
        }

        // 检查子元素
        element.querySelectorAll('[data-component]').forEach(() => {
            this.autoInitComponents();
        });
    }

    cleanupRemovedElements(element) {
        // 清理移除元素的组件
        if (this.components.has(element)) {
            const component = this.components.get(element);
            component.destroy();
            this.components.delete(element);
        }

        // 清理子元素的组件
        element.querySelectorAll('[data-component]').forEach(child => {
            if (this.components.has(child)) {
                const component = this.components.get(child);
                component.destroy();
                this.components.delete(child);
            }
        });
    }

    // 工具方法
    showNotification(message, type = 'info', options = {}) {
        const container = document.getElementById('notification-container') || this.createNotificationContainer();
        const notificationElement = document.createElement('div');
        container.appendChild(notificationElement);

        return new NotificationComponent(notificationElement, {
            message,
            type,
            ...options
        });
    }

    createNotificationContainer() {
        const container = document.createElement('div');
        container.id = 'notification-container';
        container.className = 'notification-container';
        document.body.appendChild(container);
        return container;
    }

    showModal(options = {}) {
        const modalElement = document.createElement('div');
        const modal = new ModalComponent(modalElement, options);
        modal.show();
        return modal;
    }

    confirm(message, options = {}) {
        return new Promise((resolve) => {
            const modal = this.showModal({
                title: options.title || '确认',
                content: `<p>${message}</p>`,
                footer: `
                    <button class="btn btn-secondary" data-action="cancel">取消</button>
                    <button class="btn btn-primary" data-action="confirm">确认</button>
                `,
                ...options
            });

            modal.element.addEventListener('click', (e) => {
                const action = e.target.dataset.action;
                if (action === 'confirm') {
                    resolve(true);
                    modal.close();
                } else if (action === 'cancel') {
                    resolve(false);
                    modal.close();
                }
            });
        });
    }

    prompt(message, defaultValue = '', options = {}) {
        return new Promise((resolve) => {
            const inputId = `prompt-input-${Date.now()}`;
            const modal = this.showModal({
                title: options.title || '输入',
                content: `
                    <p>${message}</p>
                    <input type="text" id="${inputId}" class="form-control" value="${defaultValue}" autofocus>
                `,
                footer: `
                    <button class="btn btn-secondary" data-action="cancel">取消</button>
                    <button class="btn btn-primary" data-action="confirm">确认</button>
                `,
                ...options
            });

            const input = modal.element.querySelector(`#${inputId}`);
            
            modal.element.addEventListener('click', (e) => {
                const action = e.target.dataset.action;
                if (action === 'confirm') {
                    resolve(input.value);
                    modal.close();
                } else if (action === 'cancel') {
                    resolve(null);
                    modal.close();
                }
            });

            input?.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    resolve(input.value);
                    modal.close();
                }
            });
        });
    }

    getComponent(element) {
        return this.components.get(element);
    }

    destroyComponent(element) {
        const component = this.components.get(element);
        if (component) {
            component.destroy();
            this.components.delete(element);
        }
    }

    destroyAllComponents() {
        this.components.forEach((component) => {
            component.destroy();
        });
        this.components.clear();
    }

    destroy() {
        this.destroyAllComponents();
        
        this.observers.forEach((observer) => {
            observer.disconnect();
        });
        this.observers.clear();
    }
}

// 导出组件类
window.BaseComponent = BaseComponent;
window.NotificationComponent = NotificationComponent;
window.ModalComponent = ModalComponent;
window.DropdownComponent = DropdownComponent;
window.TabsComponent = TabsComponent;
window.TooltipComponent = TooltipComponent;
window.ProgressComponent = ProgressComponent;
window.AccordionComponent = AccordionComponent;
window.UIManager = UIManager;

// 创建全局UI管理器实例
window.UI = new UIManager();

// 全局工具函数
window.showNotification = (message, type, options) => window.UI.showNotification(message, type, options);
window.showModal = (options) => window.UI.showModal(options);
window.confirm = (message, options) => window.UI.confirm(message, options);
window.prompt = (message, defaultValue, options) => window.UI.prompt(message, defaultValue, options);

console.log('✅ UI组件库已加载');
