/**
 * AlingAi Pro - Theme System
 * 
 * Advanced theme management with smooth transitions,
 * quantum-themed animations, and comprehensive customization
 * 
 * @package AlingAi\Frontend\Theme
 * @author AlingAi Team
 * @version 2.0.0
 */

class ThemeManager {
    constructor(options = {}) {
        this.options = {
            autoDetect: true,
            savePreference: true,
            smoothTransition: true,
            quantumEffects: true,
            transitionDuration: 300,
            storageKey: 'alingai-theme',
            defaultTheme: 'light',
            availableThemes: ['light', 'dark', 'quantum', 'matrix', 'aurora'],
            customThemes: {},
            ...options
        };
        
        this.currentTheme = null;
        this.previousTheme = null;
        this.isTransitioning = false;
        this.themeData = new Map();
        this.callbacks = new Map();
        
        this.init();
    }

    init() {
        this.loadThemeDefinitions();
        this.setupEventListeners();
        this.initializeTheme();
        this.createThemeControls();
        
        if (this.options.quantumEffects) {
            this.initQuantumEffects();
        }
    }

    loadThemeDefinitions() {
        // Built-in theme definitions
        const builtInThemes = {
            light: {
                name: 'Light',
                description: 'Clean and bright interface',
                colors: {
                    primary: '#3b82f6',
                    secondary: '#6b7280',
                    accent: '#10b981',
                    background: '#ffffff',
                    surface: '#f9fafb',
                    text: '#111827',
                    textSecondary: '#6b7280',
                    border: '#e5e7eb',
                    success: '#10b981',
                    warning: '#f59e0b',
                    error: '#ef4444',
                    quantum: '#8b5cf6'
                },
                properties: {
                    borderRadius: '8px',
                    shadows: {
                        small: '0 1px 3px rgba(0, 0, 0, 0.1)',
                        medium: '0 4px 6px rgba(0, 0, 0, 0.1)',
                        large: '0 10px 15px rgba(0, 0, 0, 0.1)'
                    },
                    transitions: {
                        fast: '150ms ease',
                        normal: '300ms ease',
                        slow: '500ms ease'
                    }
                }
            },
            
            dark: {
                name: 'Dark',
                description: 'Elegant dark mode for low-light environments',
                colors: {
                    primary: '#60a5fa',
                    secondary: '#9ca3af',
                    accent: '#34d399',
                    background: '#111827',
                    surface: '#1f2937',
                    text: '#f9fafb',
                    textSecondary: '#d1d5db',
                    border: '#374151',
                    success: '#34d399',
                    warning: '#fbbf24',
                    error: '#f87171',
                    quantum: '#a78bfa'
                },
                properties: {
                    borderRadius: '8px',
                    shadows: {
                        small: '0 1px 3px rgba(0, 0, 0, 0.3)',
                        medium: '0 4px 6px rgba(0, 0, 0, 0.3)',
                        large: '0 10px 15px rgba(0, 0, 0, 0.3)'
                    },
                    transitions: {
                        fast: '150ms ease',
                        normal: '300ms ease',
                        slow: '500ms ease'
                    }
                }
            },
            
            quantum: {
                name: 'Quantum',
                description: 'Futuristic theme with quantum-inspired effects',
                colors: {
                    primary: '#8b5cf6',
                    secondary: '#a78bfa',
                    accent: '#06b6d4',
                    background: '#0f0f23',
                    surface: '#1e1e3f',
                    text: '#e0e7ff',
                    textSecondary: '#c7d2fe',
                    border: '#4c1d95',
                    success: '#00f5ff',
                    warning: '#ffd700',
                    error: '#ff073a',
                    quantum: '#ff00ff'
                },
                properties: {
                    borderRadius: '12px',
                    shadows: {
                        small: '0 0 10px rgba(139, 92, 246, 0.3)',
                        medium: '0 0 20px rgba(139, 92, 246, 0.4)',
                        large: '0 0 30px rgba(139, 92, 246, 0.5)'
                    },
                    transitions: {
                        fast: '200ms cubic-bezier(0.4, 0, 0.2, 1)',
                        normal: '400ms cubic-bezier(0.4, 0, 0.2, 1)',
                        slow: '600ms cubic-bezier(0.4, 0, 0.2, 1)'
                    }
                }
            },
            
            matrix: {
                name: 'Matrix',
                description: 'Green-on-black matrix-inspired theme',
                colors: {
                    primary: '#00ff41',
                    secondary: '#008f11',
                    accent: '#39ff14',
                    background: '#000000',
                    surface: '#001100',
                    text: '#00ff41',
                    textSecondary: '#008f11',
                    border: '#003300',
                    success: '#39ff14',
                    warning: '#ffff00',
                    error: '#ff0000',
                    quantum: '#00ffff'
                },
                properties: {
                    borderRadius: '4px',
                    shadows: {
                        small: '0 0 5px rgba(0, 255, 65, 0.5)',
                        medium: '0 0 10px rgba(0, 255, 65, 0.6)',
                        large: '0 0 20px rgba(0, 255, 65, 0.7)'
                    },
                    transitions: {
                        fast: '100ms linear',
                        normal: '200ms linear',
                        slow: '400ms linear'
                    }
                }
            },
            
            aurora: {
                name: 'Aurora',
                description: 'Colorful aurora-inspired theme',
                colors: {
                    primary: '#ff6b9d',
                    secondary: '#4ecdc4',
                    accent: '#ffe66d',
                    background: '#0a0a2e',
                    surface: '#16213e',
                    text: '#ffffff',
                    textSecondary: '#e0e7ff',
                    border: '#0f3460',
                    success: '#4ecdc4',
                    warning: '#ffe66d',
                    error: '#ff6b9d',
                    quantum: '#c471ed'
                },
                properties: {
                    borderRadius: '16px',
                    shadows: {
                        small: '0 0 15px rgba(255, 107, 157, 0.3)',
                        medium: '0 0 25px rgba(78, 205, 196, 0.4)',
                        large: '0 0 35px rgba(255, 230, 109, 0.5)'
                    },
                    transitions: {
                        fast: '250ms cubic-bezier(0.68, -0.55, 0.265, 1.55)',
                        normal: '500ms cubic-bezier(0.68, -0.55, 0.265, 1.55)',
                        slow: '750ms cubic-bezier(0.68, -0.55, 0.265, 1.55)'
                    }
                }
            }
        };
        
        // Merge with custom themes
        const allThemes = { ...builtInThemes, ...this.options.customThemes };
        
        // Store theme data
        Object.keys(allThemes).forEach(themeId => {
            this.themeData.set(themeId, allThemes[themeId]);
        });
    }

    setupEventListeners() {
        // System theme change detection
        if (this.options.autoDetect && window.matchMedia) {
            const darkModeQuery = window.matchMedia('(prefers-color-scheme: dark)');
            darkModeQuery.addEventListener('change', this.handleSystemThemeChange.bind(this));
        }
        
        // Keyboard shortcuts
        document.addEventListener('keydown', this.handleKeyboardShortcuts.bind(this));
    }

    initializeTheme() {
        let theme = this.options.defaultTheme;
        
        // Load saved preference
        if (this.options.savePreference) {
            const saved = this.loadThemePreference();
            if (saved && this.themeData.has(saved)) {
                theme = saved;
            }
        }
        
        // Auto-detect system preference if no saved preference
        if (this.options.autoDetect && !this.loadThemePreference()) {
            const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
            theme = prefersDark ? 'dark' : 'light';
        }
        
        this.setTheme(theme, false);
    }

    createThemeControls() {
        const existingControls = document.querySelector('.theme-controls');
        if (existingControls) return;
        
        const controls = document.createElement('div');
        controls.className = 'theme-controls';
        controls.innerHTML = `
            <div class="theme-toggle">
                <button class="theme-toggle-btn" title="Toggle theme" aria-label="Toggle theme">
                    <span class="theme-icon"></span>
                </button>
                <div class="theme-dropdown hidden">
                    <div class="theme-dropdown-header">Choose Theme</div>
                    <div class="theme-options">
                        ${Array.from(this.themeData.keys()).map(themeId => {
                            const theme = this.themeData.get(themeId);
                            return `
                                <button class="theme-option" data-theme="${themeId}">
                                    <div class="theme-preview">
                                        <div class="theme-color" style="background: ${theme.colors.primary}"></div>
                                        <div class="theme-color" style="background: ${theme.colors.secondary}"></div>
                                        <div class="theme-color" style="background: ${theme.colors.accent}"></div>
                                    </div>
                                    <div class="theme-info">
                                        <div class="theme-name">${theme.name}</div>
                                        <div class="theme-description">${theme.description}</div>
                                    </div>
                                </button>
                            `;
                        }).join('')}
                    </div>
                    <div class="theme-dropdown-footer">
                        <button class="theme-custom-btn">Customize</button>
                    </div>
                </div>
            </div>
        `;
        
        // Add to page
        document.body.appendChild(controls);
        
        // Setup event listeners
        this.setupControlEvents(controls);
    }

    setupControlEvents(controls) {
        const toggleBtn = controls.querySelector('.theme-toggle-btn');
        const dropdown = controls.querySelector('.theme-dropdown');
        const options = controls.querySelectorAll('.theme-option');
        const customBtn = controls.querySelector('.theme-custom-btn');
        
        // Toggle dropdown
        toggleBtn.addEventListener('click', () => {
            dropdown.classList.toggle('hidden');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', (event) => {
            if (!controls.contains(event.target)) {
                dropdown.classList.add('hidden');
            }
        });
        
        // Theme selection
        options.forEach(option => {
            option.addEventListener('click', () => {
                const themeId = option.dataset.theme;
                this.setTheme(themeId);
                dropdown.classList.add('hidden');
            });
        });
        
        // Custom theme builder
        if (customBtn) {
            customBtn.addEventListener('click', () => {
                this.openThemeCustomizer();
            });
        }
    }

    async setTheme(themeId, animate = true) {
        if (!this.themeData.has(themeId) || this.isTransitioning) {
            return false;
        }
        
        this.previousTheme = this.currentTheme;
        this.currentTheme = themeId;
        
        if (animate && this.options.smoothTransition) {
            await this.animateThemeTransition(themeId);
        } else {
            this.applyTheme(themeId);
        }
        
        // Save preference
        if (this.options.savePreference) {
            this.saveThemePreference(themeId);
        }
        
        // Update controls
        this.updateThemeControls();
        
        // Notify listeners
        this.notifyThemeChange(themeId);
        
        return true;
    }

    async animateThemeTransition(themeId) {
        if (!this.options.smoothTransition) {
            this.applyTheme(themeId);
            return;
        }
        
        this.isTransitioning = true;
        
        try {
            // Create transition overlay
            const overlay = this.createTransitionOverlay();
            
            // Quantum effects for transition
            if (this.options.quantumEffects) {
                await this.playQuantumTransition(themeId);
            }
            
            // Apply new theme
            this.applyTheme(themeId);
            
            // Animate overlay out
            overlay.style.opacity = '0';
            
            await new Promise(resolve => {
                setTimeout(() => {
                    overlay.remove();
                    resolve();
                }, this.options.transitionDuration);
            });
            
        } finally {
            this.isTransitioning = false;
        }
    }

    createTransitionOverlay() {
        const overlay = document.createElement('div');
        overlay.className = 'theme-transition-overlay';
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--theme-background);
            z-index: 10000;
            opacity: 0;
            transition: opacity ${this.options.transitionDuration}ms ease;
            pointer-events: none;
        `;
        
        document.body.appendChild(overlay);
        
        // Trigger animation
        requestAnimationFrame(() => {
            overlay.style.opacity = '0.8';
        });
        
        return overlay;
    }

    async playQuantumTransition(themeId) {
        const theme = this.themeData.get(themeId);
        if (!theme) return;
        
        // Create quantum particles for transition
        const particleContainer = document.createElement('div');
        particleContainer.className = 'quantum-transition-particles';
        particleContainer.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 10001;
            pointer-events: none;
        `;
        
        document.body.appendChild(particleContainer);
        
        // Create particles with theme colors
        for (let i = 0; i < 20; i++) {
            const particle = document.createElement('div');
            particle.className = 'quantum-particle';
            particle.style.cssText = `
                position: absolute;
                width: 6px;
                height: 6px;
                background: ${theme.colors.primary};
                border-radius: 50%;
                left: ${Math.random() * 100}%;
                top: ${Math.random() * 100}%;
                animation: quantumFloat ${2 + Math.random() * 2}s ease-in-out infinite;
                opacity: 0.8;
                box-shadow: 0 0 10px ${theme.colors.primary};
            `;
            particleContainer.appendChild(particle);
        }
        
        await new Promise(resolve => {
            setTimeout(() => {
                particleContainer.remove();
                resolve();
            }, this.options.transitionDuration);
        });
    }

    applyTheme(themeId) {
        const theme = this.themeData.get(themeId);
        if (!theme) return;
        
        const root = document.documentElement;
        
        // Apply color variables
        Object.keys(theme.colors).forEach(colorKey => {
            root.style.setProperty(`--theme-${colorKey}`, theme.colors[colorKey]);
        });
        
        // Apply property variables
        if (theme.properties) {
            Object.keys(theme.properties).forEach(propKey => {
                const value = theme.properties[propKey];
                if (typeof value === 'object') {
                    // Handle nested properties like shadows, transitions
                    Object.keys(value).forEach(subKey => {
                        root.style.setProperty(`--theme-${propKey}-${subKey}`, value[subKey]);
                    });
                } else {
                    root.style.setProperty(`--theme-${propKey}`, value);
                }
            });
        }
        
        // Update body class
        document.body.className = document.body.className.replace(/theme-\w+/g, '');
        document.body.classList.add(`theme-${themeId}`);
        
        // Update meta theme-color for mobile browsers
        this.updateMetaThemeColor(theme.colors.primary);
    }

    updateMetaThemeColor(color) {
        let metaTag = document.querySelector('meta[name="theme-color"]');
        if (!metaTag) {
            metaTag = document.createElement('meta');
            metaTag.name = 'theme-color';
            document.head.appendChild(metaTag);
        }
        metaTag.content = color;
    }

    updateThemeControls() {
        const controls = document.querySelector('.theme-controls');
        if (!controls) return;
        
        const options = controls.querySelectorAll('.theme-option');
        options.forEach(option => {
            option.classList.toggle('active', option.dataset.theme === this.currentTheme);
        });
        
        // Update icon
        const icon = controls.querySelector('.theme-icon');
        if (icon) {
            icon.className = `theme-icon theme-icon-${this.currentTheme}`;
        }
    }

    initQuantumEffects() {
        // Add quantum CSS animations
        if (!document.querySelector('#quantum-theme-styles')) {
            const style = document.createElement('style');
            style.id = 'quantum-theme-styles';
            style.textContent = `
                @keyframes quantumFloat {
                    0%, 100% { transform: translateY(0) scale(1); opacity: 0.8; }
                    50% { transform: translateY(-20px) scale(1.2); opacity: 1; }
                }
                
                @keyframes quantumPulse {
                    0%, 100% { box-shadow: 0 0 5px var(--theme-primary); }
                    50% { box-shadow: 0 0 20px var(--theme-primary), 0 0 30px var(--theme-primary); }
                }
                
                .quantum-transition-particles {
                    animation: quantumPulse 2s ease-in-out infinite;
                }
            `;
            document.head.appendChild(style);
        }
    }

    openThemeCustomizer() {
        // Create theme customizer modal
        const modal = document.createElement('div');
        modal.className = 'theme-customizer-modal';
        modal.innerHTML = `
            <div class="theme-customizer-overlay"></div>
            <div class="theme-customizer-content">
                <div class="theme-customizer-header">
                    <h2>Theme Customizer</h2>
                    <button class="theme-customizer-close">&times;</button>
                </div>
                <div class="theme-customizer-body">
                    <div class="color-section">
                        <h3>Colors</h3>
                        <div class="color-inputs">
                            ${Object.keys(this.themeData.get(this.currentTheme).colors).map(colorKey => `
                                <div class="color-input-group">
                                    <label for="color-${colorKey}">${colorKey.charAt(0).toUpperCase() + colorKey.slice(1)}:</label>
                                    <input type="color" id="color-${colorKey}" value="${this.themeData.get(this.currentTheme).colors[colorKey]}">
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
                <div class="theme-customizer-footer">
                    <button class="btn-secondary" data-action="reset">Reset</button>
                    <button class="btn-primary" data-action="apply">Apply</button>
                    <button class="btn-primary" data-action="save">Save as Custom</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Setup modal events
        this.setupCustomizerEvents(modal);
    }

    setupCustomizerEvents(modal) {
        const overlay = modal.querySelector('.theme-customizer-overlay');
        const closeBtn = modal.querySelector('.theme-customizer-close');
        const colorInputs = modal.querySelectorAll('input[type="color"]');
        const buttons = modal.querySelectorAll('[data-action]');
        
        // Close modal
        [overlay, closeBtn].forEach(element => {
            element.addEventListener('click', () => {
                modal.remove();
            });
        });
        
        // Real-time color preview
        colorInputs.forEach(input => {
            input.addEventListener('input', () => {
                this.previewCustomTheme(modal);
            });
        });
        
        // Button actions
        buttons.forEach(button => {
            button.addEventListener('click', () => {
                const action = button.dataset.action;
                this.handleCustomizerAction(action, modal);
            });
        });
    }

    previewCustomTheme(modal) {
        const colorInputs = modal.querySelectorAll('input[type="color"]');
        const customColors = {};
        
        colorInputs.forEach(input => {
            const colorKey = input.id.replace('color-', '');
            customColors[colorKey] = input.value;
        });
        
        // Apply preview
        const root = document.documentElement;
        Object.keys(customColors).forEach(colorKey => {
            root.style.setProperty(`--theme-${colorKey}`, customColors[colorKey]);
        });
    }

    handleCustomizerAction(action, modal) {
        switch (action) {
            case 'reset':
                this.applyTheme(this.currentTheme);
                modal.remove();
                break;
                
            case 'apply':
                // Keep current preview
                modal.remove();
                break;
                
            case 'save':
                this.saveCustomTheme(modal);
                break;
        }
    }

    saveCustomTheme(modal) {
        const colorInputs = modal.querySelectorAll('input[type="color"]');
        const customColors = {};
        
        colorInputs.forEach(input => {
            const colorKey = input.id.replace('color-', '');
            customColors[colorKey] = input.value;
        });
        
        const themeName = prompt('Enter a name for your custom theme:');
        if (!themeName) return;
        
        const customThemeId = `custom-${Date.now()}`;
        const baseTheme = this.themeData.get(this.currentTheme);
        
        const customTheme = {
            ...baseTheme,
            name: themeName,
            description: 'Custom theme',
            colors: customColors
        };
        
        this.themeData.set(customThemeId, customTheme);
        this.options.availableThemes.push(customThemeId);
        
        // Save to storage
        this.saveCustomThemes();
        
        // Update controls
        this.updateThemeOptions();
        
        modal.remove();
    }

    // Event handlers
    handleSystemThemeChange(event) {
        if (!this.options.autoDetect) return;
        
        const newTheme = event.matches ? 'dark' : 'light';
        if (this.themeData.has(newTheme)) {
            this.setTheme(newTheme);
        }
    }

    handleKeyboardShortcuts(event) {
        // Ctrl/Cmd + Shift + T to toggle theme
        if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key === 'T') {
            event.preventDefault();
            this.toggleTheme();
        }
    }

    // Utility methods
    toggleTheme() {
        const currentIndex = this.options.availableThemes.indexOf(this.currentTheme);
        const nextIndex = (currentIndex + 1) % this.options.availableThemes.length;
        const nextTheme = this.options.availableThemes[nextIndex];
        
        this.setTheme(nextTheme);
    }

    getCurrentTheme() {
        return this.currentTheme;
    }

    getThemeData(themeId) {
        return this.themeData.get(themeId || this.currentTheme);
    }

    isThemeAvailable(themeId) {
        return this.themeData.has(themeId);
    }

    // Storage methods
    loadThemePreference() {
        try {
            return localStorage.getItem(this.options.storageKey);
        } catch (error) {
            console.warn('Failed to load theme preference:', error);
            return null;
        }
    }

    saveThemePreference(themeId) {
        try {
            localStorage.setItem(this.options.storageKey, themeId);
        } catch (error) {
            console.warn('Failed to save theme preference:', error);
        }
    }

    saveCustomThemes() {
        try {
            const customThemes = {};
            this.themeData.forEach((theme, id) => {
                if (id.startsWith('custom-')) {
                    customThemes[id] = theme;
                }
            });
            localStorage.setItem(`${this.options.storageKey}-custom`, JSON.stringify(customThemes));
        } catch (error) {
            console.warn('Failed to save custom themes:', error);
        }
    }

    loadCustomThemes() {
        try {
            const saved = localStorage.getItem(`${this.options.storageKey}-custom`);
            if (saved) {
                const customThemes = JSON.parse(saved);
                Object.keys(customThemes).forEach(id => {
                    this.themeData.set(id, customThemes[id]);
                    if (!this.options.availableThemes.includes(id)) {
                        this.options.availableThemes.push(id);
                    }
                });
            }
        } catch (error) {
            console.warn('Failed to load custom themes:', error);
        }
    }

    // Event system
    on(event, callback) {
        if (!this.callbacks.has(event)) {
            this.callbacks.set(event, []);
        }
        this.callbacks.get(event).push(callback);
    }

    off(event, callback) {
        if (this.callbacks.has(event)) {
            const callbacks = this.callbacks.get(event);
            const index = callbacks.indexOf(callback);
            if (index > -1) {
                callbacks.splice(index, 1);
            }
        }
    }

    notifyThemeChange(themeId) {
        if (this.callbacks.has('themechange')) {
            this.callbacks.get('themechange').forEach(callback => {
                try {
                    callback(themeId, this.previousTheme);
                } catch (error) {
                    console.error('Theme change callback error:', error);
                }
            });
        }
    }

    // Public API
    getAvailableThemes() {
        return this.options.availableThemes.map(id => ({
            id,
            ...this.themeData.get(id)
        }));
    }

    addCustomTheme(id, themeData) {
        this.themeData.set(id, themeData);
        if (!this.options.availableThemes.includes(id)) {
            this.options.availableThemes.push(id);
        }
        this.updateThemeOptions();
    }

    removeCustomTheme(id) {
        if (id.startsWith('custom-')) {
            this.themeData.delete(id);
            const index = this.options.availableThemes.indexOf(id);
            if (index > -1) {
                this.options.availableThemes.splice(index, 1);
            }
            this.updateThemeOptions();
        }
    }

    updateThemeOptions() {
        const controls = document.querySelector('.theme-controls');
        if (controls) {
            controls.remove();
            this.createThemeControls();
        }
    }

    destroy() {
        // Clean up event listeners
        const controls = document.querySelector('.theme-controls');
        if (controls) {
            controls.remove();
        }
        
        // Clear callbacks
        this.callbacks.clear();
    }
}

// Theme utility functions
const ThemeUtils = {
    // Auto-initialize theme system
    autoInit() {
        document.addEventListener('DOMContentLoaded', () => {
            if (!window.themeManager) {
                window.themeManager = new ThemeManager();
            }
        });
    },

    // Get system theme preference
    getSystemTheme() {
        if (window.matchMedia) {
            return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        }
        return 'light';
    },

    // Convert hex to RGB
    hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16)
        } : null;
    },

    // Convert RGB to hex
    rgbToHex(r, g, b) {
        return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
    },

    // Generate color palette from base color
    generatePalette(baseColor) {
        const rgb = this.hexToRgb(baseColor);
        if (!rgb) return {};
        
        return {
            light: this.rgbToHex(
                Math.min(255, rgb.r + 40),
                Math.min(255, rgb.g + 40),
                Math.min(255, rgb.b + 40)
            ),
            dark: this.rgbToHex(
                Math.max(0, rgb.r - 40),
                Math.max(0, rgb.g - 40),
                Math.max(0, rgb.b - 40)
            )
        };
    }
};

// Auto-initialize theme system
ThemeUtils.autoInit();

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { ThemeManager, ThemeUtils };
}

// Global access
window.ThemeManager = ThemeManager;
window.ThemeUtils = ThemeUtils;
