// 完整的聊天功能端到端测试
async function runEndToEndChatTest() {
    console.log('🚀 开始端到端聊天功能测试...');
    const results = {
        passed: 0,
        failed: 0,
        tests: []
    };

    function addTest(name, passed, details = '') {
        results.tests.push({ name, passed, details });
        if (passed) results.passed++;
        else results.failed++;
        console.log(`${passed ? '✅' : '❌'} ${name} ${details ? `- ${details}` : ''}`);
    }

    try {
        // 1. 测试服务器健康状态
        console.log('\n📊 1. 服务器健康检查...');
        try {
            const healthResponse = await fetch('/health');
            const healthData = await healthResponse.json();
            addTest('服务器健康检查', healthResponse.ok && healthData.status === 'healthy', `数据库: ${healthData.database}`);
        } catch (error) {
            addTest('服务器健康检查', false, error.message);
        }

        // 2. 测试聊天API连接
        console.log('\n💬 2. 聊天API连接测试...');
        try {
            const chatResponse = await fetch('/api/chat/deepseek-chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    text: '这是一个API连接测试消息',
                    temperature: 0.7
                })
            });
            const chatData = await chatResponse.json();
            addTest('聊天API连接', chatResponse.ok && chatData.success, `响应长度: ${chatData.assistantText?.length || 0}`);
        } catch (error) {
            addTest('聊天API连接', false, error.message);
        }

        // 3. 测试页面元素存在性
        console.log('\n🎨 3. 页面元素检查...');
        const requiredElements = [
            'messageInput', 'sendButton', 'chatMessages', 
            'guestModeButton', 'recordButton', 'settingsBtn'
        ];
        
        for (const elementId of requiredElements) {
            const element = document.getElementById(elementId);
            addTest(`元素 ${elementId}`, element !== null, element ? '存在' : '缺失');
        }

        // 4. 测试聊天模块加载
        console.log('\n📦 4. 聊天模块加载检查...');
        const hasCore = typeof ChatCore !== 'undefined';
        const hasUI = typeof ChatUI !== 'undefined';
        const hasAPI = typeof ChatAPI !== 'undefined';
        const hasInstance = typeof window.chatInstance !== 'undefined' && window.chatInstance !== null;
        
        addTest('ChatCore模块', hasCore);
        addTest('ChatUI模块', hasUI);
        addTest('ChatAPI模块', hasAPI);
        addTest('chatInstance实例', hasInstance);

        // 5. 测试访客模式激活
        console.log('\n👤 5. 访客模式测试...');
        const guestButton = document.getElementById('guestModeButton');
        if (guestButton) {
            guestButton.click();
            await new Promise(resolve => setTimeout(resolve, 500));
            const guestMode = localStorage.getItem('guestMode');
            addTest('访客模式激活', guestMode === 'true');
        } else {
            addTest('访客模式激活', false, '按钮不存在');
        }

        // 6. 测试消息发送功能
        console.log('\n📝 6. 消息发送测试...');
        const messageInput = document.getElementById('messageInput');
        const sendButton = document.getElementById('sendButton');
        
        if (messageInput && sendButton) {
            const testMessage = '这是一条端到端测试消息 ' + Date.now();
            messageInput.value = testMessage;
            messageInput.dispatchEvent(new Event('input'));
            
            // 检查发送按钮是否启用
            addTest('发送按钮启用', !sendButton.disabled);
            
            // 记录发送前的消息数量
            const chatMessages = document.getElementById('chatMessages');
            const messageCountBefore = chatMessages.children.length;
            
            // 点击发送
            sendButton.click();
            
            // 等待一段时间让消息处理
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            const messageCountAfter = chatMessages.children.length;
            addTest('消息添加到界面', messageCountAfter > messageCountBefore, `消息数量: ${messageCountBefore} → ${messageCountAfter}`);
        } else {
            addTest('消息发送测试', false, '输入框或按钮缺失');
        }

        // 7. 测试回车键发送
        console.log('\n⌨️ 7. 回车键发送测试...');
        if (messageInput) {
            messageInput.value = '回车键测试消息';
            const enterEvent = new KeyboardEvent('keydown', {
                key: 'Enter',
                keyCode: 13,
                which: 13
            });
            messageInput.dispatchEvent(enterEvent);
            addTest('回车键发送', true, '事件已触发');
        } else {
            addTest('回车键发送', false, '输入框不存在');
        }

        // 8. 测试UI响应性
        console.log('\n🎯 8. UI响应性测试...');
        const settingsBtn = document.getElementById('settingsBtn');
        const historyBtn = document.getElementById('historyBtn');
        
        addTest('设置按钮响应', settingsBtn && settingsBtn.onclick !== null);
        addTest('历史按钮响应', historyBtn && historyBtn.onclick !== null);

    } catch (error) {
        console.error('测试过程中发生错误:', error);
        addTest('测试执行', false, error.message);
    }

    // 显示测试结果摘要
    console.log('\n' + '='.repeat(50));
    console.log('📊 端到端测试结果摘要');
    console.log('='.repeat(50));
    console.log(`✅ 通过: ${results.passed} 项`);
    console.log(`❌ 失败: ${results.failed} 项`);
    console.log(`📊 成功率: ${Math.round((results.passed / (results.passed + results.failed)) * 100)}%`);
    
    // 详细结果
    console.log('\n📋 详细测试结果:');
    results.tests.forEach(test => {
        console.log(`${test.passed ? '✅' : '❌'} ${test.name} ${test.details ? `- ${test.details}` : ''}`);
    });

    // 如果有失败的测试，显示建议
    if (results.failed > 0) {
        console.log('\n🔧 修复建议:');
        results.tests.filter(t => !t.passed).forEach(test => {
            if (test.name.includes('服务器')) {
                console.log('• 检查服务器是否正在运行');
            } else if (test.name.includes('API')) {
                console.log('• 检查API路由配置和网络连接');
            } else if (test.name.includes('元素')) {
                console.log('• 检查HTML模板和DOM结构');
            } else if (test.name.includes('模块')) {
                console.log('• 检查JavaScript模块导入和初始化');
            }
        });
    }

    return results;
}

// 自动运行测试（延迟3秒确保页面完全加载）
setTimeout(() => {
    console.log('🏁 准备运行端到端测试...');
    runEndToEndChatTest().then(results => {
        console.log('🎉 端到端测试完成！');
        window.testResults = results; // 保存结果供后续查看
    });
}, 3000);
