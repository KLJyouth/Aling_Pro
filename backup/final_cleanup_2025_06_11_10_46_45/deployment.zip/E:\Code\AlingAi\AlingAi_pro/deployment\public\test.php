<?php
// 简单测试页面
echo "Test page is working!";
phpinfo();
?>
