// 前端功能增强脚本
// 包含动画系统、聊天功能和无障碍功能
// 创建时间: 2025-05-30

console.log('🎨 加载前端功能增强模块...');

// 动画系统类
class AnimationSystem {
    constructor() {
        this.particles = [];
        this.particleCanvas = null;
        this.particleCtx = null;
        this.matrixCanvas = null;
        this.matrixCtx = null;
        this.matrixDrops = [];
        
        this.initAnimations();
        console.log('✨ 动画系统初始化完成');
    }
    
    initAnimations() {
        this.initParticleSystem();
        this.initMatrixEffect();
        this.startAnimationLoop();
    }
    
    initParticleSystem() {
        this.particleCanvas = document.getElementById('particleCanvas');
        if (!this.particleCanvas) return;
        
        this.particleCtx = this.particleCanvas.getContext('2d');
        this.resizeParticleCanvas();
        
        // 创建粒子
        for (let i = 0; i < 50; i++) {
            this.particles.push({
                x: Math.random() * this.particleCanvas.width,
                y: Math.random() * this.particleCanvas.height,
                vx: (Math.random() - 0.5) * 0.5,
                vy: (Math.random() - 0.5) * 0.5,
                radius: Math.random() * 2 + 1,
                opacity: Math.random() * 0.5 + 0.2
            });
        }
        
        window.addEventListener('resize', () => this.resizeParticleCanvas());
    }
    
    initMatrixEffect() {
        this.matrixCanvas = document.getElementById('matrixCanvas');
        if (!this.matrixCanvas) return;
        
        this.matrixCtx = this.matrixCanvas.getContext('2d');
        this.resizeMatrixCanvas();
        
        const columns = Math.floor(this.matrixCanvas.width / 20);
        for (let i = 0; i < columns; i++) {
            this.matrixDrops[i] = Math.random() * -100;
        }
        
        window.addEventListener('resize', () => this.resizeMatrixCanvas());
    }
    
    resizeParticleCanvas() {
        if (!this.particleCanvas) return;
        this.particleCanvas.width = window.innerWidth;
        this.particleCanvas.height = window.innerHeight;
    }
    
    resizeMatrixCanvas() {
        if (!this.matrixCanvas) return;
        this.matrixCanvas.width = window.innerWidth;
        this.matrixCanvas.height = window.innerHeight;
    }
    
    updateParticles() {
        if (!this.particleCtx) return;
        
        this.particleCtx.clearRect(0, 0, this.particleCanvas.width, this.particleCanvas.height);
        
        this.particles.forEach(particle => {
            particle.x += particle.vx;
            particle.y += particle.vy;
            
            // 边界检测
            if (particle.x < 0 || particle.x > this.particleCanvas.width) particle.vx *= -1;
            if (particle.y < 0 || particle.y > this.particleCanvas.height) particle.vy *= -1;
            
            // 绘制粒子
            this.particleCtx.beginPath();
            this.particleCtx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
            this.particleCtx.fillStyle = `rgba(102, 126, 234, ${particle.opacity})`;
            this.particleCtx.fill();
        });
    }
    
    updateMatrixEffect() {
        if (!this.matrixCtx) return;
        
        this.matrixCtx.fillStyle = 'rgba(0, 0, 0, 0.05)';
        this.matrixCtx.fillRect(0, 0, this.matrixCanvas.width, this.matrixCanvas.height);
        
        this.matrixCtx.fillStyle = '#0f0';
        this.matrixCtx.font = '15px monospace';
        
        this.matrixDrops.forEach((drop, i) => {
            const text = String.fromCharCode(Math.random() * 128);
            const x = i * 20;
            const y = drop * 20;
            
            this.matrixCtx.fillText(text, x, y);
            
            if (y > this.matrixCanvas.height && Math.random() > 0.975) {
                this.matrixDrops[i] = 0;
            }
            
            this.matrixDrops[i]++;
        });
    }
    
    startAnimationLoop() {
        const animate = () => {
            this.updateParticles();
            this.updateMatrixEffect();
            requestAnimationFrame(animate);
        };
        animate();
    }
    
    showQuantumLoader() {
        const loader = document.getElementById('quantumLoader');
        if (loader) {
            loader.style.display = 'block';
        }
    }
    
    hideQuantumLoader() {
        const loader = document.getElementById('quantumLoader');
        if (loader) {
            loader.style.display = 'none';
        }
    }
}

// 聊天功能类
class ChatSystem {
    constructor() {
        this.isOpen = false;
        this.messages = [];
        this.initChat();
        console.log('💬 聊天系统初始化完成');
    }
    
    initChat() {
        // 初始化聊天界面
        const chatWidget = document.getElementById('chatWidget');
        const chatToggleBtn = document.getElementById('chatToggleBtn');
        
        if (chatToggleBtn) {
            chatToggleBtn.addEventListener('click', () => this.toggleChat());
        }
        
        // 添加初始消息
        this.addMessage('assistant', '👋 欢迎使用AlingAi综合检测系统！我可以帮您：\n• 解释检测结果\n• 提供系统状态信息\n• 回答技术问题');
    }
    
    toggleChat() {
        const chatWidget = document.getElementById('chatWidget');
        const chatToggleBtn = document.getElementById('chatToggleBtn');
        
        if (!chatWidget) return;
        
        this.isOpen = !this.isOpen;
        
        if (this.isOpen) {
            chatWidget.style.display = 'block';
            chatWidget.classList.add('show');
            chatToggleBtn.innerHTML = '<i class="bi bi-x"></i>';
        } else {
            chatWidget.style.display = 'none';
            chatWidget.classList.remove('show');
            chatToggleBtn.innerHTML = '<i class="bi bi-chat-dots"></i>';
        }
    }
    
    addMessage(type, content) {
        const messagesContainer = document.getElementById('chatMessages');
        if (!messagesContainer) return;
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${type}`;
        messageDiv.innerHTML = content.replace(/\n/g, '<br>');
        
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        this.messages.push({ type, content, timestamp: new Date().toISOString() });
    }
    
    sendMessage() {
        const input = document.getElementById('chatInput');
        if (!input || !input.value.trim()) return;
        
        const message = input.value.trim();
        this.addMessage('user', message);
        input.value = '';
        
        // 模拟AI回复
        setTimeout(() => {
            const response = this.generateResponse(message);
            this.addMessage('assistant', response);
        }, 1000);
    }
    
    generateResponse(message) {
        const responses = {
            '状态': '✅ 系统运行正常，所有核心功能已就绪。',
            '检测': '🔍 您可以使用快速检测或完整检测功能来验证系统状态。',
            '报告': '📊 检测报告可以导出为JSON或CSV格式，包含详细的系统信息。',
            '帮助': '🆘 我可以协助您进行系统检测、查看报告或解答技术问题。',
            '功能': '⚡ 系统包含动画效果、聊天功能、无障碍支持等多种特性。'
        };
        
        for (const [key, response] of Object.entries(responses)) {
            if (message.includes(key)) {
                return response;
            }
        }
        
        return `🤖 收到您的消息："${message}"。我正在学习中，如需具体帮助请查看系统检测功能或联系技术支持。`;
    }
    
    handleKeyPress(event) {
        if (event.key === 'Enter') {
            this.sendMessage();
        }
    }
}

// 无障碍功能类
class AccessibilitySystem {
    constructor() {
        this.fontSize = 100;
        this.highContrast = false;
        this.screenReaderMode = false;
        this.toolbarVisible = true;
        
        this.initAccessibility();
        console.log('♿ 无障碍系统初始化完成');
    }
    
    initAccessibility() {
        // 键盘导航支持
        document.addEventListener('keydown', (event) => {
            if (event.altKey && event.key === 'a') {
                this.toggleAccessibilityToolbar();
            }
        });
        
        // 焦点管理
        this.addFocusStyles();
    }
    
    adjustFontSize(delta) {
        this.fontSize += delta * 10;
        this.fontSize = Math.max(80, Math.min(150, this.fontSize));
        
        document.body.style.fontSize = `${this.fontSize}%`;
        
        if (this.fontSize > 100) {
            document.body.classList.add('large-font');
        } else {
            document.body.classList.remove('large-font');
        }
        
        console.log(`📏 字体大小调整为: ${this.fontSize}%`);
    }
    
    toggleHighContrast() {
        this.highContrast = !this.highContrast;
        
        if (this.highContrast) {
            document.body.classList.add('high-contrast');
            console.log('🎨 高对比度模式已启用');
        } else {
            document.body.classList.remove('high-contrast');
            console.log('🎨 高对比度模式已关闭');
        }
    }
    
    toggleScreenReaderMode() {
        this.screenReaderMode = !this.screenReaderMode;
        
        if (this.screenReaderMode) {
            document.body.classList.add('screen-reader-mode');
            this.addAriaLabels();
            console.log('🔊 屏幕阅读器模式已启用');
        } else {
            document.body.classList.remove('screen-reader-mode');
            console.log('🔊 屏幕阅读器模式已关闭');
        }
    }
    
    toggleAccessibilityToolbar() {
        const toolbar = document.getElementById('accessibilityToolbar');
        if (!toolbar) return;
        
        this.toolbarVisible = !this.toolbarVisible;
        toolbar.style.display = this.toolbarVisible ? 'block' : 'none';
        
        console.log(`🛠️ 无障碍工具栏${this.toolbarVisible ? '显示' : '隐藏'}`);
    }
    
    addFocusStyles() {
        const style = document.createElement('style');
        style.textContent = `
            *:focus {
                outline: 3px solid #667eea !important;
                outline-offset: 2px;
            }
            
            button:focus, input:focus, select:focus, textarea:focus {
                box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.3) !important;
            }
        `;
        document.head.appendChild(style);
    }
    
    addAriaLabels() {
        // 为主要元素添加aria标签
        const buttons = document.querySelectorAll('button');
        buttons.forEach((btn, index) => {
            if (!btn.getAttribute('aria-label') && !btn.textContent.trim()) {
                btn.setAttribute('aria-label', `按钮 ${index + 1}`);
            }
        });
        
        const inputs = document.querySelectorAll('input');
        inputs.forEach((input, index) => {
            if (!input.getAttribute('aria-label') && !input.placeholder) {
                input.setAttribute('aria-label', `输入框 ${index + 1}`);
            }
        });
    }
}

// 前端资源管理器
class FrontendResourceManager {
    constructor() {
        this.resources = {
            css: 0,
            javascript: 0,
            domElements: 0
        };
        
        this.checkResources();
        console.log('🎨 前端资源管理器初始化完成');
    }
    
    checkResources() {
        // 检查CSS资源
        this.resources.css = document.styleSheets.length;
        
        // 检查JavaScript资源
        this.resources.javascript = document.scripts.length;
        
        // 检查DOM元素
        this.resources.domElements = document.querySelectorAll('*').length;
        
        console.log('📊 前端资源统计:', this.resources);
    }
    
    getResourceStatus() {
        return {
            css: this.resources.css > 0 ? 'loaded' : 'missing',
            javascript: this.resources.javascript > 0 ? 'loaded' : 'missing',
            domElements: this.resources.domElements > 10 ? 'loaded' : 'missing'
        };
    }
}

// 全局函数定义
function toggleChat() {
    if (window.chatSystem) {
        window.chatSystem.toggleChat();
    }
}

function sendChatMessage() {
    if (window.chatSystem) {
        window.chatSystem.sendMessage();
    }
}

function handleChatKeyPress(event) {
    if (window.chatSystem) {
        window.chatSystem.handleKeyPress(event);
    }
}

function adjustFontSize(delta) {
    if (window.accessibilitySystem) {
        window.accessibilitySystem.adjustFontSize(delta);
    }
}

function toggleHighContrast() {
    if (window.accessibilitySystem) {
        window.accessibilitySystem.toggleHighContrast();
    }
}

function toggleScreenReaderMode() {
    if (window.accessibilitySystem) {
        window.accessibilitySystem.toggleScreenReaderMode();
    }
}

function toggleAccessibilityToolbar() {
    if (window.accessibilitySystem) {
        window.accessibilitySystem.toggleAccessibilityToolbar();
    }
}

function showQuantumLoader() {
    if (window.animationSystem) {
        window.animationSystem.showQuantumLoader();
    }
}

function hideQuantumLoader() {
    if (window.animationSystem) {
        window.animationSystem.hideQuantumLoader();
    }
}

// 页面加载后初始化所有系统
document.addEventListener('DOMContentLoaded', function() {
    // 延迟初始化避免与其他脚本冲突
    setTimeout(() => {
        try {
            window.animationSystem = new AnimationSystem();
            window.chatSystem = new ChatSystem();
            window.accessibilitySystem = new AccessibilitySystem();
            window.frontendResourceManager = new FrontendResourceManager();
            
            console.log('✅ 所有前端功能系统初始化完成');
            
            // 创建全局聊天对象以供检测使用
            window.chatInstance = window.chatSystem;
            
        } catch (error) {
            console.error('❌ 前端功能系统初始化失败:', error);
        }
    }, 1000);
});

console.log('✅ 前端功能增强模块加载完成');
