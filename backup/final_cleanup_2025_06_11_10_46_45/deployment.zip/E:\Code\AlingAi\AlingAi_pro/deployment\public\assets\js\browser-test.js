// 修复验证脚本 - 在页面加载后自动运行
// 等待页面完全加载后开始测试

// 延迟执行，确保聊天模块有时间初始化
setTimeout(() => {
    console.log('🚀 开始验证聊天功能修复...');
    runChatFixVerification();
}, 2000);

function runChatFixVerification() {
    // 测试结果存储
    const testResults = {
        syntaxErrors: [],
        moduleLoading: false,
        domElements: {},
        guestMode: false,
        sendButton: false,
        inputFunction: false
    };

    // 1. 检查JavaScript语法错误
    console.log('1️⃣ 检查JavaScript语法错误...');
    const jsErrors = [];
    const originalError = console.error;
    console.error = function(...args) {
        const message = args.join(' ');
        if (message.includes('SyntaxError') || message.includes('Invalid left-hand side')) {
            jsErrors.push(message);
            testResults.syntaxErrors.push(message);
        }
        originalError.apply(console, args);
    };

    // 2. 检查聊天模块是否成功加载
    console.log('2️⃣ 检查聊天模块加载状态...');
    setTimeout(() => {
        testResults.moduleLoading = typeof window.chatInstance !== 'undefined' && window.chatInstance !== null;
        console.log(`📦 聊天实例: ${testResults.moduleLoading ? '✅ 已加载' : '❌ 未加载'}`);
        
        if (testResults.moduleLoading) {
            console.log('   - 聊天实例详情:', window.chatInstance);
        }
    }, 1000);

    // 3. 检查关键DOM元素
    console.log('3️⃣ 检查关键DOM元素...');
    const checkElements = {
        messageInput: 'messageInput',
        sendButton: 'sendButton', 
        guestModeBtn: 'guestModeBtn',
        messagesContainer: 'messages',
        darkModeSwitch: 'darkModeSwitch',
        voiceInputSwitch: 'voiceInputSwitch',
        autoTTSSwitch: 'autoTTSSwitch'
    };

    Object.entries(checkElements).forEach(([name, id]) => {
        const element = document.getElementById(id);
        testResults.domElements[name] = !!element;
        console.log(`   ${testResults.domElements[name] ? '✅' : '❌'} ${name}`);
    });

    // 4. 测试访客模式功能
    console.log('4️⃣ 测试访客模式功能...');
    const guestBtn = document.getElementById('guestModeBtn');
    if (guestBtn) {
        try {
            guestBtn.click();
            setTimeout(() => {
                testResults.guestMode = localStorage.getItem('guestMode') === 'true';
                console.log(`👤 访客模式: ${testResults.guestMode ? '✅ 已激活' : '❌ 未激活'}`);
            }, 500);
        } catch (error) {
            console.log('❌ 访客模式按钮点击失败:', error.message);
        }
    } else {
        console.log('❌ 找不到访客模式按钮');
    }

    // 5. 测试发送按钮状态控制
    console.log('5️⃣ 测试发送按钮状态控制...');
    const messageInput = document.getElementById('messageInput');
    const sendButton = document.getElementById('sendButton');

    if (messageInput && sendButton) {
        // 测试输入文本后按钮启用
        messageInput.value = '测试消息';
        messageInput.dispatchEvent(new Event('input', { bubbles: true }));
        
        setTimeout(() => {
            const enabledAfterInput = !sendButton.disabled;
            console.log(`📤 输入后发送按钮: ${enabledAfterInput ? '✅ 已启用' : '❌ 仍禁用'}`);
            
            // 测试清空后按钮禁用
            messageInput.value = '';
            messageInput.dispatchEvent(new Event('input', { bubbles: true }));
            
            setTimeout(() => {
                const disabledAfterClear = sendButton.disabled;
                console.log(`📤 清空后发送按钮: ${disabledAfterClear ? '✅ 已禁用' : '❌ 仍启用'}`);
                
                testResults.sendButton = enabledAfterInput && disabledAfterClear;
                testResults.inputFunction = true;
            }, 200);
        }, 200);
    } else {
        console.log('❌ 找不到消息输入框或发送按钮');
    }

    // 6. 检查开关控件功能（修复后的代码）
    console.log('6️⃣ 测试设置开关功能...');
    setTimeout(() => {
        const switches = ['darkModeSwitch', 'voiceInputSwitch', 'autoTTSSwitch'];
        let switchTests = 0;
        
        switches.forEach(switchId => {
            const switchElement = document.getElementById(switchId);
            if (switchElement) {
                try {
                    // 测试开关切换
                    const originalState = switchElement.checked;
                    switchElement.checked = !originalState;
                    switchElement.dispatchEvent(new Event('change', { bubbles: true }));
                    
                    // 恢复原状态
                    setTimeout(() => {
                        switchElement.checked = originalState;
                        switchElement.dispatchEvent(new Event('change', { bubbles: true }));
                    }, 100);
                    
                    switchTests++;
                    console.log(`   ✅ ${switchId} 功能正常`);
                } catch (error) {
                    console.log(`   ❌ ${switchId} 功能异常:`, error.message);
                }
            } else {
                console.log(`   ❌ 找不到 ${switchId}`);
            }
        });
        
        console.log(`🔧 开关测试: ${switchTests}/${switches.length} 通过`);
    }, 2000);

    // 7. 生成最终报告
    setTimeout(() => {
        console.log('\n📊 修复验证报告:');
        console.log('='.repeat(50));
        
        const tests = [
            { name: 'JavaScript语法错误', status: testResults.syntaxErrors.length === 0, detail: `${testResults.syntaxErrors.length} 个错误` },
            { name: '聊天模块加载', status: testResults.moduleLoading, detail: testResults.moduleLoading ? '成功' : '失败' },
            { name: 'DOM元素完整性', status: Object.values(testResults.domElements).every(v => v), detail: `${Object.values(testResults.domElements).filter(v => v).length}/${Object.keys(testResults.domElements).length}` },
            { name: '访客模式功能', status: testResults.guestMode, detail: testResults.guestMode ? '正常' : '异常' },
            { name: '发送按钮控制', status: testResults.sendButton, detail: testResults.sendButton ? '正常' : '异常' },
            { name: '输入功能', status: testResults.inputFunction, detail: testResults.inputFunction ? '正常' : '异常' }
        ];
        
        let passed = 0;
        tests.forEach(test => {
            const icon = test.status ? '✅' : '❌';
            console.log(`${icon} ${test.name}: ${test.detail}`);
            if (test.status) passed++;
        });
        
        const successRate = Math.round((passed / tests.length) * 100);
        console.log('\n📈 总体结果:');
        console.log(`✅ 通过: ${passed}/${tests.length} (${successRate}%)`);
        
        if (successRate >= 80) {
            console.log('🎉 聊天功能修复成功！');
        } else if (successRate >= 60) {
            console.log('⚠️  基本功能已修复，但仍需优化');
        } else {
            console.log('❌ 仍需进一步修复');
        }
        
        // 输出具体错误信息
        if (testResults.syntaxErrors.length > 0) {
            console.log('\n🐛 发现的错误:');
            testResults.syntaxErrors.forEach((error, index) => {
                console.log(`   ${index + 1}. ${error}`);
            });
        }
        
        console.log('\n💡 修复建议:');
        if (!testResults.moduleLoading) {
            console.log('   - 检查模块导入和初始化代码');
        }
        if (!testResults.guestMode) {
            console.log('   - 验证访客模式按钮事件监听器');
        }
        if (!testResults.sendButton) {
            console.log('   - 检查输入事件处理和按钮状态控制');
        }
        
        console.log('\n🔧 手动测试提示:');
        console.log('可以在控制台运行以下命令进行更多测试:');
        console.log('window.manualTestHelper.simulateMessage("测试消息")');
        console.log('window.manualTestHelper.checkChatObjects()');
        console.log('window.manualTestHelper.activateGuestMode()');
        
    }, 5000);

    console.log('⏳ 测试进行中，请等待结果...');
}
