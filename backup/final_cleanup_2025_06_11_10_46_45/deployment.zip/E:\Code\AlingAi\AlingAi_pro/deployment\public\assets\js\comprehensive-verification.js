// 聊天页面综合验证脚本
// 可以在浏览器控制台中运行此脚本来验证功能

console.log('🚀 开始聊天页面综合验证...');

// 延迟执行函数
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// 验证步骤
const verificationSteps = {
    // 1. DOM 元素验证
    async verifyDOMElements() {
        console.log('📋 验证 DOM 元素...');
        
        const requiredElements = {
            'loginModal': '登录模态框',
            'loginButton': '登录按钮', 
            'guestModeButton': '访客模式按钮',
            'userStatus': '用户状态显示',
            'messageInput': '消息输入框',
            'sendButton': '发送按钮',
            'chatMessages': '聊天消息区域',
            'recordButton': '语音输入按钮',
            'imageGenButton': '图像生成按钮',
            'ttsButton': '语音播放按钮',
            'historyBtn': '历史记录按钮',
            'settingsBtn': '设置按钮'
        };
        
        const results = {};
        for (const [id, desc] of Object.entries(requiredElements)) {
            const element = document.getElementById(id);
            results[id] = {
                exists: !!element,
                description: desc,
                element: element
            };
            
            console.log(`  ${results[id].exists ? '✅' : '❌'} ${desc} (${id})`);
        }
        
        const allExists = Object.values(results).every(r => r.exists);
        console.log(`📋 DOM元素验证 ${allExists ? '✅ 通过' : '❌ 失败'}`);
        
        return { success: allExists, results };
    },

    // 2. 聊天实例验证
    async verifyChatInstance() {
        console.log('🤖 验证聊天实例...');
        
        const hasInstance = !!window.chatInstance;
        const hasCore = hasInstance && !!window.chatInstance.core;
        const hasUI = hasInstance && !!window.chatInstance.ui;
        const hasAPI = hasInstance && !!window.chatInstance.api;
        
        console.log(`  ${hasInstance ? '✅' : '❌'} 聊天实例存在`);
        console.log(`  ${hasCore ? '✅' : '❌'} Core 模块加载`);
        console.log(`  ${hasUI ? '✅' : '❌'} UI 模块加载`);
        console.log(`  ${hasAPI ? '✅' : '❌'} API 模块加载`);
        
        if (hasAPI) {
            const apiInitialized = window.chatInstance.api.isInitialized;
            console.log(`  ${apiInitialized ? '✅' : '❌'} API 已初始化`);
        }
        
        const allOK = hasInstance && hasCore && hasUI && hasAPI;
        console.log(`🤖 聊天实例验证 ${allOK ? '✅ 通过' : '❌ 失败'}`);
        
        return { success: allOK, instance: window.chatInstance };
    },

    // 3. 访客模式验证
    async verifyGuestMode() {
        console.log('👤 验证访客模式...');
        
        // 清除之前的状态
        localStorage.removeItem('guestMode');
        localStorage.removeItem('token');
        
        const guestBtn = document.getElementById('guestModeButton');
        const userStatus = document.getElementById('userStatus');
        
        if (!guestBtn) {
            console.log('  ❌ 访客模式按钮不存在');
            return { success: false };
        }
        
        // 模拟点击访客模式按钮
        console.log('  🔄 点击访客模式按钮...');
        guestBtn.click();
        
        await delay(500);
        
        // 检查状态
        const guestModeSet = localStorage.getItem('guestMode') === 'true';
        const statusText = userStatus ? userStatus.textContent : '';
        
        console.log(`  ${guestModeSet ? '✅' : '❌'} 访客模式状态设置`);
        console.log(`  ${statusText.includes('访客') ? '✅' : '❌'} 用户状态显示: "${statusText}"`);
        
        const success = guestModeSet && statusText.includes('访客');
        console.log(`👤 访客模式验证 ${success ? '✅ 通过' : '❌ 失败'}`);
        
        return { success, guestModeSet, statusText };
    },

    // 4. 消息输入验证
    async verifyMessageInput() {
        console.log('💬 验证消息输入...');
        
        const messageInput = document.getElementById('messageInput');
        const sendButton = document.getElementById('sendButton');
        
        if (!messageInput || !sendButton) {
            console.log('  ❌ 输入元素不存在');
            return { success: false };
        }
        
        // 测试空输入
        messageInput.value = '';
        messageInput.dispatchEvent(new Event('input'));
        await delay(100);
        
        const emptyDisabled = sendButton.disabled;
        console.log(`  ${emptyDisabled ? '✅' : '❌'} 空输入时按钮禁用`);
        
        // 测试有内容输入
        messageInput.value = '测试消息';
        messageInput.dispatchEvent(new Event('input'));
        await delay(100);
        
        const textEnabled = !sendButton.disabled;
        console.log(`  ${textEnabled ? '✅' : '❌'} 有内容时按钮启用`);
        
        // 清空输入
        messageInput.value = '';
        
        const success = emptyDisabled && textEnabled;
        console.log(`💬 消息输入验证 ${success ? '✅ 通过' : '❌ 失败'}`);
        
        return { success, emptyDisabled, textEnabled };
    },

    // 5. 消息发送验证（访客模式）
    async verifyMessageSending() {
        console.log('📤 验证消息发送（访客模式）...');
        
        // 确保在访客模式
        localStorage.setItem('guestMode', 'true');
        
        const messageInput = document.getElementById('messageInput');
        const sendButton = document.getElementById('sendButton');
        const chatMessages = document.getElementById('chatMessages');
        
        if (!messageInput || !sendButton || !chatMessages) {
            console.log('  ❌ 必要元素不存在');
            return { success: false };
        }
        
        // 记录初始消息数量
        const initialMessageCount = chatMessages.children.length;
        
        // 发送测试消息
        const testMessage = '这是一条自动化测试消息';
        messageInput.value = testMessage;
        messageInput.dispatchEvent(new Event('input'));
        
        console.log('  🔄 发送测试消息...');
        sendButton.click();
        
        // 等待处理
        await delay(2000);
        
        // 检查结果
        const finalMessageCount = chatMessages.children.length;
        const messagesAdded = finalMessageCount > initialMessageCount;
        const inputCleared = messageInput.value === '';
        
        console.log(`  ${messagesAdded ? '✅' : '❌'} 消息已添加到界面`);
        console.log(`  ${inputCleared ? '✅' : '❌'} 输入框已清空`);
        console.log(`  📊 消息数量: ${initialMessageCount} → ${finalMessageCount}`);
        
        // 检查是否有访客模式回复
        const messages = Array.from(chatMessages.querySelectorAll('.message, [class*="message"]'));
        const hasGuestResponse = messages.some(msg => 
            msg.textContent && msg.textContent.includes('访客模式')
        );
        
        console.log(`  ${hasGuestResponse ? '✅' : '❌'} 收到访客模式回复`);
        
        const success = messagesAdded && inputCleared && hasGuestResponse;
        console.log(`📤 消息发送验证 ${success ? '✅ 通过' : '❌ 失败'}`);
        
        return { 
            success, 
            messagesAdded, 
            inputCleared, 
            hasGuestResponse,
            messageCount: { initial: initialMessageCount, final: finalMessageCount }
        };
    },

    // 6. 按钮功能验证
    async verifyButtonFunctions() {
        console.log('🔘 验证按钮功能...');
        
        const buttons = [
            { id: 'historyBtn', name: '历史记录' },
            { id: 'settingsBtn', name: '设置' },
            { id: 'recordButton', name: '语音输入' },
            { id: 'imageGenButton', name: '图像生成' },
            { id: 'ttsButton', name: '语音播放' }
        ];
        
        const results = {};
        
        for (const button of buttons) {
            const element = document.getElementById(button.id);
            if (element) {
                try {
                    element.click();
                    await delay(300);
                    results[button.id] = { success: true, error: null };
                    console.log(`  ✅ ${button.name}按钮可点击`);
                } catch (error) {
                    results[button.id] = { success: false, error: error.message };
                    console.log(`  ❌ ${button.name}按钮错误: ${error.message}`);
                }
            } else {
                results[button.id] = { success: false, error: '按钮不存在' };
                console.log(`  ❌ ${button.name}按钮不存在`);
            }
        }
        
        const allWorking = Object.values(results).every(r => r.success);
        console.log(`🔘 按钮功能验证 ${allWorking ? '✅ 通过' : '⚠️ 部分通过'}`);
        
        return { success: allWorking, results };
    }
};

// 主验证函数
async function runComprehensiveVerification() {
    console.log('🎯 开始综合功能验证...\n');
    
    const results = {};
    
    try {
        // 等待页面完全加载
        await delay(1000);
        
        // 运行所有验证步骤
        results.domElements = await verificationSteps.verifyDOMElements();
        console.log('');
        
        results.chatInstance = await verificationSteps.verifyChatInstance();
        console.log('');
        
        results.guestMode = await verificationSteps.verifyGuestMode();
        console.log('');
        
        results.messageInput = await verificationSteps.verifyMessageInput();
        console.log('');
        
        results.messageSending = await verificationSteps.verifyMessageSending();
        console.log('');
        
        results.buttonFunctions = await verificationSteps.verifyButtonFunctions();
        console.log('');
        
        // 生成总结报告
        const allTests = Object.values(results);
        const passedTests = allTests.filter(test => test.success).length;
        const totalTests = allTests.length;
        
        console.log('📊 验证结果总结:');
        console.log(`   总测试数: ${totalTests}`);
        console.log(`   通过测试: ${passedTests}`);
        console.log(`   失败测试: ${totalTests - passedTests}`);
        console.log(`   成功率: ${Math.round((passedTests / totalTests) * 100)}%`);
        
        if (passedTests === totalTests) {
            console.log('🎉 所有功能验证通过！聊天页面运行正常。');
        } else {
            console.log('⚠️ 部分功能需要进一步优化。');
        }
        
        return results;
        
    } catch (error) {
        console.error('❌ 验证过程中发生错误:', error);
        return { error: error.message, results };
    }
}

// 自动运行验证（如果在浏览器中）
if (typeof window !== 'undefined') {
    // 页面加载完成后自动运行
    if (document.readyState === 'complete') {
        setTimeout(runComprehensiveVerification, 1500);
    } else {
        window.addEventListener('load', () => {
            setTimeout(runComprehensiveVerification, 1500);
        });
    }
    
    // 添加到全局以便手动调用
    window.chatVerification = {
        runComprehensiveVerification,
        verificationSteps
    };
}

console.log('ℹ️ 验证脚本已加载。如需手动运行，请调用: chatVerification.runComprehensiveVerification()');
