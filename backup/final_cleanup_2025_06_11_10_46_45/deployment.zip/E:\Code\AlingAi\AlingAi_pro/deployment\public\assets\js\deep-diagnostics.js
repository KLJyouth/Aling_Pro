/**
 * 深度诊断脚本 - 检查聊天系统的每个组件
 * 用于发现潜在问题并提供详细的诊断信息
 */

class ChatSystemDiagnostics {
    constructor() {
        this.diagnosticResults = [];
        this.issues = [];
        this.recommendations = [];
    }

    log(category, message, level = 'info') {
        const timestamp = new Date().toLocaleTimeString();
        const entry = {
            timestamp,
            category,
            message,
            level
        };
        
        this.diagnosticResults.push(entry);
        
        const color = {
            'error': 'color: red; font-weight: bold',
            'warn': 'color: orange; font-weight: bold',
            'success': 'color: green; font-weight: bold',
            'info': 'color: blue'
        }[level] || 'color: black';
        
        console.log(`%c[${category}] ${message}`, color);
    }

    addIssue(issue, recommendation) {
        this.issues.push(issue);
        this.recommendations.push(recommendation);
        this.log('ISSUE', issue, 'error');
        this.log('RECOMMENDATION', recommendation, 'warn');
    }

    async checkDOMStructure() {
        this.log('DOM', '检查DOM结构...', 'info');
        
        const requiredElements = [
            { id: 'chatContainer', desc: '聊天容器' },
            { id: 'messageInput', desc: '消息输入框' },
            { id: 'sendButton', desc: '发送按钮' },
            { id: 'settingsBtn', desc: '设置按钮' },
            { id: 'historyBtn', desc: '历史按钮' },
            { id: 'languageBtn', desc: '语言按钮' },
            { id: 'loginModal', desc: '登录模态框' },
            { id: 'guestModeBtn', desc: '访客模式按钮' }
        ];

        let missingElements = 0;
        for (const element of requiredElements) {
            const domElement = document.getElementById(element.id);
            if (!domElement) {
                this.addIssue(
                    `缺失DOM元素: ${element.id} (${element.desc})`,
                    `检查HTML文件中是否正确定义了id="${element.id}"的元素`
                );
                missingElements++;
            } else {
                this.log('DOM', `✅ ${element.desc} 存在`, 'success');
            }
        }

        if (missingElements === 0) {
            this.log('DOM', '✅ DOM结构完整', 'success');
        }
    }

    async checkScriptLoading() {
        this.log('SCRIPTS', '检查脚本加载状态...', 'info');
        
        const requiredClasses = [
            { name: 'MessageProcessor', desc: '消息处理器' },
            { name: 'MessageRenderer', desc: '消息渲染器' }
        ];

        const requiredGlobals = [
            { name: 'ChatCore', desc: '聊天核心' },
            { name: 'ChatUI', desc: '聊天UI' },
            { name: 'ChatAPI', desc: '聊天API' }
        ];

        for (const cls of requiredClasses) {
            if (typeof window[cls.name] === 'undefined') {
                this.addIssue(
                    `类 ${cls.name} 未定义`,
                    `检查相应的JS文件是否正确加载并定义了 ${cls.name} 类`
                );
            } else {
                this.log('SCRIPTS', `✅ ${cls.desc} 已加载`, 'success');
            }
        }

        for (const global of requiredGlobals) {
            if (typeof window[global.name] === 'undefined') {
                this.addIssue(
                    `全局对象 ${global.name} 未暴露`,
                    `检查模块脚本是否正确将 ${global.name} 暴露到 window 对象`
                );
            } else {
                this.log('SCRIPTS', `✅ ${global.desc} 已暴露`, 'success');
            }
        }
    }

    async checkMessageProcessorMethods() {
        this.log('PROCESSOR', '检查MessageProcessor方法...', 'info');
        
        if (typeof MessageProcessor === 'undefined') {
            this.addIssue(
                'MessageProcessor类未定义',
                '检查message-processor.js文件是否正确加载'
            );
            return;
        }

        const requiredMethods = [
            'processUserMessage',
            'processAssistantMessage',
            'escapeHtml',
            'processMarkdown'
        ];

        for (const method of requiredMethods) {
            if (typeof MessageProcessor[method] !== 'function') {
                this.addIssue(
                    `MessageProcessor.${method} 方法未定义`,
                    `在MessageProcessor类中添加 ${method} 静态方法`
                );
            } else {
                this.log('PROCESSOR', `✅ ${method} 方法存在`, 'success');
                
                // 测试方法功能
                try {
                    if (method === 'processUserMessage') {
                        const result = MessageProcessor[method]('测试');
                        if (!result) throw new Error('返回空值');
                    } else if (method === 'processAssistantMessage') {
                        const result = MessageProcessor[method]('**测试**');
                        if (!result) throw new Error('返回空值');
                    }
                    this.log('PROCESSOR', `✅ ${method} 功能正常`, 'success');
                } catch (error) {
                    this.addIssue(
                        `MessageProcessor.${method} 功能异常: ${error.message}`,
                        `检查 ${method} 方法的实现逻辑`
                    );
                }
            }
        }
    }

    async checkEventHandlers() {
        this.log('EVENTS', '检查事件处理器...', 'info');
        
        const buttonChecks = [
            { id: 'sendButton', desc: '发送按钮', expectedEvents: ['click'] },
            { id: 'settingsBtn', desc: '设置按钮', expectedEvents: ['click'] },
            { id: 'historyBtn', desc: '历史按钮', expectedEvents: ['click'] },
            { id: 'languageBtn', desc: '语言按钮', expectedEvents: ['click'] },
            { id: 'guestModeBtn', desc: '访客模式按钮', expectedEvents: ['click'] }
        ];

        for (const check of buttonChecks) {
            const element = document.getElementById(check.id);
            if (!element) continue;

            let hasEventHandler = false;
            
            // 检查onclick属性
            if (element.onclick) {
                hasEventHandler = true;
                this.log('EVENTS', `✅ ${check.desc} 有onclick处理器`, 'success');
            }
            
            // 检查addEventListener绑定 (这个比较难检测，但可以尝试)
            const listeners = getEventListeners ? getEventListeners(element) : null;
            if (listeners && listeners.click && listeners.click.length > 0) {
                hasEventHandler = true;
                this.log('EVENTS', `✅ ${check.desc} 有addEventListener处理器`, 'success');
            }

            if (!hasEventHandler) {
                this.addIssue(
                    `${check.desc} 缺少事件处理器`,
                    `为 ${check.id} 添加点击事件处理器`
                );
            }
        }

        // 检查消息输入框事件
        const messageInput = document.getElementById('messageInput');
        if (messageInput) {
            const hasKeydownHandler = messageInput.onkeydown || 
                (getEventListeners && getEventListeners(messageInput).keydown);
            
            if (!hasKeydownHandler) {
                this.addIssue(
                    '消息输入框缺少键盘事件处理器',
                    '为messageInput添加keydown事件处理器以支持回车发送'
                );
            } else {
                this.log('EVENTS', '✅ 消息输入框事件处理器存在', 'success');
            }
        }
    }

    async checkAPIEndpoints() {
        this.log('API', '检查API端点...', 'info');
        
        const endpoints = [
            { url: '/api/status', desc: '状态端点' },
            { url: '/api/chat/deepseek-chat', desc: '聊天端点', method: 'POST' }
        ];

        for (const endpoint of endpoints) {
            try {
                const options = endpoint.method === 'POST' ? {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ message: '测试', mode: 'guest' })
                } : {};

                const response = await fetch(endpoint.url, options);
                
                if (response.ok) {
                    this.log('API', `✅ ${endpoint.desc} 可访问`, 'success');
                } else {
                    this.addIssue(
                        `${endpoint.desc} 返回错误状态: ${response.status}`,
                        `检查服务器端 ${endpoint.url} 的实现`
                    );
                }
            } catch (error) {
                this.addIssue(
                    `${endpoint.desc} 请求失败: ${error.message}`,
                    `检查服务器是否运行以及网络连接`
                );
            }
        }
    }

    async checkConsoleErrors() {
        this.log('CONSOLE', '检查控制台错误...', 'info');
        
        // 存储原始的console.error方法
        const originalError = console.error;
        const errors = [];
        
        // 暂时劫持console.error来收集错误
        console.error = function(...args) {
            errors.push(args.join(' '));
            originalError.apply(console, args);
        };

        // 等待一小段时间来收集错误
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // 恢复原始的console.error
        console.error = originalError;
        
        if (errors.length > 0) {
            for (const error of errors) {
                this.addIssue(
                    `控制台错误: ${error}`,
                    '检查相关代码并修复错误'
                );
            }
        } else {
            this.log('CONSOLE', '✅ 无控制台错误', 'success');
        }
    }

    generateReport() {
        const report = {
            timestamp: new Date().toISOString(),
            totalChecks: this.diagnosticResults.length,
            issuesFound: this.issues.length,
            healthScore: Math.max(0, 100 - (this.issues.length * 10)),
            diagnostics: this.diagnosticResults,
            issues: this.issues,
            recommendations: this.recommendations
        };

        // 生成可视化报告
        console.log('\n' + '='.repeat(60));
        console.log('🏥 AlingAi 聊天系统健康诊断报告');
        console.log('='.repeat(60));
        console.log(`🕒 诊断时间: ${new Date().toLocaleString()}`);
        console.log(`📊 健康评分: ${report.healthScore}/100`);
        console.log(`🔍 执行检查: ${report.totalChecks} 项`);
        console.log(`⚠️  发现问题: ${report.issuesFound} 个`);
        console.log('='.repeat(60));

        if (report.issuesFound > 0) {
            console.log('\n🚨 发现的问题:');
            this.issues.forEach((issue, index) => {
                console.log(`${index + 1}. ${issue}`);
            });

            console.log('\n💡 修复建议:');
            this.recommendations.forEach((rec, index) => {
                console.log(`${index + 1}. ${rec}`);
            });
        } else {
            console.log('\n🎉 恭喜！系统运行良好，未发现问题！');
        }

        console.log('\n' + '='.repeat(60));
        
        return report;
    }

    async runFullDiagnostics() {
        console.log('🔍 开始AlingAi聊天系统深度诊断...');
        
        await this.checkDOMStructure();
        await this.checkScriptLoading();
        await this.checkMessageProcessorMethods();
        await this.checkEventHandlers();
        await this.checkAPIEndpoints();
        await this.checkConsoleErrors();
        
        const report = this.generateReport();
        
        // 暴露到全局供检查
        window.diagnosticReport = report;
        
        return report;
    }
}

// 自动执行诊断
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', async () => {
        await new Promise(resolve => setTimeout(resolve, 3000)); // 等待其他脚本加载
        const diagnostics = new ChatSystemDiagnostics();
        await diagnostics.runFullDiagnostics();
    });
} else {
    setTimeout(async () => {
        const diagnostics = new ChatSystemDiagnostics();
        await diagnostics.runFullDiagnostics();
    }, 3000);
}
