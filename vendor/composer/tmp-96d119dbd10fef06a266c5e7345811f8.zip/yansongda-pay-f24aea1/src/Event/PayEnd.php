<?php

declare(strict_types=1);

namespace Yansongda\Pay\Event;

use Yansongda\Artful\Event\Event;

class PayEnd extends Event {}
