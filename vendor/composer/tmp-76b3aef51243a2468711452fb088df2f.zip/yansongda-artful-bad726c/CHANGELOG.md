## v1.1.1

### chore

- chore: 升级 `yansongda/supports` 版本以解决潜在的问题(#19)

## v1.1.0

### changed

- change: http 配置项由 `httpFactory` 修改为 `http`(#17)

## v1.0.9

### fixed

- fix: 修复 `JsonPacker` 为空时 `packer` 错误的问题(#15)

## v1.0.8

### added

- feat: `get_radar_body` 返回值由 `?string` 改为 `mixed`(#10)
- feat: 增加 `StartPlugin` 插件(#10)

## v1.0.7

### added

- feat: `unpack` 支持参数(#8, #9)

## v1.0.6

### chore

- chore: 依赖由 `guzzlehttp/guzzle` 改为 `guzzlehttp/psr7`(#7)

## v1.0.5

### added

- feat: 增加 `load()` 第二个参数默认值为 `null`(#6)

## v1.0.4

### added

- feat: 增加 `registerService()` 第二个参数默认值为 `null`(#5)

## v1.0.3

### added

- feat: 增加 `InvalidConfigException`(#4)

## v1.0.2

### changed

- change: 更改 `Exception` code 码(#3)

## v1.0.1

### added

- feat: 增加 `shortcut` 快捷方式(#2)

## v1.0.0

### init

- init: 首个版本(#1)