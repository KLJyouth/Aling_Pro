<?php

declare(strict_types=1);

namespace Yansongda\Artful\Contract;

interface LoggerInterface extends \Psr\Log\LoggerInterface {}
