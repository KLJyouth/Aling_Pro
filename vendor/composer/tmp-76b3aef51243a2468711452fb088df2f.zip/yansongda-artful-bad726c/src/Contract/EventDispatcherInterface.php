<?php

declare(strict_types=1);

namespace Yansongda\Artful\Contract;

interface EventDispatcherInterface extends \Psr\EventDispatcher\EventDispatcherInterface {}
