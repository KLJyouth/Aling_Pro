<?php

declare(strict_types=1);

namespace Yansongda\Artful\Direction;

class ResponseDirection extends NoHttpRequestDirection {}
