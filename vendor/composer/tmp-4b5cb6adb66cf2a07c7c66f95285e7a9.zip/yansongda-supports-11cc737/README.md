<h1 align="center">Supports</h1>

[![Linter Status](https://github.com/yansongda/supports/workflows/Coding%20Style/badge.svg)](https://github.com/yansongda/supports/actions) 
[![Tester Status](https://github.com/yansongda/supports/workflows/Tester/badge.svg)](https://github.com/yansongda/supports/actions)
[![Latest Stable Version](https://poser.pugx.org/yansongda/supports/v/stable)](https://packagist.org/packages/yansongda/supports)
[![Total Downloads](https://poser.pugx.org/yansongda/supports/downloads)](https://packagist.org/packages/yansongda/supports)
[![License](https://poser.pugx.org/yansongda/supports/license)](https://packagist.org/packages/yansongda/supports)


handle with array/config/Pipeline etc.

