<?php

declare(strict_types=1);

namespace Yansongda\Supports;

class Config extends Collection {}
