# v4.0.0

## change

- php 最低版本改为 8.0

## delete

- 删除 Yansongda\Supports\Logger\StdoutHandler
- 删除 Yansongda\Supports\Logger
