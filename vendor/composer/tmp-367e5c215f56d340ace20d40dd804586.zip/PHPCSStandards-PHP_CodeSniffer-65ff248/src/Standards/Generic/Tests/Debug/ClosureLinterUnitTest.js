/**
 * My function
 */
function something() {
	return a;
}
